﻿using COVID.Datos.Opcion;
using COVID.Entidades;
using COVID.Entidades.Listado;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Negocio.Opcion
{
    public class OpcionBL:IOpcionBL
    {
        private readonly IOpcionDAL _objOpcionDAL;

        #region Constructores

        public OpcionBL()
        {
            _objOpcionDAL = new OpcionDAL();
        }
        public OpcionBL(IOpcionDAL ObjOpcionDAL)
        {
            _objOpcionDAL = ObjOpcionDAL;
        }
        #endregion

        public List<OpcionListaEL> fn_Get_Opcion(OpcionEL objOpcionEL)
        {
            return _objOpcionDAL.fn_Get_Opcion(objOpcionEL);
        }

        public OpcionEL fn_GetInfo_Opcion(OpcionEL objOpcionEL)
        {
            return _objOpcionDAL.fn_GetInfo_Opcion(objOpcionEL);
        }

        public string fn_Update_Opcion(OpcionEL objOpcionEL)
        {
            return _objOpcionDAL.fn_Update_Opcion(objOpcionEL);
        }

        public string fn_Insert_Opcion(OpcionEL objOpcionEL)
        {
            return _objOpcionDAL.fn_Insert_Opcion(objOpcionEL);
        }
    }
}
