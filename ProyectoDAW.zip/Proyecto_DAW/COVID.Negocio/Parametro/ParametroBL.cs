﻿using COVID.Datos.Parametro;
using COVID.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Negocio.Parametro
{
    public class ParametroBL : IParametroBL
    {
        private readonly IParametroDAL _objParametroDAL;

        #region Constructores

        public ParametroBL()
        {
            _objParametroDAL = new ParametroDAL();
        }
        public ParametroBL(IParametroDAL ObjParametroDAL)
        {
            _objParametroDAL = ObjParametroDAL;
        }
        #endregion

        public List<ParametroEL> fn_Get_ParametrosXGrupo(ParametroEL objParametroEL)
        {
            return _objParametroDAL.fn_Get_ParametrosXGrupo(objParametroEL);
        }

        public List<ParametroEL> fn_Get_ParametrosXGrupo_Todos(ParametroEL objParametroEL)
        {
            return _objParametroDAL.fn_Get_ParametrosXGrupo_Todos(objParametroEL);
        }

        public List<ParametroEL> fn_Get_Roles()
        {
            return _objParametroDAL.fn_Get_Roles();
        }
    }
}
