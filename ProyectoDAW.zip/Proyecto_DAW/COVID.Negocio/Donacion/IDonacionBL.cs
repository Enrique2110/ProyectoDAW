﻿using COVID.Entidades;
using COVID.Entidades.Listado;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Negocio.Donacion
{
    public interface IDonacionBL
    {
        List<DonacionListaEL> fn_Get_Donacion(DonacionEL objDonacionEL);
        string fn_Insert_Donacion(DonacionEL objDonacionEL);
        DonacionEL fn_GetInfo_Donacion(DonacionEL objDonacionEL);
        string fn_Update_Donacion(DonacionEL objDonacionEL);
        List<DonacionEL> fn_Get_Donaciones_Persona(int intTipoConsulta, PersonaEL objPersonaEL);
        string fn_Insert_DonacionPersona(List<DonacionEL> lstDonaciones, PersonaEL objPersonaEL);
        List<DonacionEL> fn_Get_DonacionesReporte();
    }
}
