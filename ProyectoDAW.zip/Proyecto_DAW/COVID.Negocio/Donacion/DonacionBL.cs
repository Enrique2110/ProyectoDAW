﻿using COVID.Datos.Donacion;
using COVID.Entidades;
using COVID.Entidades.Listado;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Negocio.Donacion
{
    public class DonacionBL:IDonacionBL
    {
        private readonly IDonacionDAL _objDonacionDAL;
        #region Constructores
        public DonacionBL()
        {
            _objDonacionDAL = new DonacionDAL();
        }
        public DonacionBL(IDonacionDAL ObjDonacionDAL)
        {
            _objDonacionDAL = ObjDonacionDAL;
        }
        #endregion

        public List<DonacionListaEL> fn_Get_Donacion(DonacionEL objDonacionEL)
        {
            return _objDonacionDAL.fn_Get_Donacion(objDonacionEL);
        }

        public string fn_Insert_Donacion(DonacionEL objDonacionEL)
        {
            return _objDonacionDAL.fn_Insert_Donacion(objDonacionEL);
        }

        public DonacionEL fn_GetInfo_Donacion(DonacionEL objDonacionEL)
        {
            return _objDonacionDAL.fn_GetInfo_Donacion(objDonacionEL);
        }

        public string fn_Update_Donacion(DonacionEL objDonacionEL)
        {
            return _objDonacionDAL.fn_Update_Donacion(objDonacionEL);
        }

        public List<DonacionEL> fn_Get_Donaciones_Persona(int intTipoConsulta, PersonaEL objPersonaEL)
        {
            return _objDonacionDAL.fn_Get_Donaciones_Persona(intTipoConsulta, objPersonaEL);
        }

        public string fn_Insert_DonacionPersona(List<DonacionEL> lstDonaciones, PersonaEL objPersonaEL)
        {
            return _objDonacionDAL.fn_Insert_DonacionPersona(lstDonaciones, objPersonaEL);
        }

        public List<DonacionEL> fn_Get_DonacionesReporte()
        {
            return _objDonacionDAL.fn_Get_DonacionesReporte();
        }
    }
}
