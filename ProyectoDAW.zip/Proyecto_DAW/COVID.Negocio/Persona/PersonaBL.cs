﻿using COVID.Datos.Persona;
using COVID.Entidades;
using COVID.Entidades.Listado;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Negocio.Persona
{
    public class PersonaBL:IPersonaBL
    {
        private readonly IPersonaDAL _objPersonaDAL;
        #region Constructores
        public PersonaBL()
        {
            _objPersonaDAL = new PersonaDAL();
        }
        public PersonaBL(IPersonaDAL ObjPersonaDAL)
        {
            _objPersonaDAL = ObjPersonaDAL;
        }
        #endregion

        public List<PersonaPobreListaEL> fn_Get_Persona(PersonaEL objPersonaEL)
        {
            return _objPersonaDAL.fn_Get_Persona(objPersonaEL);
        }

        public string fn_Insert_Persona(PersonaEL objPersonaEL)
        {
            return _objPersonaDAL.fn_Insert_Persona(objPersonaEL);
        }

        public string fn_Update_PersonaFoto(PersonaEL objPersonaEL)
        {
            return _objPersonaDAL.fn_Update_PersonaFoto(objPersonaEL);
        }

        public PersonaEL fn_GetInfo_Persona(PersonaEL objPersonaEL)
        {
            return _objPersonaDAL.fn_GetInfo_Persona(objPersonaEL);
        }
    }
}
