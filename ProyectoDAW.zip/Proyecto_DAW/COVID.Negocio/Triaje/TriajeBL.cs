﻿using COVID.Datos.Triaje;
using COVID.Entidades;
using COVID.Entidades.Listado;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Negocio.Triaje
{
    public class TriajeBL:ITriajeBL
    {
        private readonly ITriajeDAL _objTriajeDAL;
        #region Constructores
        public TriajeBL()
        {
            _objTriajeDAL = new TriajeDAL();
        }
        public TriajeBL(ITriajeDAL ObjTriajeDAL)
        {
            _objTriajeDAL = ObjTriajeDAL;
        }
        #endregion

        public List<TriajeListaEL> fn_Get_Triaje(TriajeEL objTriajeEL)
        {
            return _objTriajeDAL.fn_Get_Triaje(objTriajeEL);
        }

        public string fn_Insert_Triaje(TriajeEL objTriajeEL)
        {
            return _objTriajeDAL.fn_Insert_Triaje(objTriajeEL);
        }

        public TriajeEL fn_GetInfo_Triaje(TriajeEL objTriajeEL)
        {
            return _objTriajeDAL.fn_GetInfo_Triaje(objTriajeEL);
        }

        public TriajeEL fn_Get_TotalTriajes()
        {
            return _objTriajeDAL.fn_Get_TotalTriajes();
        }

        public TriajeEL fn_Get_TotalTriajeResultado(TriajeEL objTriajeEL)
        {
            return _objTriajeDAL.fn_Get_TotalTriajeResultado(objTriajeEL);
        }

        public List<TriajeEL> fn_Get_TriajeSexo()
        {
            return _objTriajeDAL.fn_Get_TriajeSexo();
        }

        public List<TriajeEL> fn_Get_TriajeTipoPrueba()
        {
            return _objTriajeDAL.fn_Get_TriajeTipoPrueba();
        }
    }
}
