﻿using COVID.Entidades;
using COVID.Entidades.Listado;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Negocio.Triaje
{
    public interface ITriajeBL
    {
        List<TriajeListaEL> fn_Get_Triaje(TriajeEL objTriajeEL);
        string fn_Insert_Triaje(TriajeEL objTriajeEL);
        TriajeEL fn_GetInfo_Triaje(TriajeEL objTriajeEL);
        TriajeEL fn_Get_TotalTriajes();
        TriajeEL fn_Get_TotalTriajeResultado(TriajeEL objTriajeEL);
        List<TriajeEL> fn_Get_TriajeSexo();
        List<TriajeEL> fn_Get_TriajeTipoPrueba();
    }
}
