﻿using COVID.Datos.Seguridad;
using COVID.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Negocio.Seguridad
{
    public class SeguridadBL : ISeguridadBL
    {
        private readonly ISeguridadDAL _objSeguridadDAL;
        
        #region Constructores

        public SeguridadBL()
        {
            _objSeguridadDAL = new SeguridadDAL();
        }

        public SeguridadBL(ISeguridadDAL ObjSeguridadDAL)
        {
            _objSeguridadDAL = ObjSeguridadDAL;
        }
        #endregion

        public UsuarioActualEL GetUsuarioLogin(string strUsuario)
        {
            return _objSeguridadDAL.GetUsuarioLogin(strUsuario);
        }

        public List<OpcionEL> GetOpcionesRol(int idRol)
        {
            return _objSeguridadDAL.GetOpcionesRol(idRol);
        }
    }
}
