﻿using COVID.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Negocio.Seguridad
{
    public interface ISeguridadBL
    {
        UsuarioActualEL GetUsuarioLogin(string strUsuario);

        List<OpcionEL> GetOpcionesRol(int idRol);
    }
}
