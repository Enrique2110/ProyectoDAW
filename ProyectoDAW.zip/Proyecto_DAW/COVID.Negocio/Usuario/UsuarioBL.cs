﻿using COVID.Datos.Usuario;
using COVID.Entidades;
using COVID.Entidades.Listado;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Negocio.Usuario
{
    public class UsuarioBL:IUsuarioBL
    {
        private readonly IUsuarioDAL _objUsuarioDAL;
        #region Constructores
        public UsuarioBL()
        {
            _objUsuarioDAL = new UsuarioDAL();
        }
        public UsuarioBL(IUsuarioDAL ObjUsuarioDAL)
        {
            _objUsuarioDAL = ObjUsuarioDAL;
        }
        #endregion
        public List<UsuarioListaEL> fn_Get_Usuario(UsuarioEL objUsuarioEL)
        {
            return _objUsuarioDAL.fn_Get_Usuario(objUsuarioEL);
        }

        public string fn_Insert_Usuario(UsuarioEL objUsuarioEL)
        {
            return _objUsuarioDAL.fn_Insert_Usuario(objUsuarioEL);
        }

        public UsuarioEL fn_GetInfo_Usuario(UsuarioEL objUsuarioEL)
        {
            return _objUsuarioDAL.fn_GetInfo_Usuario(objUsuarioEL);
        }

        public string fn_Update_Usuario(UsuarioEL objUsuarioEL)
        {
            return _objUsuarioDAL.fn_Update_Usuario(objUsuarioEL);
        }

        public string fn_Update_Clave(UsuarioEL objUsuarioEL)
        {
            return _objUsuarioDAL.fn_Update_Clave(objUsuarioEL);
        }

        public string fn_Update_GenerarClave(UsuarioEL objUsuarioEL)
        {
            return _objUsuarioDAL.fn_Update_GenerarClave(objUsuarioEL);
        }

        public string fn_Update_UsuarioAvatar(UsuarioEL objUsuarioEL)
        {
            return _objUsuarioDAL.fn_Update_UsuarioAvatar(objUsuarioEL);
        }

        public UsuarioActualEL fn_GetInfo_UsuarioCorreo(string strCorreo)
        {
            return _objUsuarioDAL.fn_GetInfo_UsuarioCorreo(strCorreo);
        }

        public UsuarioEL GetUsuarioAdministrador()
        {
            return _objUsuarioDAL.GetUsuarioAdministrador();
        }
    }
}
