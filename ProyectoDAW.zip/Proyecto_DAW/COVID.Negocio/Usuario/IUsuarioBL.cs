﻿using COVID.Entidades;
using COVID.Entidades.Listado;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Negocio.Usuario
{
    public interface IUsuarioBL
    {
        List<UsuarioListaEL> fn_Get_Usuario(UsuarioEL objUsuarioEL);
        string fn_Insert_Usuario(UsuarioEL objUsuarioEL);
        UsuarioEL fn_GetInfo_Usuario(UsuarioEL objUsuarioEL);
        string fn_Update_Usuario(UsuarioEL objUsuarioEL);
        string fn_Update_Clave(UsuarioEL objUsuarioEL);
        string fn_Update_GenerarClave(UsuarioEL objUsuarioEL);
        string fn_Update_UsuarioAvatar(UsuarioEL objUsuarioEL);
        UsuarioActualEL fn_GetInfo_UsuarioCorreo(string strCorreo);
        UsuarioEL GetUsuarioAdministrador();
    }
}
