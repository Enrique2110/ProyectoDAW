﻿using COVID.Datos.Rol;
using COVID.Entidades;
using COVID.Entidades.Listado;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Negocio.Rol
{
    public class RolBL:IRolBL
    {
        private readonly IRolDAL _objRolDAL;

        #region Constructores
        
        public RolBL()
        {
            _objRolDAL = new RolDAL();
        }
        public RolBL(IRolDAL ObjRolDAL)
        {
            _objRolDAL = ObjRolDAL;
        }
        #endregion

        public List<RolListaEL> fn_Get_Rol(RolEL objRolEL)
        {
            return _objRolDAL.fn_Get_Rol(objRolEL);
        }

        public string fn_Insert_Rol(RolEL objRolEL)
        {
            return _objRolDAL.fn_Insert_Rol(objRolEL);
        }

        public RolEL fn_GetInfo_Rol(RolEL objRolEL)
        {
            return _objRolDAL.fn_GetInfo_Rol(objRolEL);
        }

        public string fn_Update_Rol(RolEL objRolEL)
        {
            return _objRolDAL.fn_Update_Rol(objRolEL);
        }

        public List<OpcionEL> fn_Get_Rol_Opcion_Actual(int intTipoConsulta, RolEL objRolEL)
        {
            return _objRolDAL.fn_Get_Rol_Opcion_Actual(intTipoConsulta, objRolEL);
        }

        public string fn_Insert_RolOpcion(List<OpcionEL> lstOpciones,RolEL objRolEL)
        {
            return _objRolDAL.fn_Insert_RolOpcion(lstOpciones, objRolEL);
        }
    }
}
