﻿using COVID.Datos.Helpers;
using COVID.Entidades;
using COVID.Entidades.Listado;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Datos.Triaje
{
    public class TriajeDAL:ITriajeDAL
    {
        public List<TriajeListaEL> fn_Get_Triaje(TriajeEL objTriajeEL)
        {
            try
            {
                List<TriajeListaEL> lstTriajes = new List<TriajeListaEL>();
                TriajeListaEL triaje;
                DataTable dt = new DataTable();
                SqlParameter[] objParameter = new SqlParameter[2];
                objParameter[0] = new SqlParameter("@RESULTADO", objTriajeEL.RESULTADO_ID);
                objParameter[1] = new SqlParameter("@TIPOPRUEBA", objTriajeEL.TIPO_PRUEBA_ID);
                SqlHelper.Fill(dt, "sp_GetListaTriaje", objParameter);

                foreach (DataRow item in dt.Rows)
                {
                    triaje = new TriajeListaEL();
                    triaje.TRIAJE_ID = Convert.ToInt32(item[0].ToString());
                    triaje.APELLIDO_PACIENTE = item[1].ToString();
                    triaje.NOMBRE_PACIENTE = item[2].ToString();
                    triaje.RESULTADO = item[3].ToString();
                    triaje.TIPO_PRUEBA = item[4].ToString();
                    triaje.DIRECCION = item[5].ToString();
                    triaje.PROFESION = item[6].ToString();
                    lstTriajes.Add(triaje);
                }
                return lstTriajes;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public string fn_Insert_Triaje(TriajeEL objTriajeEL)
        {
            try
            {
                SqlParameter[] objParameter = new SqlParameter[11];
                objParameter[0] = new SqlParameter("@TIPO_DOCUMENTO", objTriajeEL.TIPO_DOCUMENTO_ID);
                objParameter[1] = new SqlParameter("@NRO_DOCUMENTO", objTriajeEL.NRO_DOCUMENTO);
                objParameter[2] = new SqlParameter("@PATERNO", objTriajeEL.APELLIDO_PACIENTE);
                objParameter[3] = new SqlParameter("@MATERNO", objTriajeEL.APELLIDO_MATERNO_PACIENTE);
                objParameter[4] = new SqlParameter("@NOMBRE", objTriajeEL.NOMBRE_PACIENTE);
                objParameter[5] = new SqlParameter("@SEXO", objTriajeEL.SEXO_ID);
                objParameter[6] = new SqlParameter("@DIRECCION", objTriajeEL.DIRECCION);
                objParameter[7] = new SqlParameter("@PROFESION", objTriajeEL.PROFESION);
                objParameter[8] = new SqlParameter("@TIPO_PRUEBA", objTriajeEL.TIPO_PRUEBA_ID);
                objParameter[9] = new SqlParameter("@RESULTADO", objTriajeEL.RESULTADO_ID);
                objParameter[10] = new SqlParameter("@USUARIOCREACION", objTriajeEL.USUARIO_CREACION);
                int resultado = Convert.ToInt32(SqlHelper.ExecuteScalar("sp_GetGuardarTriaje", objParameter));
                return resultado.ToString();
            }
            catch (Exception ex)
            {
                return "NOOK";
            }
        }

        public TriajeEL fn_GetInfo_Triaje(TriajeEL objTriajeEL)
        {
            try
            {
                TriajeEL triaje = null;
                DataTable dt = new DataTable();
                SqlParameter[] objParameter = new SqlParameter[1];
                objParameter[0] = new SqlParameter("@IDTRIAJE", objTriajeEL.TRIAJE_ID);
                SqlHelper.Fill(dt, "sp_GetTriaje", objParameter);
                foreach (DataRow item in dt.Rows)
                {
                    triaje = new TriajeEL();
                    triaje.TRIAJE_ID = Convert.ToInt32(item[0].ToString());
                    triaje.TIPO_DOCUMENTO_ID = Convert.ToInt32(item[1].ToString());
                    triaje.NRO_DOCUMENTO = item[2].ToString();
                    triaje.APELLIDO_PACIENTE = item[3].ToString();
                    triaje.APELLIDO_MATERNO_PACIENTE = item[4].ToString();
                    triaje.NOMBRE_PACIENTE = item[5].ToString();
                    triaje.SEXO_ID = Convert.ToInt32(item[6].ToString());
                    triaje.DIRECCION = item[7].ToString();
                    triaje.PROFESION = item[8].ToString();
                    triaje.TIPO_PRUEBA_ID = Convert.ToInt32(item[9].ToString());
                    triaje.RESULTADO_ID = Convert.ToInt32(item[10].ToString());
                }
                return triaje;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public TriajeEL fn_Get_TotalTriajes()
        {
            try
            {
                TriajeEL triaje = new TriajeEL();
                DataTable dt = new DataTable();
                SqlHelper.Fill(dt, "sp_GetTotalTriaje");
                foreach (DataRow item in dt.Rows)
                {
                    triaje = new TriajeEL();
                    triaje.TOTAL_TRIAJE = Convert.ToInt32(item[0].ToString());
                }
                return triaje;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public TriajeEL fn_Get_TotalTriajeResultado(TriajeEL objTriajeEL)
        {
            try
            {
                TriajeEL triaje = new TriajeEL();
                DataTable dt = new DataTable();
                SqlParameter[] objParameter = new SqlParameter[1];
                objParameter[0] = new SqlParameter("@RESULTADO", objTriajeEL.RESULTADO_ID);
                SqlHelper.Fill(dt, "sp_GetTotalTriajeResultado", objParameter);
                foreach (DataRow item in dt.Rows)
                {
                    triaje = new TriajeEL();
                    triaje.TOTAL_TRIAJE = Convert.ToInt32(item[0].ToString());
                }
                return triaje;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<TriajeEL> fn_Get_TriajeSexo()
        {
            try
            {
                List<TriajeEL> lstTriajes = new List<TriajeEL>();
                TriajeEL triaje;
                DataTable dt = new DataTable();
                SqlHelper.Fill(dt, "sp_GetTriajexSexo");

                foreach (DataRow item in dt.Rows)
                {
                    triaje = new TriajeEL();
                    triaje.DESCRIPCION = item[0].ToString();
                    triaje.TOTAL_TRIAJE = Convert.ToInt32(item[1].ToString());
                    lstTriajes.Add(triaje);
                }
                return lstTriajes;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<TriajeEL> fn_Get_TriajeTipoPrueba()
        {
            try
            {
                List<TriajeEL> lstTriajes = new List<TriajeEL>();
                TriajeEL triaje;
                DataTable dt = new DataTable();
                SqlHelper.Fill(dt, "sp_GetTriajeTipoPrueba");

                foreach (DataRow item in dt.Rows)
                {
                    triaje = new TriajeEL();
                    triaje.TIPO_PRUEBA = item[0].ToString();
                    triaje.TOTAL_TRIAJE = Convert.ToInt32(item[1].ToString());
                    lstTriajes.Add(triaje);
                }
                return lstTriajes;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
