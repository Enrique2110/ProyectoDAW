﻿using COVID.Datos.Helpers;
using COVID.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Datos.Seguridad
{
    public class SeguridadDAL : ISeguridadDAL
    {

        public UsuarioActualEL GetUsuarioLogin(string strUsuario)
        {
            try
            {
                UsuarioActualEL usuario=null;
                DataTable dt = new DataTable();
                SqlParameter[] objParameter = new SqlParameter[1];
                objParameter[0] = new SqlParameter("@USUARIO", strUsuario);
                SqlHelper.Fill(dt, "sp_GetUsuarioLogin", objParameter);

                foreach (DataRow item in dt.Rows)
                {
                    usuario = new UsuarioActualEL();
                    usuario.USUARIO_ID = Convert.ToInt32(item[0].ToString());
                    usuario.LOGIN_USUARIO = item[1].ToString();
                    usuario.ROL_ID = Convert.ToInt32(item[2].ToString());
                    usuario.PERSONA_ID = Convert.ToInt32(item[3].ToString());
                    usuario.LOGIN_PWD = item[4].ToString();
                    usuario.APELLIDO_PATERNO = item[5].ToString();
                    usuario.APELLIDO_MATERNO = item[6].ToString();
                    usuario.NOMBRE=item[7].ToString();
                    usuario.NOMBRE_ROL = item[8].ToString();
                    usuario.AVATAR=item[9].ToString();
                }
                return usuario;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<OpcionEL> GetOpcionesRol(int idRol)
        {
            try
            {
                List<OpcionEL> lstOpciones= new List<OpcionEL>();
                OpcionEL opcion;
                DataTable dt = new DataTable();
                SqlParameter[] objParameter = new SqlParameter[1];
                objParameter[0] = new SqlParameter("@ROL", idRol);
                SqlHelper.Fill(dt, "sp_GetOpcionxRol", objParameter);
                foreach (DataRow item in dt.Rows)
                {
                    opcion = new OpcionEL();
                    opcion.OPCION_ID = Convert.ToInt32(item[0].ToString());
                    opcion.NOMBRE_OPCION = item[1].ToString();
                    opcion.SIGLA_OPCION = item[2].ToString();
                    opcion.ESTADO = int.Parse(item[3].ToString());
                    lstOpciones.Add(opcion);
                }
                return lstOpciones;
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
