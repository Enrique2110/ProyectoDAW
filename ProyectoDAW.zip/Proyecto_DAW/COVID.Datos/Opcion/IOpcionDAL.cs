﻿using COVID.Entidades;
using COVID.Entidades.Listado;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Datos.Opcion
{
    public interface IOpcionDAL
    {
        List<OpcionListaEL> fn_Get_Opcion(OpcionEL objOpcionEL);
        OpcionEL fn_GetInfo_Opcion(OpcionEL objOpcionEL);
        string fn_Update_Opcion(OpcionEL objOpcionEL);
        string fn_Insert_Opcion(OpcionEL objOpcionEL);
    }
}
