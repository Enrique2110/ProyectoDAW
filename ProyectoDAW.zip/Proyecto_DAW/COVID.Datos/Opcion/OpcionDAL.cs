﻿using COVID.Datos.Helpers;
using COVID.Entidades;
using COVID.Entidades.Listado;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Datos.Opcion
{
    public class OpcionDAL:IOpcionDAL
    {
        public List<OpcionListaEL> fn_Get_Opcion(OpcionEL objOpcionEL)
        {
            try
            {
                List<OpcionListaEL> lstOpciones = new List<OpcionListaEL>();
                OpcionListaEL opcion;
                DataTable dt = new DataTable();
                SqlParameter[] objParameter = new SqlParameter[1];
                objParameter[0] = new SqlParameter("@NOMBRE", objOpcionEL.NOMBRE_OPCION);
                SqlHelper.Fill(dt, "sp_GetListaOpciones", objParameter);

                foreach (DataRow item in dt.Rows)
                {
                    opcion = new OpcionListaEL();
                    opcion.OPCION_ID = Convert.ToInt32(item[0].ToString());
                    opcion.NOMBRE = item[1].ToString();
                    opcion.ESTADO_DESCRIPCION = item[2].ToString();
                    lstOpciones.Add(opcion);
                }
                return lstOpciones;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public OpcionEL fn_GetInfo_Opcion(OpcionEL objOpcionEL)
        {
            try
            {
                OpcionEL opcion = null;
                DataTable dt = new DataTable();
                SqlParameter[] objParameter = new SqlParameter[1];
                objParameter[0] = new SqlParameter("@IDOPCION", objOpcionEL.OPCION_ID);
                SqlHelper.Fill(dt, "sp_GetOpcion", objParameter);

                foreach (DataRow item in dt.Rows)
                {
                    opcion = new OpcionEL();
                    opcion.OPCION_ID = Convert.ToInt32(item[0].ToString());
                    opcion.NOMBRE_OPCION = item[1].ToString();
                    opcion.DESCRIPCION = item[2].ToString();
                    opcion.ESTADO = Convert.ToInt32(item[3].ToString());
                    opcion.SIGLA_OPCION= item[4].ToString();
                }
                return opcion;
            }
            catch (Exception ex)
            {
                return null;
            }   
        }

        public string fn_Update_Opcion(OpcionEL objOpcionEL)
        {
            try
            {
                SqlParameter[] objParameter = new SqlParameter[5];
                objParameter[0] = new SqlParameter("@NOMBRE", objOpcionEL.NOMBRE_OPCION);
                objParameter[1] = new SqlParameter("@DESCRIPCION", objOpcionEL.DESCRIPCION);
                objParameter[2] = new SqlParameter("@ESTADO", objOpcionEL.ESTADO);
                objParameter[3] = new SqlParameter("@USUCREACION", objOpcionEL.USU_CREACION);
                objParameter[4] = new SqlParameter("@IDOPCION", objOpcionEL.OPCION_ID);
                int resultado = Convert.ToInt32(SqlHelper.ExecuteScalar("sp_GetActualizarOpcion", objParameter));
                return resultado.ToString();
            }
            catch (Exception ex)
            {
                return "NOOK";
            }
        }

        public string fn_Insert_Opcion(OpcionEL objOpcionEL)
        {
            try
            {
                SqlParameter[] objParameter = new SqlParameter[4];
                objParameter[0] = new SqlParameter("@NOMBRE", objOpcionEL.NOMBRE_OPCION);
                objParameter[1] = new SqlParameter("@DESCRIPCION", objOpcionEL.DESCRIPCION);
                objParameter[2] = new SqlParameter("@PALABRA", objOpcionEL.SIGLA_OPCION);
                objParameter[3] = new SqlParameter("@USUCREACION", objOpcionEL.USU_CREACION);
                int resultado = Convert.ToInt32(SqlHelper.ExecuteScalar("sp_GetGuardarOpcion", objParameter));
                return resultado.ToString();
            }
            catch (Exception ex)
            {
                return "NOOK";
            }
        }
    }
}
