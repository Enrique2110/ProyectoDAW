﻿using COVID.Datos.Helpers;
using COVID.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Datos.Parametro
{
    public class ParametroDAL : IParametroDAL
    {
        public List<ParametroEL> fn_Get_ParametrosXGrupo(ParametroEL objParametroEL)
        {
            try
            {
                List<ParametroEL> lstParametros = new List<ParametroEL>();
                ParametroEL parametro;
                DataTable dt = new DataTable();
                SqlParameter[] objParameter = new SqlParameter[1];
                objParameter[0] = new SqlParameter("@GRUPO", objParametroEL.GRUPO_LISTA_VALORES);
                SqlHelper.Fill(dt, "sp_GetListaParametros", objParameter);
                foreach (DataRow item in dt.Rows)
                {
                    parametro = new ParametroEL();
                    parametro.CODIGO_VALOR = item[0].ToString();
                    parametro.DESCRIPCION = item[1].ToString();
                    parametro.VALOR=item[2].ToString();
                    lstParametros.Add(parametro);
                }
                return lstParametros;
            }
            catch (Exception ex)
            {
                return null;
            }   
        }

        public List<ParametroEL> fn_Get_ParametrosXGrupo_Todos(ParametroEL objParametroEL)
        {
            try
            {
                List<ParametroEL> lstParametros = new List<ParametroEL>();
                ParametroEL parametro;
                DataTable dt = new DataTable();
                SqlParameter[] objParameter = new SqlParameter[1];
                objParameter[0] = new SqlParameter("@GRUPO", objParametroEL.GRUPO_LISTA_VALORES);
                SqlHelper.Fill(dt, "sp_GetListaParametros", objParameter);
                parametro = new ParametroEL();
                parametro.CODIGO_VALOR = "0";
                parametro.DESCRIPCION = "--Todos--";
                parametro.VALOR = "0";
                lstParametros.Add(parametro);
                foreach (DataRow item in dt.Rows)
                {
                    parametro = new ParametroEL();
                    parametro.CODIGO_VALOR = item[0].ToString();
                    parametro.DESCRIPCION = item[1].ToString();
                    parametro.VALOR = item[2].ToString();
                    lstParametros.Add(parametro);
                }
                return lstParametros;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<ParametroEL> fn_Get_Roles()
        {
            try
            {
                List<ParametroEL> lstParametros = new List<ParametroEL>();
                ParametroEL parametro;
                DataTable dt = new DataTable();
                SqlHelper.Fill(dt, "sp_GetRolesActivo");
                foreach (DataRow item in dt.Rows)
                {
                    parametro = new ParametroEL();
                    parametro.CODIGO_VALOR = item[0].ToString();
                    parametro.DESCRIPCION = item[1].ToString();
                    lstParametros.Add(parametro);
                }
                return lstParametros;
            }
            catch (Exception ex)
            {
                return null;
            }   
        }

    }
}
