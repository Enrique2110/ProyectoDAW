﻿using COVID.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Datos.Parametro
{
    public interface IParametroDAL
    {
        List<ParametroEL> fn_Get_ParametrosXGrupo(ParametroEL objParametroEL);
        List<ParametroEL> fn_Get_ParametrosXGrupo_Todos(ParametroEL objParametroEL);
        List<ParametroEL> fn_Get_Roles();
    }
}
