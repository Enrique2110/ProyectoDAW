﻿using COVID.Entidades;
using COVID.Entidades.Listado;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Datos.Rol
{
    public interface IRolDAL
    {
        List<RolListaEL> fn_Get_Rol(RolEL objRolEL);
        string fn_Insert_Rol(RolEL objRolEL);
        RolEL fn_GetInfo_Rol(RolEL objRolEL);
        string fn_Update_Rol(RolEL objRolEL);
        List<OpcionEL> fn_Get_Rol_Opcion_Actual(int intTipoConsulta, RolEL objRolEL);
        string fn_Insert_RolOpcion(List<OpcionEL> lstOpciones, RolEL objRolEL);
    }
}
