﻿using COVID.Datos.Helpers;
using COVID.Entidades;
using COVID.Entidades.Listado;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Datos.Rol
{
    public class RolDAL:IRolDAL
    {
        public List<RolListaEL> fn_Get_Rol(RolEL objPerfilEL)
        {
            try
            {
                List<RolListaEL> lstRoles = new List<RolListaEL>();
                RolListaEL rol;
                DataTable dt = new DataTable();
                SqlParameter[] objParameter = new SqlParameter[1];
                objParameter[0] = new SqlParameter("@NOMBRE", objPerfilEL.NOMBRE_ROL);
                SqlHelper.Fill(dt, "sp_GetListaRoles", objParameter);

                foreach (DataRow item in dt.Rows)
                {
                    rol = new RolListaEL();
                    rol.ROL_ID = Convert.ToInt32(item[0].ToString());
                    rol.NOMBRE_ROL = item[1].ToString();
                    rol.ESTADO_DESCRIPCION = item[3].ToString();
                    rol.USUARIO_CREACION = item[4].ToString();
                    lstRoles.Add(rol);
                }
                return lstRoles;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public string fn_Insert_Rol(RolEL objRolEL)
        {
            try
            {
                SqlParameter[] objParameter = new SqlParameter[4];
                objParameter[0] = new SqlParameter("@NOMBRE", objRolEL.NOMBRE_ROL);
                objParameter[1] = new SqlParameter("@DESCRIPCION", objRolEL.DESCRIPCION);
                objParameter[2] = new SqlParameter("@USUCREACION", objRolEL.USUARIO_REGISTRO);
                objParameter[3] = new SqlParameter("@ESTADO", objRolEL.ESTADO_CODIGO);
                int resultado = Convert.ToInt32(SqlHelper.ExecuteScalar("sp_GetGuardarRol", objParameter));
                return resultado.ToString();
            }
            catch (Exception ex)
            {
                return "NOOK";
            }
        }

        public RolEL fn_GetInfo_Rol(RolEL objRolEL)
        {
            try
            {
                RolEL rol = null;
                DataTable dt = new DataTable();
                SqlParameter[] objParameter = new SqlParameter[1];
                objParameter[0] = new SqlParameter("@IDROL", objRolEL.ROL_ID);
                SqlHelper.Fill(dt, "sp_GetRol", objParameter);

                foreach (DataRow item in dt.Rows)
                {
                    rol = new RolEL();
                    rol.ROL_ID = Convert.ToInt32(item[0].ToString());
                    rol.NOMBRE_ROL = item[1].ToString();
                    rol.ESTADO_CODIGO = Convert.ToInt32(item[2].ToString());
                    rol.DESCRIPCION = item[3].ToString();
                }
                return rol;
            }
            catch (Exception ex)
            {
                return null;
            }   
        }

        public string fn_Update_Rol(RolEL objRolEL)
        {
            try
            {
                SqlParameter[] objParameter = new SqlParameter[5];
                objParameter[0] = new SqlParameter("@NOMBRE", objRolEL.NOMBRE_ROL);
                objParameter[1] = new SqlParameter("@DESCRIPCION", objRolEL.DESCRIPCION);
                objParameter[2] = new SqlParameter("@ESTADO", objRolEL.ESTADO_CODIGO);
                objParameter[3] = new SqlParameter("@USUCREACION", objRolEL.USUARIO_REGISTRO);
                objParameter[4] = new SqlParameter("@ROLID", objRolEL.ROL_ID);
                int resultado = Convert.ToInt32(SqlHelper.ExecuteScalar("sp_GetActualizarRol", objParameter));
                return resultado.ToString();
            }
            catch (Exception ex)
            {
                return "NOOK";
            }
        }

        public List<OpcionEL> fn_Get_Rol_Opcion_Actual(int intTipoConsulta, RolEL objRolEL)
        {
            try
            {
                List<OpcionEL> lstOpciones = new List<OpcionEL>();
                OpcionEL opcion;
                DataTable dt = new DataTable();
                SqlParameter[] objParameter = new SqlParameter[2];
                objParameter[0] = new SqlParameter("@ROL", objRolEL.ROL_ID);
                objParameter[1] = new SqlParameter("@TIPO", intTipoConsulta);
                SqlHelper.Fill(dt, "sp_GetOpcionxRolTipo", objParameter);
                foreach (DataRow item in dt.Rows)
                {
                    opcion = new OpcionEL();
                    opcion.OPCION_ID = Convert.ToInt32(item[0].ToString());
                    opcion.NOMBRE_OPCION = item[1].ToString();
                    opcion.SIGLA_OPCION = item[2].ToString();
                    opcion.ESTADO = int.Parse(item[3].ToString());
                    lstOpciones.Add(opcion);
                }
                return lstOpciones;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public string fn_Insert_RolOpcion(List<OpcionEL> lstOpciones, RolEL objRolEL)
        {
            try
            {
                fn_Eliminar_RolOpcion(objRolEL);
                foreach (OpcionEL item in lstOpciones)
                {
                    SqlParameter[] objParameter = new SqlParameter[3];
                    objParameter[0] = new SqlParameter("@IDROL", objRolEL.ROL_ID);
                    objParameter[1] = new SqlParameter("@IDOPCION", item.OPCION_ID);
                    objParameter[2] = new SqlParameter("@USUCREACION", objRolEL.USUARIO_REGISTRO);
                    Convert.ToInt32(SqlHelper.ExecuteScalar("sp_GetGuardarOpcionRol", objParameter));
                }
                return "1";
            }
            catch (Exception ex)
            {
                return "NOOK";
            }
        }

        public string fn_Eliminar_RolOpcion(RolEL objRolEL)
        {
            try
            {
                SqlParameter[] objParameter = new SqlParameter[1];
                objParameter[0] = new SqlParameter("@IDROL", objRolEL.ROL_ID);
                int resultado = Convert.ToInt32(SqlHelper.ExecuteScalar("sp_GetEliminarRolOpcion", objParameter));
                return resultado.ToString();
            }
            catch (Exception ex)
            {
                return "NOOK";
            }
        }
    }
}
