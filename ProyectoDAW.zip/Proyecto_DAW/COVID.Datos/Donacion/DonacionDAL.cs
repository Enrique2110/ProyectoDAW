﻿using COVID.Datos.Helpers;
using COVID.Entidades;
using COVID.Entidades.Listado;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Datos.Donacion
{
    public class DonacionDAL:IDonacionDAL
    {
        public List<DonacionListaEL> fn_Get_Donacion(DonacionEL objDonacionEL)
        {
            try
            {
                List<DonacionListaEL> lstDonaciones = new List<DonacionListaEL>();
                DonacionListaEL donacion;
                DataTable dt = new DataTable();
                SqlParameter[] objParameter = new SqlParameter[2];
                objParameter[0] = new SqlParameter("@TIPODONACION", objDonacionEL.TIPO_DONACION_ID);
                objParameter[1] = new SqlParameter("@ESTADO", objDonacionEL.ESTADO_DONACION_ID);
                SqlHelper.Fill(dt, "sp_GetListaDonacion", objParameter);

                foreach (DataRow item in dt.Rows)
                {
                    donacion = new DonacionListaEL();
                    donacion.DONACION_ID = Convert.ToInt32(item[0].ToString());
                    donacion.PATERNO_DONANTE = item[1].ToString();
                    donacion.MATERNO_DONANTE = item[2].ToString();
                    donacion.NOMBRE_DONANTE = item[3].ToString();
                    donacion.TIPO_DONACION = item[4].ToString();
                    donacion.ESTADO_DONACION = item[5].ToString();
                    donacion.CANTIDAD = Convert.ToDecimal(item[6].ToString());
                    donacion.DESCRIPCION_DONACION = item[7].ToString();
                    donacion.FECHA_REGISTRO = item[8].ToString();
                    lstDonaciones.Add(donacion);
                }
                return lstDonaciones;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public string fn_Insert_Donacion(DonacionEL objDonacionEL)
        {
            try
            {
                SqlParameter[] objParameter = new SqlParameter[11];
                objParameter[0] = new SqlParameter("@TIPO_DOCUMENTO", objDonacionEL.TIPO_DOCUMENTO_ID);
                objParameter[1] = new SqlParameter("@NRO_DOCUMENTO", objDonacionEL.NRO_DOCUMENTO);
                objParameter[2] = new SqlParameter("@PATERNO", objDonacionEL.APELLIDO_PATERNO);
                objParameter[3] = new SqlParameter("@MATERNO", objDonacionEL.APELLIDO_MATERNO);
                objParameter[4] = new SqlParameter("@NOMBRE", objDonacionEL.NOMBRE_DONANTE);
                objParameter[5] = new SqlParameter("@SEXO", objDonacionEL.SEXO_ID);
                objParameter[6] = new SqlParameter("@TIPODONACION", objDonacionEL.TIPO_DONACION_ID);
                objParameter[7] = new SqlParameter("@ESTADO", objDonacionEL.ESTADO_DONACION_ID);
                objParameter[8] = new SqlParameter("@DESCRIPCION", objDonacionEL.DESCRIPCION_DONACION);
                objParameter[9] = new SqlParameter("@CANTIDAD", objDonacionEL.CANTIDAD);
                objParameter[10] = new SqlParameter("@USUARIOCREACION", objDonacionEL.USUARIO_CREACION);
                int resultado = Convert.ToInt32(SqlHelper.ExecuteScalar("sp_GetGuardarDonacion", objParameter));
                return resultado.ToString();
            }
            catch (Exception ex)
            {
                return "NOOK";
            }
        }

        public DonacionEL fn_GetInfo_Donacion(DonacionEL objDonacionEL)
        {
            try
            {
                DonacionEL donacion = null;
                DataTable dt = new DataTable();
                SqlParameter[] objParameter = new SqlParameter[1];
                objParameter[0] = new SqlParameter("@IDDONACION", objDonacionEL.DONACION_ID);
                SqlHelper.Fill(dt, "sp_GetDonacion", objParameter);
                foreach (DataRow item in dt.Rows)
                {
                    donacion = new DonacionEL();
                    donacion.DONACION_ID = Convert.ToInt32(item[0].ToString());
                    donacion.TIPO_DOCUMENTO_ID = Convert.ToInt32(item[1].ToString());
                    donacion.NRO_DOCUMENTO = item[2].ToString();
                    donacion.APELLIDO_PATERNO = item[3].ToString();
                    donacion.APELLIDO_MATERNO = item[4].ToString();
                    donacion.NOMBRE_DONANTE = item[5].ToString();
                    donacion.SEXO_ID = Convert.ToInt32(item[6].ToString());
                    donacion.DESCRIPCION_DONACION = item[7].ToString();
                    donacion.CANTIDAD = Convert.ToDecimal(item[8].ToString());
                    donacion.TIPO_DONACION_ID = Convert.ToInt32(item[9].ToString());
                    donacion.ESTADO_DONACION_ID = Convert.ToInt32(item[10].ToString());
                }
                return donacion;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public string fn_Update_Donacion(DonacionEL objDonacionEL)
        {
            try
            {
                SqlParameter[] objParameter = new SqlParameter[3];
                objParameter[0] = new SqlParameter("@DONACIONID", objDonacionEL.DONACION_ID);
                objParameter[1] = new SqlParameter("@ESTADO", objDonacionEL.ESTADO_DONACION_ID);
                objParameter[2] = new SqlParameter("@USUARIOCREACION", objDonacionEL.USUARIO_CREACION);
                int resultado = Convert.ToInt32(SqlHelper.ExecuteScalar("sp_GetActualizarDonacion", objParameter));
                return resultado.ToString();
            }
            catch (Exception ex)
            {
                return "NOOK";
            }
        }

        public List<DonacionEL> fn_Get_Donaciones_Persona(int intTipoConsulta, PersonaEL objPersonaEL)
        {
            try
            {
                List<DonacionEL> lstDonaciones = new List<DonacionEL>();
                DonacionEL donacion;
                DataTable dt = new DataTable();
                SqlParameter[] objParameter = new SqlParameter[2];
                objParameter[0] = new SqlParameter("@PERSONA", objPersonaEL.PERSONA_ID);
                objParameter[1] = new SqlParameter("@TIPO", intTipoConsulta);
                SqlHelper.Fill(dt, "sp_GetDonacionPersona", objParameter);
                foreach (DataRow item in dt.Rows)
                {
                    donacion = new DonacionEL();
                    donacion.DONACION_ID = Convert.ToInt32(item[0].ToString());
                    donacion.DESCRIPCION_DONACION = item[1].ToString();
                    donacion.CANTIDAD = Decimal.Parse(item[2].ToString());
                    lstDonaciones.Add(donacion);
                }
                return lstDonaciones;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public string fn_Insert_DonacionPersona(List<DonacionEL> lstDonaciones, PersonaEL objPersonaEL)
        {
            try
            {
                fn_Eliminar_DonacionPersona(objPersonaEL);
                foreach (DonacionEL item in lstDonaciones)
                {
                    SqlParameter[] objParameter = new SqlParameter[3];
                    objParameter[0] = new SqlParameter("@IDDONACION", item.DONACION_ID);
                    objParameter[1] = new SqlParameter("@IDPERSONA", objPersonaEL.PERSONA_ID);
                    objParameter[2] = new SqlParameter("@USUCREACION", objPersonaEL.USUARIO_REGISTRO);
                    Convert.ToInt32(SqlHelper.ExecuteScalar("sp_GetGuardarDonacionPersona", objParameter));
                }
                return "1";
            }
            catch (Exception ex)
            {
                return "NOOK";
            }
        }

        public string fn_Eliminar_DonacionPersona(PersonaEL objPersonaEL)
        {
            try
            {
                SqlParameter[] objParameter = new SqlParameter[1];
                objParameter[0] = new SqlParameter("@IDPERSONA", objPersonaEL.PERSONA_ID);
                int resultado = Convert.ToInt32(SqlHelper.ExecuteScalar("sp_GetEliminarDonacionPersona", objParameter));
                return resultado.ToString();
            }
            catch (Exception ex)
            {
                return "NOOK";
            }
        }

        public List<DonacionEL> fn_Get_DonacionesReporte()
        {
            try
            {
                List<DonacionEL> lstDonaciones = new List<DonacionEL>();
                DonacionEL donacion;
                DataTable dt = new DataTable();
                SqlHelper.Fill(dt, "sp_GetDonacionesReporte");

                foreach (DataRow item in dt.Rows)
                {
                    donacion = new DonacionEL();
                    donacion.DESCRIPCION = item[0].ToString();
                    donacion.TOTAL_DONACIONES = Convert.ToInt32(item[1].ToString());
                    lstDonaciones.Add(donacion);
                }
                return lstDonaciones;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
