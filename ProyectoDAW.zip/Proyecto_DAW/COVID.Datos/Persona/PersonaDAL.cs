﻿using COVID.Datos.Helpers;
using COVID.Entidades;
using COVID.Entidades.Listado;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Datos.Persona
{
    public class PersonaDAL:IPersonaDAL
    {
        public List<PersonaPobreListaEL> fn_Get_Persona(PersonaEL objPersonaEL)
        {
            try
            {
                List<PersonaPobreListaEL> lstPersonas = new List<PersonaPobreListaEL>();
                PersonaPobreListaEL persona;
                DataTable dt = new DataTable();
                SqlParameter[] objParameter = new SqlParameter[2];
                objParameter[0] = new SqlParameter("@DOCUMENTO", objPersonaEL.DOCUMENTO);
                objParameter[1] = new SqlParameter("@NOMBRES", objPersonaEL.NOMBRE_COMPLETO);
                SqlHelper.Fill(dt, "sp_GetListaPersonas", objParameter);

                foreach (DataRow item in dt.Rows)
                {
                    persona = new PersonaPobreListaEL();
                    persona.PERSONA_ID = Convert.ToInt32(item[0].ToString());
                    persona.TIPO_DOCUMENTO = item[1].ToString();
                    persona.NRO_DOCUMENTO = item[2].ToString();
                    persona.PATERNO = item[3].ToString();
                    persona.MATERNO = item[4].ToString();
                    persona.NOMBRES = item[5].ToString();
                    persona.SEXO = item[6].ToString();
                    persona.DIRECCION = item[7].ToString();
                    lstPersonas.Add(persona);
                }
                return lstPersonas;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public string fn_Insert_Persona(PersonaEL objPersonaEL)
        {
            try
            {
                SqlParameter[] objParameter = new SqlParameter[10];
                objParameter[0] = new SqlParameter("@TIPODOCUMENTO", objPersonaEL.TIPO_DOCUMENTO_CODIGO);
                objParameter[1] = new SqlParameter("@NRODOCUMENTO", objPersonaEL.DOCUMENTO);
                objParameter[2] = new SqlParameter("@PATERNO", objPersonaEL.APELLIDO_PATERNO);
                objParameter[3] = new SqlParameter("@MATERNO", objPersonaEL.APELLIDO_MATERNO);
                objParameter[4] = new SqlParameter("@NOMBRES", objPersonaEL.NOMBRE);
                objParameter[5] = new SqlParameter("@TELEFONO", objPersonaEL.TELEFONO);
                objParameter[6] = new SqlParameter("@SEXO", objPersonaEL.SEXO_CODIGO);
                objParameter[7] = new SqlParameter("@FECHANACIMIENTO", objPersonaEL.FECHA_NACIMIENTO);
                objParameter[8] = new SqlParameter("@DOMICILIO", objPersonaEL.DOMICILIO);
                objParameter[9] = new SqlParameter("@USUARIOCREACION", objPersonaEL.USUARIO_REGISTRO);
                int resultado = Convert.ToInt32(SqlHelper.ExecuteScalar("sp_GetGuardarPersonaPobre", objParameter));
                return resultado.ToString();
            }
            catch (Exception ex)
            {
                return "NOOK";
            }
        }

        public string fn_Update_PersonaFoto(PersonaEL objPersonaEL)
        {
            try
            {
                SqlParameter[] objParameter = new SqlParameter[2];
                objParameter[0] = new SqlParameter("@FOTO", objPersonaEL.FOTO);
                objParameter[1] = new SqlParameter("@USUARIOCREACION", objPersonaEL.USUARIO_REGISTRO);
                int resultado = Convert.ToInt32(SqlHelper.ExecuteScalar("sp_UpdFotoPersona", objParameter));
                return resultado.ToString();
            }
            catch (Exception ex)
            {
                return "NOOK";
            }
        }

        public PersonaEL fn_GetInfo_Persona(PersonaEL objPersonaEL)
        {
            try
            {
                PersonaEL persona = null;
                DataTable dt = new DataTable();
                SqlParameter[] objParameter = new SqlParameter[1];
                objParameter[0] = new SqlParameter("@IDPERSONA", objPersonaEL.PERSONA_ID);
                SqlHelper.Fill(dt, "sp_GetPersona", objParameter);

                foreach (DataRow item in dt.Rows)
                {
                    persona = new PersonaEL();
                    persona.PERSONA_ID = Convert.ToInt32(item[0].ToString());
                    persona.TIPO_DOCUMENTO_CODIGO = Convert.ToInt32(item[1].ToString());
                    persona.DOCUMENTO = item[2].ToString();
                    persona.APELLIDO_PATERNO = item[3].ToString();
                    persona.APELLIDO_MATERNO = item[4].ToString();
                    persona.NOMBRE = item[5].ToString();
                    persona.SEXO_CODIGO = Convert.ToInt32(item[6].ToString());
                    persona.TELEFONO = item[7].ToString();
                    persona.DOMICILIO = item[8].ToString();
                    persona.FECHA_NACIMIENTO = item[9].ToString();
                    persona.FOTO = item[10].ToString();
                }
                return persona;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
