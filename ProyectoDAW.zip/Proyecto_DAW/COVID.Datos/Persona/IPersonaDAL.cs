﻿using COVID.Entidades;
using COVID.Entidades.Listado;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Datos.Persona
{
    public interface IPersonaDAL
    {
        List<PersonaPobreListaEL> fn_Get_Persona(PersonaEL objPersonaEL);
        string fn_Insert_Persona(PersonaEL objPersonaEL);
        string fn_Update_PersonaFoto(PersonaEL objPersonaEL);
        PersonaEL fn_GetInfo_Persona(PersonaEL objPersonaEL);
    }
}
