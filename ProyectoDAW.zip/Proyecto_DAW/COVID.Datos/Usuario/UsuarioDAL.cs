﻿using COVID.Datos.Helpers;
using COVID.Entidades;
using COVID.Entidades.Listado;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Datos.Usuario
{
    public class UsuarioDAL: IUsuarioDAL
    {
        public List<UsuarioListaEL> fn_Get_Usuario(UsuarioEL objUsuarioEL)
        {
            try
            {
                List<UsuarioListaEL> lstUsuarios = new List<UsuarioListaEL>();
                UsuarioListaEL usuario;
                DataTable dt = new DataTable();
                SqlParameter[] objParameter = new SqlParameter[3];
                objParameter[0] = new SqlParameter("@LOGIN", objUsuarioEL.LOGIN);
                objParameter[1] = new SqlParameter("@DOCUMENTO", objUsuarioEL.DOCUMENTO);
                objParameter[2] = new SqlParameter("@NOMBRES", objUsuarioEL.NOMBRE_COMPLETO);
                SqlHelper.Fill(dt, "sp_GetListaUsuarios", objParameter);

                foreach (DataRow item in dt.Rows)
                {
                    usuario = new UsuarioListaEL();
                    usuario.USUARIO_ID = Convert.ToInt32(item[0].ToString());
                    usuario.LOGIN = item[1].ToString();
                    usuario.NOMBRE_COMPLETO = item[7].ToString() + " " + item[5].ToString() + " " + item[6].ToString();
                    usuario.ROL_DESCRIPCION = item[8].ToString();
                    usuario.ESTADO_DESCRIPCION = item[10].ToString();
                    usuario.DOCUMENTO = item[13].ToString() + ':' + item[12].ToString();
                    lstUsuarios.Add(usuario);
                }
                return lstUsuarios;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public string fn_Insert_Usuario(UsuarioEL objUsuarioEL)
        {
            try
            {
                //Registrar nuevo cupon
                SqlParameter[] objParameter = new SqlParameter[13];
                objParameter[0] = new SqlParameter("@PATERNO", objUsuarioEL.APELLIDO_PATERNO);
                objParameter[1] = new SqlParameter("@MATERNO", objUsuarioEL.APELLIDO_MATERNO);
                objParameter[2] = new SqlParameter("@NOMBRES", objUsuarioEL.NOMBRE);
                objParameter[3] = new SqlParameter("@TIPODOCUMENTO", objUsuarioEL.TIPO_DOCUMENTO_CODIGO);
                objParameter[4] = new SqlParameter("@NRODOCUMENTO", objUsuarioEL.DOCUMENTO);
                objParameter[5] = new SqlParameter("@TELEFONO", objUsuarioEL.TELEFONO);
                objParameter[6] = new SqlParameter("@CELULAR", objUsuarioEL.CELULAR);
                objParameter[7] = new SqlParameter("@CORREO", objUsuarioEL.EMAIL);
                objParameter[8] = new SqlParameter("@USUCREACION", objUsuarioEL.USUARIO_REGISTRO);
                objParameter[9] = new SqlParameter("@LOGIN", objUsuarioEL.LOGIN);
                objParameter[10] = new SqlParameter("@ROL", objUsuarioEL.ROL_CODIGO);
                objParameter[11] = new SqlParameter("@CONTRASENA", objUsuarioEL.CLAVE);
                objParameter[12] = new SqlParameter("@ESTADO_USUARIO", objUsuarioEL.ESTADO_CODIGO);
                int resultado = Convert.ToInt32(SqlHelper.ExecuteScalar("sp_GetGuardarUsuario", objParameter));
                return resultado.ToString();
            }
            catch (Exception ex)
            {
                return "NOOK";
            }
        }

        public UsuarioEL fn_GetInfo_Usuario(UsuarioEL objUsuarioEL)
        {
            try
            {
                UsuarioEL usuario=null;
                DataTable dt = new DataTable();
                SqlParameter[] objParameter = new SqlParameter[1];
                objParameter[0] = new SqlParameter("@IDUSUARIO", objUsuarioEL.USUARIO_ID);
                SqlHelper.Fill(dt, "sp_GetUsuario", objParameter);

                foreach (DataRow item in dt.Rows)
                {
                    usuario = new UsuarioEL();
                    usuario.USUARIO_ID = Convert.ToInt32(item[0].ToString());
                    usuario.LOGIN = item[1].ToString();
                    usuario.ROL_CODIGO = int.Parse(item[2].ToString());
                    usuario.CLAVE = item[4].ToString();
                    usuario.APELLIDO_PATERNO = item[5].ToString();
                    usuario.APELLIDO_MATERNO = item[6].ToString();
                    usuario.NOMBRE = item[7].ToString();
                    usuario.ESTADO_CODIGO = int.Parse(item[9].ToString());
                    usuario.TIPO_DOCUMENTO_CODIGO = int.Parse(item[14].ToString());
                    usuario.DOCUMENTO = item[12].ToString();
                    usuario.EMAIL = item[15].ToString();
                    usuario.CELULAR = item[16].ToString();
                    usuario.TELEFONO = item[17].ToString();
                    usuario.AVATAR = item[18].ToString();
                }
                return usuario;
            }
            catch (Exception ex)
            {
                return null;
            }   
        }

        public string fn_Update_Usuario(UsuarioEL objUsuarioEL)
        {
            try
            {
                //Registrar nuevo cupon
                SqlParameter[] objParameter = new SqlParameter[14];
                objParameter[0] = new SqlParameter("@PATERNO", objUsuarioEL.APELLIDO_PATERNO);
                objParameter[1] = new SqlParameter("@MATERNO", objUsuarioEL.APELLIDO_MATERNO);
                objParameter[2] = new SqlParameter("@NOMBRES", objUsuarioEL.NOMBRE);
                objParameter[3] = new SqlParameter("@TIPODOCUMENTO", objUsuarioEL.TIPO_DOCUMENTO_CODIGO);
                objParameter[4] = new SqlParameter("@NRODOCUMENTO", objUsuarioEL.DOCUMENTO);
                objParameter[5] = new SqlParameter("@TELEFONO", objUsuarioEL.TELEFONO);
                objParameter[6] = new SqlParameter("@CELULAR", objUsuarioEL.CELULAR);
                objParameter[7] = new SqlParameter("@CORREO", objUsuarioEL.EMAIL);
                objParameter[8] = new SqlParameter("@USUCREACION", objUsuarioEL.USUARIO_REGISTRO);
                objParameter[9] = new SqlParameter("@LOGIN", objUsuarioEL.LOGIN);
                objParameter[10] = new SqlParameter("@ROL", objUsuarioEL.ROL_CODIGO);
                objParameter[11] = new SqlParameter("@CONTRASENA", objUsuarioEL.CLAVE);
                objParameter[12] = new SqlParameter("@ESTADO_USUARIO", objUsuarioEL.ESTADO_CODIGO);
                objParameter[13] = new SqlParameter("@USUARIOID", objUsuarioEL.USUARIO_ID);
                int resultado = Convert.ToInt32(SqlHelper.ExecuteScalar("sp_GetActualizarUsuario", objParameter));
                return resultado.ToString();
            }
            catch (Exception ex)
            {
                return "NOOK";
            }
        }

        public string fn_Update_Clave(UsuarioEL objUsuarioEL)
        {
            try
            {
                SqlParameter[] objParameter = new SqlParameter[2];
                objParameter[0] = new SqlParameter("@USUCREACION", objUsuarioEL.USUARIO_REGISTRO);
                objParameter[1] = new SqlParameter("@CONTRASENA", objUsuarioEL.CLAVE);
                int resultado = Convert.ToInt32(SqlHelper.ExecuteScalar("sp_GetActualizarClave", objParameter));
                return resultado.ToString();
            }
            catch (Exception ex)
            {
                return "NOOK";
            }
        }

        public string fn_Update_GenerarClave(UsuarioEL objUsuarioEL)
        {
            try
            {
                SqlParameter[] objParameter = new SqlParameter[2];
                objParameter[0] = new SqlParameter("@CORREO", objUsuarioEL.EMAIL);
                objParameter[1] = new SqlParameter("@CONTRASENA", objUsuarioEL.CLAVE);
                int resultado = Convert.ToInt32(SqlHelper.ExecuteScalar("sp_UpdGenerarClave", objParameter));
                return resultado.ToString();
            }
            catch (Exception ex)
            {
                return "NOOK";
            }
        }

        public string fn_Update_UsuarioAvatar(UsuarioEL objUsuarioEL)
        {
            try
            {
                SqlParameter[] objParameter = new SqlParameter[3];
                objParameter[0] = new SqlParameter("@LOGIN", objUsuarioEL.LOGIN);
                objParameter[1] = new SqlParameter("@AVATAR", objUsuarioEL.AVATAR);
                objParameter[2] = new SqlParameter("@USUCREACION", objUsuarioEL.USUARIO_REGISTRO);
                int resultado = Convert.ToInt32(SqlHelper.ExecuteScalar("sp_UpdUsuarioAvatar", objParameter));
                return resultado.ToString();
            }
            catch (Exception ex)
            {
                return "NOOK";
            }
        }

        public UsuarioActualEL fn_GetInfo_UsuarioCorreo(string strCorreo)
        {
            try
            {
                UsuarioActualEL usuario = null;
                DataTable dt = new DataTable();
                SqlParameter[] objParameter = new SqlParameter[1];
                objParameter[0] = new SqlParameter("@CORREO", strCorreo);
                SqlHelper.Fill(dt, "sp_GetUsuarioCorreo", objParameter);

                foreach (DataRow item in dt.Rows)
                {
                    usuario = new UsuarioActualEL();
                    usuario.USUARIO_ID = Convert.ToInt32(item[0].ToString());
                    usuario.LOGIN_USUARIO = item[1].ToString();
                    usuario.ROL_ID = Convert.ToInt32(item[2].ToString());
                    usuario.PERSONA_ID = Convert.ToInt32(item[3].ToString());
                    usuario.LOGIN_PWD = item[4].ToString();
                    usuario.APELLIDO_PATERNO = item[5].ToString();
                    usuario.APELLIDO_MATERNO = item[6].ToString();
                    usuario.NOMBRE = item[7].ToString();
                    usuario.NOMBRE_ROL = item[8].ToString();
                    usuario.AVATAR = item[9].ToString();
                }
                return usuario;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public UsuarioEL GetUsuarioAdministrador()
        {
            try
            {
                UsuarioEL usuario = null;
                DataTable dt = new DataTable();
                SqlHelper.Fill(dt, "sp_GetUsuarioAdministrador");

                foreach (DataRow item in dt.Rows)
                {
                    usuario = new UsuarioEL();
                    usuario.EMAIL = item[15].ToString();
                    usuario.APELLIDO_PATERNO = item[5].ToString();
                    usuario.APELLIDO_MATERNO = item[6].ToString();
                    usuario.NOMBRE = item[7].ToString();
                }
                return usuario;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
