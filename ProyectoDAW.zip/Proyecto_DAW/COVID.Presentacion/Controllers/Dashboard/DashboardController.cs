﻿using COVID.Entidades;
using COVID.Negocio.Donacion;
using COVID.Negocio.Triaje;
using COVID.Presentacion.General;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace COVID.Presentacion.Controllers.Dashboard
{
    public class DashboardController : Controller
    {
        //
        // GET: /Dashboard/

        public ActionResult Dashboard()
        {
            Session.Abandon();
            Response.Cache.SetCacheability(HttpCacheability.NoCache);  // HTTP 1.1.
            var vLstTriaje = new TriajeEL();
            ITriajeBL objTriajeBL = new TriajeBL();
            TriajeEL objTriajeEL = new TriajeEL();
            vLstTriaje = objTriajeBL.fn_Get_TotalTriajes();
            ViewBag.TotalTriaje = vLstTriaje.TOTAL_TRIAJE;

            objTriajeEL.RESULTADO_ID = Convert.ToInt32(ListaValores.RESULTADO_POSITIVO.Value);
            vLstTriaje = objTriajeBL.fn_Get_TotalTriajeResultado(objTriajeEL);
            ViewBag.Positivos = vLstTriaje.TOTAL_TRIAJE;

            objTriajeEL.RESULTADO_ID = Convert.ToInt32(ListaValores.RESULTADO_NEGATIVO.Value);
            vLstTriaje = objTriajeBL.fn_Get_TotalTriajeResultado(objTriajeEL);
            ViewBag.Negativos = vLstTriaje.TOTAL_TRIAJE;


            ///vLstTicket = objTicketBL.fn_Get_PromedioTicket(1);//Promedio Asignados
            //ViewBag.MediaAsignados = vLstTicket.PROMEDIO;

            //vLstTicket = objTicketBL.fn_Get_PromedioTicket(2);//Promedio Atención
            //ViewBag.MediaAtencion = vLstTicket.PROMEDIO;

            //vLstTicket = objTicketBL.fn_Get_PromedioTicket(3);//Promedio Conformidad
            //ViewBag.MediaConformidad = vLstTicket.PROMEDIO;

            return View();
        }

        [HttpPost]
        public JsonResult graficoPie()
        {
            List<object> chartData = new List<object>();
            ITriajeBL objTriajeBL = new TriajeBL();
            var vLstTriaje = new List<TriajeEL>();
            vLstTriaje = objTriajeBL.fn_Get_TriajeSexo();
            chartData.Add(new object[]
                        {
                            "Sexo", "Total"
                        });

            foreach (var item in vLstTriaje)
            {
                chartData.Add(new object[]
                {
                    item.DESCRIPCION,item.TOTAL_TRIAJE 
                });
            }
            return Json(chartData);
        }

        [HttpPost]
        public JsonResult graficoPieDonaciones()
        {
            List<object> chartData = new List<object>();
            IDonacionBL objDonacionBL = new DonacionBL();
            var vLstDonacion = new List<DonacionEL>();
            vLstDonacion = objDonacionBL.fn_Get_DonacionesReporte();
            chartData.Add(new object[]
                        {
                            "Estado Donación", "Total"
                        });

            foreach (var item in vLstDonacion)
            {
                chartData.Add(new object[]
                {
                    item.DESCRIPCION,item.TOTAL_DONACIONES 
                });
            }
            return Json(chartData);
        }

        [HttpPost]
        public JsonResult graficoBarraTipoPruebas()
        {
            List<object> chartData = new List<object>();
            ITriajeBL objTriajeBL = new TriajeBL();
            var vLstTriaje = new List<TriajeEL>();
            vLstTriaje = objTriajeBL.fn_Get_TriajeTipoPrueba();
            chartData.Add(new object[]
                        {
                            "Tipo Prueba", "Total"
                        });

            foreach (var item in vLstTriaje)
            {
                chartData.Add(new object[]
                {
                    item.TIPO_PRUEBA,item.TOTAL_TRIAJE
                });
            }
            return Json(chartData);
        }

        public ActionResult Index()
        {
            return View();
        }

    }
}
