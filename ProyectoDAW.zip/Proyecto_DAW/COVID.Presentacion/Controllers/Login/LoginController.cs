﻿using COVID.Entidades;
using COVID.Negocio.Seguridad;
using COVID.Presentacion.General;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace COVID.Presentacion.Controllers.Login
{
    public class LoginController : Controller
    {
        #region "Refrescar Cache"
        public void RefrescarCache()
        {
            ViewData["LOGUEO_NOMBRE_COMPLETO"] = SesionActual.Current.NOMBRE_COMPLETO;
            ViewData["LOGUEO_PERFIL"] = SesionActual.Current.PERFIL;
            ViewData["OPCIONES_USUARIO"] = SesionActual.Current.OPCIONES_USUARIO;
            ViewData["NOMBRE_SISTEMA"] = SesionActual.Current.APLICACION;
            ViewData["AVATAR"] = SesionActual.Current.AVATAR;
            Response.Cache.AppendCacheExtension("no-store, must-revalidate");
            Response.AppendHeader("Pragma", "no-cache"); // HTTP 1.0.
            Response.AppendHeader("Expires", "0"); // Proxies.
        }
        #endregion

        //
        // GET: /Login/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult LoginEstandar()
        {
            RefrescarCache();
            Session.Abandon();
            return View();
        }

        [HttpPost]
        public ActionResult AutenticacionUsuario(string strLogin, string strPwd, string strIP, string strBrowser, string strFlgCambioClave)
        {
            string strRespuesta = string.Empty;
            string strUsuario = strLogin.ToUpper();
            string strClaveEncrypt = Encriptador.Encriptar(strPwd);

            ISeguridadBL objBL = new SeguridadBL();
            UsuarioActualEL objUsuarioEL = new UsuarioActualEL();
            objUsuarioEL = objBL.GetUsuarioLogin(strUsuario);
            if (objUsuarioEL != null)
            {
                if (objUsuarioEL.LOGIN_PWD.Equals(strClaveEncrypt))
                {
                    SesionActual.Current.USUARIO_ID = objUsuarioEL.USUARIO_ID;
                    SesionActual.Current.NOMBRE_COMPLETO = string.Format("{0} {1}", objUsuarioEL.NOMBRE,
                        objUsuarioEL.APELLIDO_PATERNO);
                    SesionActual.Current.USUARIO_LOGIN = strLogin.ToUpper();
                    SesionActual.Current.PERFIL = objUsuarioEL.NOMBRE_ROL;
                    SesionActual.Current.AVATAR = objUsuarioEL.AVATAR;
                    ViewData["LOGUEO_NOMBRE_COMPLETO"] = SesionActual.Current.NOMBRE_COMPLETO;
                    ViewData["LOGUEO_PERFIL"] = SesionActual.Current.PERFIL;
                    // OBTENER ACCESOS POR EL PERFIL 
                    List<OpcionEL> lstOpciones = objBL.GetOpcionesRol(objUsuarioEL.ROL_ID);
                    var json = JsonConvert.SerializeObject(lstOpciones);
                    SesionActual.Current.OPCIONES_USUARIO = json;
                    ViewData["OPCIONES_USUARIO"] = SesionActual.Current.OPCIONES_USUARIO;
                    ViewData["AVATAR"] = SesionActual.Current.AVATAR;
                    Session["AVATAR"] = SesionActual.Current.AVATAR;
                    // VARIABLES DEL SISTEMA
                    SesionActual.Current.CANTIDAD_FILAS_DATATABLE = "10";
                    /*Indicador de Exito*/
                    return Json(new { strRespuesta = 1 }, JsonRequestBehavior.AllowGet);
                }
                /*Clave incorrecta*/
                return Json(new { strRespuesta = 2 }, JsonRequestBehavior.AllowGet);
            }
            else
            {

                return Json(new { strRespuesta = 3 }, JsonRequestBehavior.AllowGet);
            }
        }

    }
}
