﻿using COVID.Entidades;
using COVID.Entidades.Listado;
using COVID.Negocio.Donacion;
using COVID.Negocio.Persona;
using COVID.Presentacion.Controllers.Parametro;
using COVID.Presentacion.General;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace COVID.Presentacion.Controllers.Donacion
{
    public class DonacionController : Controller
    {
        #region "Refrescar Cache"
        [SessionExpireFilter]
        public void RefrescarCache()
        {
            if (SesionActual.Current.PERFIL == "")
            {
                Session.Abandon();
                Response.Redirect("~");
            }
            else
            {
                ViewData["LOGUEO_NOMBRE_COMPLETO"] = SesionActual.Current.NOMBRE_COMPLETO;
                ViewData["LOGUEO_PERFIL"] = SesionActual.Current.PERFIL;
                ViewData["USUARIO_CHAT"] = SesionActual.Current.USUARIO_LOGIN;
                ViewData["OPCIONES_USUARIO"] = SesionActual.Current.OPCIONES_USUARIO;
                Response.Cache.AppendCacheExtension("no-store, must-revalidate");
                Response.AppendHeader("Pragma", "no-cache"); // HTTP 1.0.
                Response.AppendHeader("Expires", "0"); // Proxies.
            }
        }
        #endregion

        [SessionExpireFilter]
        public ActionResult Listar()
        {
            RefrescarCache();
            Response.Cache.SetCacheability(HttpCacheability.NoCache);  // HTTP 1.1.
            ViewBag.TipoDonacion = new ParametroController().SelectListValoresXGrupo_Todos(int.Parse(ListaValores.TIPO_DONACION.Value));
            ViewBag.EstadoDonacion = new ParametroController().SelectListValoresXGrupo_Todos(int.Parse(ListaValores.ESTADO_DONACION.Value));
            return View();
        }

        [HttpGet]
        public JsonResult Leer_Donacion(int intTipoDonacion, int intEstado)
        {
            var vLstDonacion= new List<DonacionListaEL>();
            IDonacionBL objDonacionBL = new DonacionBL();
            DonacionEL objDonacionEL = new DonacionEL();
            objDonacionEL.TIPO_DONACION_ID = intTipoDonacion;
            objDonacionEL.ESTADO_DONACION_ID = intEstado;
            vLstDonacion = objDonacionBL.fn_Get_Donacion(objDonacionEL);
            Session[Constantes.LISTA.Value] = null;
            Session[Constantes.LISTA.Value] = vLstDonacion;
            return Json(vLstDonacion, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Index()
        {
            return View();
        }

        [SessionExpireFilter]
        public ActionResult Crear()
        {
            RefrescarCache();
            ViewBag.TipoDonacion = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.TIPO_DONACION.Value));
            ViewBag.EstadoDonacion = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.ESTADO_DONACION.Value));
            ViewBag.TipoDocumento = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.TIPO_DOCUMENTO.Value));
            ViewBag.Sexo = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.SEXO.Value));
            return View();
        }

        [HttpPost, ValidateInput(false)]
        [SessionExpireFilter]
        public ActionResult Guardar()
        {
            try
            {
                string strRespuesta = string.Empty;
                IDonacionBL objDonacionBL = new DonacionBL();
                DonacionEL objDonacionEL = new DonacionEL();
                objDonacionEL.TIPO_DOCUMENTO_ID = Convert.ToInt32(Request.Form["intTipoDocumento"].ToString());
                objDonacionEL.NRO_DOCUMENTO = Request.Form["strNroDocumento"].ToString();
                objDonacionEL.APELLIDO_PATERNO = Request.Form["strApellidoPaterno"].ToString().ToUpper();
                objDonacionEL.APELLIDO_MATERNO = Request.Form["strApellidoMaterno"].ToString().ToUpper();
                objDonacionEL.NOMBRE_DONANTE = Request.Form["strNombres"].ToString().ToUpper();
                objDonacionEL.SEXO_ID = Convert.ToInt32(Request.Form["intSexo"].ToString());
                objDonacionEL.TIPO_DONACION_ID = Convert.ToInt32(Request.Form["intTipoDonacion"].ToString());
                objDonacionEL.ESTADO_DONACION_ID = Convert.ToInt32(Request.Form["intEstadoDonacion"].ToString());
                objDonacionEL.DESCRIPCION_DONACION = Request.Form["strDescripcion"].ToString().ToUpper();
                objDonacionEL.CANTIDAD = Convert.ToDecimal(Request.Form["intCantidad"].ToString());
                objDonacionEL.USUARIO_CREACION = SesionActual.Current.USUARIO_LOGIN;
                strRespuesta = objDonacionBL.fn_Insert_Donacion(objDonacionEL);
                return Json(new { strRespuesta = (int.Parse(strRespuesta) > 0 ? "1" : strRespuesta) }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json("Ocurrio un error. Detalle de error " + ex.Message);
            }
        }

        [SessionExpireFilter]
        public ActionResult Ver(int strIdDonacion)
        {
            RefrescarCache();
            var vdonacion = new DonacionEL();
            IDonacionBL objDonacionBL = new DonacionBL();
            DonacionEL objDonacionEL = new DonacionEL();
            objDonacionEL.DONACION_ID = strIdDonacion;
            ViewBag.TipoDonacion = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.TIPO_DONACION.Value));
            ViewBag.EstadoDonacion = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.ESTADO_DONACION.Value));
            ViewBag.TipoDocumento = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.TIPO_DOCUMENTO.Value));
            ViewBag.Sexo = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.SEXO.Value));
            vdonacion = objDonacionBL.fn_GetInfo_Donacion(objDonacionEL);
            return View("Ver", vdonacion);
        }

        [HttpPost]
        [SessionExpireFilter]
        public ActionResult Modificar()
        {
            string strRespuesta = string.Empty;
            IDonacionBL objDonacionBL = new DonacionBL();
            DonacionEL objDonacionEL = new DonacionEL();
            objDonacionEL.DONACION_ID = Convert.ToInt32(Request.Form["intDonacionId"].ToString());
            objDonacionEL.ESTADO_DONACION_ID = Convert.ToInt32(Request.Form["intEstadoDonacion"].ToString());
            objDonacionEL.USUARIO_CREACION = SesionActual.Current.USUARIO_LOGIN;
            strRespuesta = objDonacionBL.fn_Update_Donacion(objDonacionEL);
            return Json(new { strRespuesta = strRespuesta }, JsonRequestBehavior.AllowGet);
        }

        [SessionExpireFilter]
        public ActionResult Editar(int strIdDonacion)
        {
            RefrescarCache();
            var vdonacion = new DonacionEL();
            IDonacionBL objDonacionBL = new DonacionBL();
            DonacionEL objDonacionEL = new DonacionEL();
            objDonacionEL.DONACION_ID = strIdDonacion;
            ViewBag.TipoDonacion = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.TIPO_DONACION.Value));
            ViewBag.EstadoDonacion = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.ESTADO_DONACION.Value));
            ViewBag.TipoDocumento = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.TIPO_DOCUMENTO.Value));
            ViewBag.Sexo = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.SEXO.Value));
            vdonacion = objDonacionBL.fn_GetInfo_Donacion(objDonacionEL);
            return View("Editar", vdonacion);
        }

        [SessionExpireFilter]
        public ActionResult ListarPersonaPobre()
        {
            RefrescarCache();
            return View();
        }

        [HttpGet]
        public JsonResult Leer_Persona_Pobre(string strNroDocumento, string strApellidosNombres)
        {
            var vLstPersona = new List<PersonaPobreListaEL>();
            IPersonaBL objPersonaBL = new PersonaBL();
            PersonaEL objPersonaEL = new PersonaEL();
            objPersonaEL.DOCUMENTO = strNroDocumento;
            objPersonaEL.NOMBRE_COMPLETO = strApellidosNombres;
            vLstPersona = objPersonaBL.fn_Get_Persona(objPersonaEL);
            Session[Constantes.LISTA.Value] = null;
            Session[Constantes.LISTA.Value] = vLstPersona;
            return Json(vLstPersona, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [SessionExpireFilter]
        public ActionResult GuardarPersona()
        {
            if (Request.Files.Count > 0)
            {
                string strRespuesta = string.Empty;
                IPersonaBL objPersonaBL = new PersonaBL();
                PersonaEL objPersonaEL = new PersonaEL();
                objPersonaEL.TIPO_DOCUMENTO_CODIGO = Convert.ToInt32(Request.Form["strTipoDocumento"].ToString());
                objPersonaEL.DOCUMENTO = Request.Form["strNroDocumento"].ToString().ToUpper();
                objPersonaEL.APELLIDO_PATERNO = Request.Form["strApellidoPaterno"].ToString().ToUpper();
                objPersonaEL.APELLIDO_MATERNO = Request.Form["strApellidoMaterno"].ToString();
                objPersonaEL.NOMBRE = Request.Form["strNombres"].ToString();
                objPersonaEL.TELEFONO = Request.Form["strTelefono"].ToString().ToUpper();
                objPersonaEL.SEXO_CODIGO = Convert.ToInt32(Request.Form["strSexo"].ToString());
                objPersonaEL.FECHA_NACIMIENTO = Request.Form["strFechaNacimiento"].ToString().ToUpper();
                objPersonaEL.FECHA_NACIMIENTO = objPersonaEL.FECHA_NACIMIENTO.Substring(3, 2) + "-" + objPersonaEL.FECHA_NACIMIENTO.Substring(0, 2) + "-" + objPersonaEL.FECHA_NACIMIENTO.Substring(6, 4);
                objPersonaEL.DOMICILIO = Request.Form["strDomicilio"].ToString().ToUpper();
                objPersonaEL.USUARIO_REGISTRO = SesionActual.Current.USUARIO_LOGIN;
                strRespuesta = objPersonaBL.fn_Insert_Persona(objPersonaEL);
                /*Guardamos el Avatar*/
                HttpFileCollectionBase files = Request.Files;
                for (int i = 0; i < files.Count; i++)
                {
                    HttpPostedFileBase file = files[i];
                    string fname;
                    // Checking for Internet Explorer  
                    if (Request.Browser.Browser.ToUpper() == "IE" || Request.Browser.Browser.ToUpper() == "INTERNETEXPLORER")
                    {
                        string[] testfiles = file.FileName.Split(new char[] { '\\' });
                        fname = testfiles[testfiles.Length - 1];
                    }
                    else
                    {
                        fname = file.FileName;
                        fname = objPersonaEL.DOCUMENTO + Path.GetExtension(file.FileName);
                        objPersonaEL.FOTO = fname;
                        objPersonaEL.USUARIO_REGISTRO = SesionActual.Current.USUARIO_LOGIN;
                    }
                    // Get the complete folder path and store the file inside it.  
                    fname = Path.Combine(Server.MapPath("~/FotoPersona/"), fname);
                    file.SaveAs(fname);
                    objPersonaBL.fn_Update_PersonaFoto(objPersonaEL);
                }
                return Json(new { strRespuesta = (int.Parse(strRespuesta) > 0 ? "1" : strRespuesta) }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json("Archivo no seleccionado.");
            }
        }

        [SessionExpireFilter]
        public ActionResult CrearPersona()
        {
            RefrescarCache();
            ViewBag.TipoDocumento = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.TIPO_DOCUMENTO.Value));
            ViewBag.Sexo = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.SEXO.Value));
            return View();
        }

        [SessionExpireFilter]
        public ActionResult VerPersona(int strIdCodigoPersona)
        {
            RefrescarCache();
            var vpersona = new PersonaEL();
            IPersonaBL objPersonaBL = new PersonaBL();
            PersonaEL objPersonaEL = new PersonaEL();
            objPersonaEL.PERSONA_ID = strIdCodigoPersona;
            ViewBag.TipoDocumento = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.TIPO_DOCUMENTO.Value));
            ViewBag.Sexo = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.SEXO.Value));
            vpersona = objPersonaBL.fn_GetInfo_Persona(objPersonaEL);
            string strRuta = String.Empty;
            var strRutaServicio = System.Configuration.ConfigurationManager.AppSettings["RutaFoto"].ToString();
            strRuta = Request.ApplicationPath + strRutaServicio + vpersona.FOTO;
            ViewData["urlFoto"] = strRuta;
            return View("VerPersona", vpersona);
        }

        [SessionExpireFilter]
        public ActionResult ListarDonacionPersona()
        {
            RefrescarCache();
            return View();
        }

        [HttpGet]
        public JsonResult Leer_Persona_Pobre_Entrega(string strNombrePersona)
        {
            var vLstPersona = new List<PersonaPobreListaEL>();
            IPersonaBL objPersonaBL = new PersonaBL();
            PersonaEL objPersonaEL = new PersonaEL();
            objPersonaEL.DOCUMENTO = "";
            objPersonaEL.NOMBRE_COMPLETO = strNombrePersona;
            vLstPersona = objPersonaBL.fn_Get_Persona(objPersonaEL);
            Session[Constantes.LISTA.Value] = null;
            Session[Constantes.LISTA.Value] = vLstPersona;
            return Json(vLstPersona, JsonRequestBehavior.AllowGet);
        }

        [SessionExpireFilter]
        public ActionResult PersonaDonacion(int intIdPersona, string strNombreCompleto)
        {
            RefrescarCache();
            ViewData["intIdPersona"] = intIdPersona;
            ViewData["strNombreCompleto"] = strNombreCompleto;
            return View();
        }

        [SessionExpireFilter]
        public JsonResult Leer_Donacion_Persona(int intPersonaId, int intTipoConsulta)
        {
            var vLstDonacion = new List<DonacionEL>();
            IDonacionBL objDonacionBL = new DonacionBL();
            PersonaEL objPersonaEL = new PersonaEL();
            objPersonaEL.PERSONA_ID = intPersonaId;
            vLstDonacion = objDonacionBL.fn_Get_Donaciones_Persona(intTipoConsulta, objPersonaEL);
            return Json(vLstDonacion, JsonRequestBehavior.AllowGet);
        }

        public class DonacionModel
        {
            public List<DatosModel> DONACIONES { get; set; }
        }

        public class DatosModel
        {
            public int PERSONA_ID { get; set; }
            public int DONACION_ID { get; set; }
            public string DESCRIPCION_DONACION { get; set; }
        }

        [HttpPost]
        [SessionExpireFilter]
        public ActionResult GuardarDonacionPersona(DonacionModel model)
        {
            int intPersonaID = 0;
            intPersonaID = model.DONACIONES[0].PERSONA_ID;
            List<DonacionEL> lstDonaciones = new List<DonacionEL>();
            DonacionEL donacion;
            foreach (var fila in model.DONACIONES)
            {
                donacion = new DonacionEL();
                donacion.DONACION_ID = fila.DONACION_ID;
                lstDonaciones.Add(donacion);
            }
            IDonacionBL objDonacionBL = new DonacionBL();
            PersonaEL objPersonaEL = new PersonaEL();
            objPersonaEL.PERSONA_ID = intPersonaID;
            objPersonaEL.USUARIO_REGISTRO = SesionActual.Current.USUARIO_LOGIN;
            string strRespuesta = objDonacionBL.fn_Insert_DonacionPersona(lstDonaciones, objPersonaEL);
            return Json(new { strRespuesta = strRespuesta });
        }

        [SessionExpireFilter]
        public ActionResult ExportarExcel()
        {
            Response.ClearContent();
            Response.AddHeader("content-disposition", "attachment;filename=Donaciones.xls");
            Response.AddHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            Response.ContentEncoding = System.Text.Encoding.Default;
            Response.Charset = "";
            ExportExcel.ExportarExcel<DonacionListaEL>(TitulosCabeceraExcel.DONACION.Value, (List<DonacionListaEL>)(Session[Constantes.LISTA.Value]), Response.Output);
            Response.BinaryWrite(System.Text.Encoding.UTF8.GetPreamble());

            Response.Flush();
            Response.End();
            string strRespuesta = "";
            return Json(new { strRespuesta = strRespuesta });
        }

    }
}
