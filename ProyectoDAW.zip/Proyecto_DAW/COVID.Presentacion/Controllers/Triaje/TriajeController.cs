﻿using COVID.Entidades;
using COVID.Entidades.Listado;
using COVID.Negocio.Triaje;
using COVID.Presentacion.Controllers.Parametro;
using COVID.Presentacion.General;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace COVID.Presentacion.Controllers.Triaje
{
    public class TriajeController : Controller
    {
        #region "Refrescar Cache"
        [SessionExpireFilter]
        public void RefrescarCache()
        {
            if (SesionActual.Current.PERFIL == "")
            {
                Session.Abandon();
                Response.Redirect("~");
            }
            else
            {
                ViewData["LOGUEO_NOMBRE_COMPLETO"] = SesionActual.Current.NOMBRE_COMPLETO;
                ViewData["LOGUEO_PERFIL"] = SesionActual.Current.PERFIL;
                ViewData["USUARIO_CHAT"] = SesionActual.Current.USUARIO_LOGIN;
                ViewData["OPCIONES_USUARIO"] = SesionActual.Current.OPCIONES_USUARIO;
                Response.Cache.AppendCacheExtension("no-store, must-revalidate");
                Response.AppendHeader("Pragma", "no-cache"); // HTTP 1.0.
                Response.AppendHeader("Expires", "0"); // Proxies.
            }
        }
        #endregion

        [SessionExpireFilter]
        public ActionResult Listar()
        {
            RefrescarCache();
            Response.Cache.SetCacheability(HttpCacheability.NoCache);  // HTTP 1.1.
            ViewBag.TipoPrueba = new ParametroController().SelectListValoresXGrupo_Todos(int.Parse(ListaValores.TIPO_PRUEBA.Value));
            ViewBag.Resultado = new ParametroController().SelectListValoresXGrupo_Todos(int.Parse(ListaValores.RESULTADO_PRUEBA.Value));
            return View();
        }

        [HttpGet]
        public JsonResult Leer_Triaje(int intTipoPrueba, int intResultado)
        {
            var vLstTriaje = new List<TriajeListaEL>();
            ITriajeBL objTriajeBL = new TriajeBL();
            TriajeEL objTriajeEL = new TriajeEL();
            objTriajeEL.TIPO_PRUEBA_ID = intTipoPrueba;
            objTriajeEL.RESULTADO_ID = intResultado;
            vLstTriaje = objTriajeBL.fn_Get_Triaje(objTriajeEL);
            Session[Constantes.LISTA.Value] = null;
            Session[Constantes.LISTA.Value] = vLstTriaje;
            return Json(vLstTriaje, JsonRequestBehavior.AllowGet);
        }

        [SessionExpireFilter]
        public ActionResult Crear()
        {
            RefrescarCache();
            ViewBag.TipoPrueba = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.TIPO_PRUEBA.Value));
            ViewBag.Resultado = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.RESULTADO_PRUEBA.Value));
            ViewBag.TipoDocumento = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.TIPO_DOCUMENTO.Value));
            ViewBag.Sexo = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.SEXO.Value));
            return View();
        }

        [HttpPost, ValidateInput(false)]
        [SessionExpireFilter]
        public ActionResult Guardar()
        {
            try
            {
                string strRespuesta = string.Empty;
                ITriajeBL objTriajeBL = new TriajeBL();
                TriajeEL objTriajeEL = new TriajeEL();
                objTriajeEL.TIPO_DOCUMENTO_ID = Convert.ToInt32(Request.Form["intTipoDocumento"].ToString());
                objTriajeEL.NRO_DOCUMENTO =Request.Form["strNroDocumento"].ToString();
                objTriajeEL.APELLIDO_PACIENTE = Request.Form["strApellidoPaterno"].ToString().ToUpper();
                objTriajeEL.APELLIDO_MATERNO_PACIENTE = Request.Form["strApellidoMaterno"].ToString().ToUpper();
                objTriajeEL.NOMBRE_PACIENTE = Request.Form["strNombres"].ToString().ToUpper();
                objTriajeEL.SEXO_ID = Convert.ToInt32(Request.Form["intSexo"].ToString());
                objTriajeEL.DIRECCION = Request.Form["strDireccion"].ToString().ToUpper();
                objTriajeEL.PROFESION = Request.Form["strProfesion"].ToString().ToUpper();
                objTriajeEL.TIPO_PRUEBA_ID = Convert.ToInt32(Request.Form["intTipoPrueba"].ToString());
                objTriajeEL.RESULTADO_ID = Convert.ToInt32(Request.Form["intResultado"].ToString());
                objTriajeEL.USUARIO_CREACION = SesionActual.Current.USUARIO_LOGIN;
                strRespuesta = objTriajeBL.fn_Insert_Triaje(objTriajeEL);
                return Json(new { strRespuesta = (int.Parse(strRespuesta) > 0 ? "1" : strRespuesta) }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json("Ocurrio un error. Detalle de error " + ex.Message);
            }
        }

        [SessionExpireFilter]
        public ActionResult VerTriaje(int strIdTriaje)
        {
            RefrescarCache();
            var vtriaje = new TriajeEL();
            ITriajeBL objTriajeBL = new TriajeBL();
            TriajeEL objTriajeEL = new TriajeEL();
            objTriajeEL.TRIAJE_ID = strIdTriaje;
            ViewBag.TipoPrueba = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.TIPO_PRUEBA.Value));
            ViewBag.Resultado = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.RESULTADO_PRUEBA.Value));
            ViewBag.TipoDocumento = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.TIPO_DOCUMENTO.Value));
            ViewBag.Sexo = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.SEXO.Value));
            vtriaje = objTriajeBL.fn_GetInfo_Triaje(objTriajeEL);
            return View("VerTriaje", vtriaje);
        }

        /*[SessionExpireFilter]
        public string Obtener_SubEspecialidades(int intEspecialidadId)
        {
            Boolean success = false;
            object data;
            try
            {
                var lstSubEspecialidad = new ParametroController().SelectListSubEspecialidades(intEspecialidadId);
                data = lstSubEspecialidad;
                success = true;
            }
            catch (Exception)
            {
                success = false;
                data = "Error Interno";
            }
            return JsonConvert.SerializeObject(new
            {
                success = success,
                data = data
            });
        }*/


        /*[HttpPost, ValidateInput(false)]
        [SessionExpireFilter]
        public ActionResult Guardar()
        {
            if (Request.Files.Count > 0)
            {
                try
                {
                    string strRespuesta = string.Empty;
                    ITicketBL objTicketBL = new TicketBL();
                    TicketEL objTicketEL = new TicketEL();
                    objTicketEL.SUBESPECIALIDAD_ID = 0;
                    objTicketEL.TIPO_TICKET_ID = Convert.ToInt32(Request.Form["tipoTicket"].ToString());
                    objTicketEL.PRIORIDAD_ID = Convert.ToInt32(Request.Form["prioridad"].ToString());
                    objTicketEL.DETALLE = Request.Form["detalle"].ToString();
                    objTicketEL.USUARIO_CREACION = SesionActual.Current.USUARIO_LOGIN;
                    objTicketEL.ESTADO_TICKET = Convert.ToInt32(ListaValores.ESTADO_REGISTRADO.Value);
                    strRespuesta = objTicketBL.fn_Insert_Ticket(objTicketEL);
                    objTicketEL = objTicketBL.fn_GetMaximoNro_Ticket();
                    HttpFileCollectionBase files = Request.Files;
                    for (int i = 0; i < files.Count; i++)
                    {
                        HttpPostedFileBase file = files[i];
                        string fname;
                        // Checking for Internet Explorer  
                        if (Request.Browser.Browser.ToUpper() == "IE" || Request.Browser.Browser.ToUpper() == "INTERNETEXPLORER")
                        {
                            string[] testfiles = file.FileName.Split(new char[] { '\\' });
                            fname = testfiles[testfiles.Length - 1];
                        }
                        else
                        {
                            fname = file.FileName;
                            fname = objTicketEL.NUMERO_TICKET + Path.GetExtension(file.FileName);
                            objTicketEL.EVIDENCIA = fname;
                            objTicketEL.USUARIO_CREACION = SesionActual.Current.USUARIO_LOGIN;
                        }
                        // Get the complete folder path and store the file inside it.  
                        fname = Path.Combine(Server.MapPath("~/Evidencia/"), fname);
                        file.SaveAs(fname);
                        objTicketBL.fn_Update_Evidencia(objTicketEL);
                    }
                    fn_enviar_correo_administrador(objTicketEL);
                    return Json(new { strRespuesta = (int.Parse(strRespuesta) > 0 ? "1" : strRespuesta) }, JsonRequestBehavior.AllowGet);
                }
                catch (Exception ex)
                {
                    return Json("Ocurrio un error. Detalle de error " + ex.Message);
                }
            }
            else
            {
                return Json("Archivo no seleccionado.");
            }
        }*/

        /*[SessionExpireFilter]
        public ActionResult VerTicket(int strIdTicket)
        {
            RefrescarCache();
            var vticket = new TicketEL();
            ITicketBL objTicketBL = new TicketBL();
            TicketEL objTicketEL = new TicketEL();
            objTicketEL.TICKET_ID = strIdTicket;
            vticket = objTicketBL.fn_GetInfo_Ticket(objTicketEL);
            ViewBag.Estado = vticket.DESCRIPCION_ESTADO;
            string strRuta = String.Empty;
            var strRutaServicio = System.Configuration.ConfigurationManager.AppSettings["RutaEvidencia"].ToString();
            strRuta = Request.ApplicationPath + strRutaServicio + vticket.EVIDENCIA;
            ViewData["urlEvidencia"] = strRuta;
            ViewData["rating"] = vticket.CALIFICACION;
            ViewData["estado"] = vticket.DESCRIPCION_ESTADO;
            return View("VerTicket", vticket);
        }*/

       
        public ActionResult Index()
        {
            return View();
        }

        [SessionExpireFilter]
        public ActionResult ExportarExcel()
        {
            Response.ClearContent();
            Response.AddHeader("content-disposition", "attachment;filename=Triaje.xls");
            Response.AddHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            Response.ContentEncoding = System.Text.Encoding.Default;
            Response.Charset = "";
            ExportExcel.ExportarExcel<TriajeListaEL>(TitulosCabeceraExcel.TRIAJE.Value, (List<TriajeListaEL>)(Session[Constantes.LISTA.Value]), Response.Output);
            Response.BinaryWrite(System.Text.Encoding.UTF8.GetPreamble());

            Response.Flush();
            Response.End();
            string strRespuesta = "";
            return Json(new { strRespuesta = strRespuesta });
        }

    }
}
