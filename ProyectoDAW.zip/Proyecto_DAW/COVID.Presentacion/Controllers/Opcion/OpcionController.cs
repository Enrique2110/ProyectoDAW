﻿using COVID.Entidades;
using COVID.Entidades.Listado;
using COVID.Negocio.Opcion;
using COVID.Presentacion.Controllers.Parametro;
using COVID.Presentacion.General;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace COVID.Presentacion.Controllers.Opcion
{
    public class OpcionController : Controller
    {
        #region "Refrescar Cache"
        public void RefrescarCache()
        {
            if (SesionActual.Current.PERFIL == "")
            {
                Session.Abandon();
                Response.Redirect("~");
            }
            else
            {
                ViewData["LOGUEO_NOMBRE_COMPLETO"] = SesionActual.Current.NOMBRE_COMPLETO;
                ViewData["LOGUEO_PERFIL"] = SesionActual.Current.PERFIL;
                ViewData["OPCIONES_USUARIO"] = SesionActual.Current.OPCIONES_USUARIO;
                Response.Cache.AppendCacheExtension("no-store, must-revalidate");
                Response.AppendHeader("Pragma", "no-cache"); // HTTP 1.0.
                Response.AppendHeader("Expires", "0"); // Proxies.
            }
        }
        #endregion

        #region "Listar"
        [SessionExpireFilter]
        public JsonResult Leer_Opcion(string strNombreOpcion)
        {
            var vLstOpcion = new List<OpcionListaEL>();
            IOpcionBL objOpcionBL = new OpcionBL();
            OpcionEL objOpcionEL = new OpcionEL();
            objOpcionEL.NOMBRE_OPCION = strNombreOpcion;
            vLstOpcion = objOpcionBL.fn_Get_Opcion(objOpcionEL);
            Session[Constantes.LISTA.Value] = null;
            Session[Constantes.LISTA.Value] = vLstOpcion;
            return Json(vLstOpcion, JsonRequestBehavior.AllowGet);
        }
        #endregion

        [SessionExpireFilter]
        public ActionResult Editar(int intIdCodigoOpcion)
        {
            RefrescarCache();
            var vOpcion = new OpcionEL();
            IOpcionBL objOpcionBL = new OpcionBL();
            OpcionEL objOpcionEL = new OpcionEL();
            objOpcionEL.OPCION_ID = intIdCodigoOpcion;
            vOpcion = objOpcionBL.fn_GetInfo_Opcion(objOpcionEL);
            ViewBag.Estados = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.ESTADO_REGISTRO.Value));
            return View("Editar",vOpcion);
        }

        [HttpPost]
        [SessionExpireFilter]
        public ActionResult Modificar(FormCollection form)
        {
            string strRespuesta = string.Empty;
            IOpcionBL objOpcionBL = new OpcionBL();
            OpcionEL objOpcionEL = new OpcionEL();
            objOpcionEL.OPCION_ID = int.Parse(form["OPCION_ID"]);
            objOpcionEL.NOMBRE_OPCION = form["NOMBRE_OPCION"].ToString().ToUpper();
            objOpcionEL.SIGLA_OPCION = form["SIGLA_OPCION"].ToString().ToUpper();
            objOpcionEL.DESCRIPCION = form["DESCRIPCION"].ToString().ToUpper();
            objOpcionEL.ESTADO = int.Parse(form["ESTADO"].ToString());
            objOpcionEL.USU_CREACION = SesionActual.Current.USUARIO_LOGIN;
            strRespuesta = objOpcionBL.fn_Update_Opcion(objOpcionEL);
            return Json(new { strRespuesta = strRespuesta }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [SessionExpireFilter]
        public ActionResult Guardar(FormCollection form)
        {
            string strRespuesta = string.Empty;
            IOpcionBL objOpcionBL = new OpcionBL();
            OpcionEL objOpcionEL = new OpcionEL();
            objOpcionEL.NOMBRE_OPCION = form["NOMBRE_OPCION"].ToString().ToUpper();
            objOpcionEL.SIGLA_OPCION = form["SIGLA_OPCION"].ToString().ToUpper();
            objOpcionEL.DESCRIPCION = form["DESCRIPCION"].ToString().ToUpper();
            objOpcionEL.USU_CREACION = SesionActual.Current.USUARIO_LOGIN;
            strRespuesta = objOpcionBL.fn_Insert_Opcion(objOpcionEL);
            return Json(new { strRespuesta = strRespuesta }, JsonRequestBehavior.AllowGet);
        }

        //
        // GET: /Opcion/
        [SessionExpireFilter]
        public ActionResult Listar()
        {
            RefrescarCache();
            return View();
        }

        [SessionExpireFilter]
        public ActionResult Ver(int intIdCodigoOpcion)
        {
            RefrescarCache();
            var vOpcion = new OpcionEL();
            IOpcionBL objOpcionBL = new OpcionBL();
            OpcionEL objOpcionEL = new OpcionEL();
            objOpcionEL.OPCION_ID = intIdCodigoOpcion;
            vOpcion = objOpcionBL.fn_GetInfo_Opcion(objOpcionEL);
            ViewBag.Estados = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.ESTADO_REGISTRO.Value));
            return View("Ver",vOpcion);
        }

        [SessionExpireFilter]
        public ActionResult Crear()
        {
            RefrescarCache();
            ViewBag.Estado = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.ESTADO_REGISTRO.Value));
            return View();
        }

        [SessionExpireFilter]
        public ActionResult ExportarExcel()
        {
            Response.ClearContent();
            Response.AddHeader("content-disposition", "attachment;filename=Opcion.xls");
            Response.AddHeader("Content-Type", "application/vnd.ms-excel");
            Response.Charset = "UTF-8";
            Response.ContentEncoding = System.Text.Encoding.Default;
            String ruta = Server.MapPath("Content\\images");
            ExportExcel.ExportarExcel<OpcionListaEL>(TitulosCabeceraExcel.MANTENIMIENTO_OPCIONES.Value, (List<OpcionListaEL>)(Session[Constantes.LISTA.Value]), Response.Output, ruta);
            Response.End();
            string strRespuesta = "";
            return Json(new { strRespuesta = strRespuesta });
        }

        public ActionResult Index()
        {
            return View();
        }

    }
}
