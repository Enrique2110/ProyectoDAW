﻿using COVID.Presentacion.General;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace COVID.Presentacion.Controllers.Inicio
{
    public class InicioController : Controller
    {
        #region "Refrescar Cache"
        public void RefrescarCache()
        {
            ViewData["LOGUEO_NOMBRE_COMPLETO"] = SesionActual.Current.NOMBRE_COMPLETO;
            ViewData["LOGUEO_PERFIL"] = SesionActual.Current.PERFIL;
            ViewData["OPCIONES_USUARIO"] = SesionActual.Current.OPCIONES_USUARIO;
            ViewData["NOMBRE_SISTEMA"] = SesionActual.Current.APLICACION;
            ViewData["AVATAR"] = SesionActual.Current.AVATAR;
            Response.Cache.AppendCacheExtension("no-store, must-revalidate");
            Response.AppendHeader("Pragma", "no-cache"); // HTTP 1.0.
            Response.AppendHeader("Expires", "0"); // Proxies.
        }
        #endregion
        //
        // GET: /Inicio/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Inicio()
        {
            RefrescarCache();
            Session.Abandon();
            return View();
        }

    }
}
