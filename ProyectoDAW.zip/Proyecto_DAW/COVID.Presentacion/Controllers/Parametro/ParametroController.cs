﻿using COVID.Entidades;
using COVID.Negocio.Parametro;
using COVID.Presentacion.General;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace COVID.Presentacion.Controllers.Parametro
{
    public class ParametroController : Controller
    {
        #region "Refrescar Cache"
        public void RefrescarCache()
        {
            if (SesionActual.Current.PERFIL == "")
            {
                Session.Abandon();
                Response.Redirect("~");
            }
            else
            {
                ViewData["LOGUEO_NOMBRE_COMPLETO"] = SesionActual.Current.NOMBRE_COMPLETO;
                ViewData["LOGUEO_PERFIL"] = SesionActual.Current.PERFIL;
                ViewData["OPCIONES_USUARIO"] = SesionActual.Current.OPCIONES_USUARIO;
                Response.Cache.AppendCacheExtension("no-store, must-revalidate");
                Response.AppendHeader("Pragma", "no-cache"); // HTTP 1.0.
                Response.AppendHeader("Expires", "0"); // Proxies.
            }
        }
        #endregion

        [SessionExpireFilter]
        public SelectList SelectListValoresXGrupo(int strGrupoParametro)
        {
            var vLstParametro = new List<ParametroEL>();
            IParametroBL objParametroBL = new ParametroBL();
            ParametroEL objParametroEL = new ParametroEL();
            objParametroEL.GRUPO_LISTA_VALORES = strGrupoParametro;
            vLstParametro = objParametroBL.fn_Get_ParametrosXGrupo(objParametroEL);
            return new SelectList(vLstParametro, CamposDDL.VALOR.Value, CamposDDL.DESCRIPCION.Value);
        }

        [SessionExpireFilter]
        public SelectList SelectListValoresXGrupo_Todos(int strGrupoParametro)
        {
            var vLstParametro = new List<ParametroEL>();
            IParametroBL objParametroBL = new ParametroBL();
            ParametroEL objParametroEL = new ParametroEL();
            objParametroEL.GRUPO_LISTA_VALORES = strGrupoParametro;
            vLstParametro = objParametroBL.fn_Get_ParametrosXGrupo_Todos(objParametroEL);
            return new SelectList(vLstParametro, CamposDDL.VALOR.Value, CamposDDL.DESCRIPCION.Value);
        }

        [SessionExpireFilter]
        public SelectList SelectListRoles()
        {
            var vLstParametro = new List<ParametroEL>();
            IParametroBL objParametroBL = new ParametroBL();
            ParametroEL objParametroEL = new ParametroEL();
            vLstParametro = objParametroBL.fn_Get_Roles();
            return new SelectList(vLstParametro, CamposDDL.VALOR.Value, CamposDDL.DESCRIPCION.Value);
        }

        #region "Listar"
        [SessionExpireFilter]
        public ActionResult ObtenerElementosXGrupo(int strGrupoParametro)
        {
            var vLstParametro = new List<ParametroEL>();
            IParametroBL objParametroBL = new ParametroBL();
            ParametroEL objParametroEL = new ParametroEL();
            objParametroEL.GRUPO_LISTA_VALORES = strGrupoParametro;
            vLstParametro = objParametroBL.fn_Get_ParametrosXGrupo(objParametroEL);
            return Json(vLstParametro, JsonRequestBehavior.AllowGet);
        }
        #endregion

    }
}
