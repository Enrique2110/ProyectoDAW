﻿using COVID.Entidades;
using COVID.Entidades.Listado;
using COVID.Negocio.Rol;
using COVID.Presentacion.Controllers.Parametro;
using COVID.Presentacion.General;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace COVID.Presentacion.Controllers.Rol
{
    public class RolController : Controller
    {
        public void RefrescarCache()
        {
            if (SesionActual.Current.PERFIL == "")
            {
                Session.Abandon();
                Response.Redirect("~");
            }
            else
            {
                ViewData["LOGUEO_NOMBRE_COMPLETO"] = SesionActual.Current.NOMBRE_COMPLETO;
                ViewData["LOGUEO_PERFIL"] = SesionActual.Current.PERFIL;
                ViewData["OPCIONES_USUARIO"] = SesionActual.Current.OPCIONES_USUARIO;
                Response.Cache.AppendCacheExtension("no-store, must-revalidate");
                Response.AppendHeader("Pragma", "no-cache"); // HTTP 1.0.
                Response.AppendHeader("Expires", "0"); // Proxies.
            }
        }

        [SessionExpireFilter]
        public JsonResult Leer_Rol(string strNombreRol)
        {
            var vLstRol = new List<RolListaEL>();
            IRolBL objRolBL = new RolBL();
            RolEL objRolEL = new RolEL();
            objRolEL.NOMBRE_ROL = strNombreRol;
            vLstRol = objRolBL.fn_Get_Rol(objRolEL);
            Session[Constantes.LISTA.Value] = null;
            Session[Constantes.LISTA.Value] = vLstRol;
            return Json(vLstRol, JsonRequestBehavior.AllowGet);
        }

        [SessionExpireFilter]
        public ActionResult Listar()
        {
            RefrescarCache();
            return View();
        }

        [SessionExpireFilter]
        public ActionResult Crear()
        {
            RefrescarCache();
            ViewBag.Estado = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.ESTADO_REGISTRO.Value));
            return View();
        }

        [HttpPost]
        [SessionExpireFilter]
        public ActionResult Guardar(FormCollection form)
        {
            string strRespuesta = string.Empty;
            IRolBL objRolBL = new RolBL();
            RolEL objRolEL = new RolEL();
            objRolEL.NOMBRE_ROL = form["NOMBRE_ROL"].ToString().ToUpper();
            objRolEL.DESCRIPCION = form["DESCRIPCION"].ToString().ToUpper();
            objRolEL.USUARIO_REGISTRO = SesionActual.Current.USUARIO_LOGIN;
            objRolEL.ESTADO_CODIGO = int.Parse(form["ESTADO_CODIGO"].ToString());
            strRespuesta = objRolBL.fn_Insert_Rol(objRolEL);
            return Json(new { strRespuesta = strRespuesta }, JsonRequestBehavior.AllowGet);
        }

        [SessionExpireFilter]
        public ActionResult Ver(int intIdCodigoRol)
        {
            RefrescarCache();
            var vRol = new RolEL();
            IRolBL objRolBL = new RolBL();
            RolEL objRolEL = new RolEL();
            objRolEL.ROL_ID = intIdCodigoRol;
            ViewBag.Estado = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.ESTADO_REGISTRO.Value));
            vRol = objRolBL.fn_GetInfo_Rol(objRolEL);
            return View(vRol);
        }

        [SessionExpireFilter]
        public ActionResult Editar(int intIdCodigoRol)
        {
            RefrescarCache();
            var vPerfil = new RolEL();
            IRolBL objRolBL = new RolBL();
            RolEL objRolEL = new RolEL();
            objRolEL.ROL_ID = intIdCodigoRol;
            ViewBag.Estado = new ParametroController().SelectListValoresXGrupo(int.Parse(ListaValores.ESTADO_REGISTRO.Value));
            vPerfil = objRolBL.fn_GetInfo_Rol(objRolEL);
            return View(vPerfil);
        }

        [HttpPost]
        [SessionExpireFilter]
        public ActionResult Modificar(FormCollection form)
        {
            string strRespuesta = string.Empty;
            IRolBL objRolBL = new RolBL();
            RolEL objRolEL = new RolEL();
            objRolEL.NOMBRE_ROL = form["NOMBRE_ROL"].ToString().ToUpper();
            objRolEL.DESCRIPCION = form["DESCRIPCION"].ToString().ToUpper();
            objRolEL.ROL_ID = int.Parse(form["ROL_ID"]);
            objRolEL.ESTADO_CODIGO = int.Parse(form["ESTADO_CODIGO"].ToString());
            objRolEL.USUARIO_REGISTRO = SesionActual.Current.USUARIO_LOGIN;
            strRespuesta = objRolBL.fn_Update_Rol(objRolEL);
            return Json(new { strRespuesta = strRespuesta }, JsonRequestBehavior.AllowGet);
        }

        [SessionExpireFilter]
        public ActionResult ExportarExcel()
        {
            Response.ClearContent();
            Response.AddHeader("content-disposition", "attachment;filename=Roles.xls");
            Response.AddHeader("Content-Type", "application/vnd.ms-excel");
            Response.Charset = "UTF-8";
            Response.ContentEncoding = System.Text.Encoding.Default;
            String ruta = Request.ApplicationPath;
            ExportExcel.ExportarExcel<RolListaEL>(TitulosCabeceraExcel.MANTENIMIENTO_PERFILES.Value, (List<RolListaEL>)(Session[Constantes.LISTA.Value]), Response.Output, ruta);
            Response.End();
            string strRespuesta = "";
            return Json(new { strRespuesta = strRespuesta });
        }

        [SessionExpireFilter]
        public JsonResult Leer_Opcion(int intRolId, int intTipoConsulta)
        {
            var vLstRol = new List<OpcionEL>();
            IRolBL objRolBL = new RolBL();
            RolEL objRolEL = new RolEL();
            objRolEL.ROL_ID = intRolId;
            vLstRol = objRolBL.fn_Get_Rol_Opcion_Actual(intTipoConsulta, objRolEL);
            return Json(vLstRol, JsonRequestBehavior.AllowGet);
        }

        public class OpcionModel
        {
            public List<DatosModel> OPCIONES { get; set; }
        }

        public class DatosModel
        {
            public int ROL_ID { get; set; }
            public int OPCION_ID { get; set; }
            public string NOMBRE_OPCION { get; set; }
        }

        [HttpPost]
        [SessionExpireFilter]
        public ActionResult GuardarRolOpcion(OpcionModel model)
        {
            int intRolID = 0;
            intRolID = model.OPCIONES[0].ROL_ID;
            List<OpcionEL> lstOpciones = new List<OpcionEL>();
            OpcionEL opcion;
            foreach (var fila in model.OPCIONES)
            {
                opcion = new OpcionEL();
                opcion.OPCION_ID = fila.OPCION_ID;
                lstOpciones.Add(opcion);
            }
            IRolBL objRolBL = new RolBL();
            RolEL objRolEL = new RolEL();
            objRolEL.ROL_ID = intRolID;
            objRolEL.USUARIO_REGISTRO = SesionActual.Current.USUARIO_LOGIN;
            string strRespuesta = objRolBL.fn_Insert_RolOpcion(lstOpciones, objRolEL);
            return Json(new { strRespuesta = strRespuesta });
        }

        [SessionExpireFilter]
        public ActionResult ListarRolP()
        {
            RefrescarCache();
            return View();
        }

        [SessionExpireFilter]
        public ActionResult RolOpcion(int intIdCodigoRol, string strNombreRol)
        {
            RefrescarCache();
            ViewData["intIdCodigoRol"] = intIdCodigoRol;
            ViewData["strNombreRol"] = strNombreRol;
            return View();
        }

        public ActionResult Index()
        {
            return View();
        }
    }
}
