﻿using COVID.Presentacion.General;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace COVID.Presentacion.Controllers.Home
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            RefrescarCache();
            return View();
        }

        public void RefrescarCache()
        {
            if (SesionActual.Current.PERFIL == "")
            {
                Session.Abandon();
                Response.Redirect("~");
            }
            else
            {
                ViewData["LOGUEO_NOMBRE_COMPLETO"] = SesionActual.Current.NOMBRE_COMPLETO;
                ViewData["LOGUEO_PERFIL"] = SesionActual.Current.PERFIL;
                ViewData["OPCIONES_USUARIO"] = SesionActual.Current.OPCIONES_USUARIO;
                ViewData["NOMBRE_SISTEMA"] = SesionActual.Current.APLICACION;
                ViewData["AVATAR"] = SesionActual.Current.AVATAR;
                Response.Cache.AppendCacheExtension("no-store, must-revalidate");
                Response.AppendHeader("Pragma", "no-cache"); // HTTP 1.0.
                Response.AppendHeader("Expires", "0"); // Proxies.
            }
        }

        [SessionExpireFilter]
        public ActionResult NavBar()
        {
            string strRuta = String.Empty;
            string strRutaServicio = String.Empty;
            if (SesionActual.Current.AVATAR == null || SesionActual.Current.AVATAR.ToString().Equals(""))
            {
                strRutaServicio = System.Configuration.ConfigurationManager.AppSettings["RutaFotoUsuario"].ToString();
                strRuta = Request.ApplicationPath + strRutaServicio + "userDefault.jpg";
            }
            else
            {
                strRutaServicio = System.Configuration.ConfigurationManager.AppSettings["RutaAvatar"].ToString();
                strRuta = Request.ApplicationPath + strRutaServicio + SesionActual.Current.AVATAR;
            }
            ViewData["urlUsuarioFoto"] = strRuta;
            return PartialView("_NavBar");
        }

        [SessionExpireFilter]
        public ActionResult EncriptarParametroJS(string strParametro)
        {
            return Json(new { strEncriptado = Encriptador.Encriptar(strParametro) });
        }
    }
}
