﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;

namespace COVID.Presentacion
{
    public class BundleConfig
    {
        // Para obtener más información acerca de Bundling, consulte http://go.microsoft.com/fwlink/?LinkId=254725
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryui").Include(
                        "~/Scripts/jquery-ui-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                        "~/Scripts/jquery.unobtrusive*",
                        "~/Scripts/jquery.validate*"));

            bundles.Add(new ScriptBundle("~/bundles/Script-custom-editor").Include(
                       "~/Scripts/script-custom-editor.js"));

            bundles.Add(new ScriptBundle("~/bundles/Scripts/layout")
                                                .Include("~/Scripts/Intranet/General.js")
                                                .Include("~/Scripts/layout/metronic.js")
                                                .Include("~/Scripts/layout/layout.js")
                                                .Include("~/Scripts/layout/principal.js")
                                                .Include("~/Scripts/Datatable/jquery.dataTables.js")
                                                .Include("~/Scripts/Datatable/dataTables.tableTools.js")
                                                .Include("~/Scripts/jquery.loading.js")
                                                .Include("~/Scripts/tooltipster.bundle.min.js")
                                                );

            bundles.Add(new ScriptBundle("~/bundles/Scripts/layoutLogin")
                                    .Include("~/Scripts/layout/metronic.js")
                                    .Include("~/Scripts/layout/layout.js")
                                    .Include("~/Scripts/layout/principal.js")
                                    .Include("~/Scripts/Datatable/jquery.dataTables.js")
                                    .Include("~/Scripts/Datatable/dataTables.tableTools.js")
                                    .Include("~/Scripts/jquery.loading.js")
                                    .Include("~/Scripts/ServiceDesk/UsuarioInfoPC.js")
                                    );


            bundles.Add(new StyleBundle("~/bundles/Content/css").Include("~/Content/estilos.css")
                                                        .Include("~/Content/css/custom.css")
                                                        .Include("~/Content/css/layout.css")
                                                        .Include("~/Content/css/light2.css")
                                                        .Include("~/Content/css/plugins.css")
                                                        .Include("~/Content/css/select2.css")
                                                        .Include("~/Content/css/login-soft.css")
                                                        .Include("~/Content/css/uniform.default.css")
                                                        .Include("~/Content/css/jquery.dataTables.css")
                                                        .Include("~/Content/css/dataTables.tableTools.css")
                                                        .Include("~/Content/css/tooltipster.bundle.min.css")
                                                        );

            bundles.Add(new StyleBundle("~/bundles/Content/cssEstandar").Include("~/Content/estilos.css")
                                            .Include("~/Content/css/custom.css")
                                            .Include("~/Content/css/layout.css")
                                            .Include("~/Content/css/light2.css")
                                            .Include("~/Content/css/plugins.css")
                                            .Include("~/Content/css/select2.css")
                                            .Include("~/Content/css/font-awesome.min.css")
                                            .Include("~/Content/css/uniform.default.css")
                                            .Include("~/Content/css/jquery.dataTables.css")
                                            .Include("~/Content/css/dataTables.tableTools.css")
                                            );

            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include("~/Scripts/bootstrap*"));
        }
    }
}