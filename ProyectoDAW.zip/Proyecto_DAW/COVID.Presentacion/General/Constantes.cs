﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace COVID.Presentacion.General
{
    public class Constantes
    {
        private Constantes(string value) { Value = value; }
        private Constantes(int value) { ValueInt = value; }
        public string Value { get; set; }
        public int ValueInt { get; set; }
        public static Constantes LISTA { get { return new Constantes("LISTA"); } }
        public static Constantes IDENTIFICADOR_APLICACION { get { return new Constantes(1); } }
        public static Constantes SUFIJO_USUARIOEXTERNO { get { return new Constantes(".EXT"); } }
    }

    public class ListaValores
    {
        private ListaValores(string value) { Value = value; }
        public string Value { get; set; }
        public static ListaValores SEXO { get { return new ListaValores("2"); } }
        public static ListaValores ESTADO_REGISTRO { get { return new ListaValores("3"); } }
        public static ListaValores TIPO_DOCUMENTO { get { return new ListaValores("1"); } }
        public static ListaValores RESULTADO_PRUEBA { get { return new ListaValores("4"); } }
        public static ListaValores TIPO_PRUEBA { get { return new ListaValores("5"); } }
        public static ListaValores TIPO_DONACION { get { return new ListaValores("6"); } }
        public static ListaValores ESTADO_DONACION { get { return new ListaValores("7"); } }
        public static ListaValores RESULTADO_POSITIVO { get { return new ListaValores("10"); } }
        public static ListaValores RESULTADO_NEGATIVO { get { return new ListaValores("9"); } }

        public static ListaValores TIPO_LOGUEO { get { return new ListaValores("014"); } }
        public static ListaValores CANTIDAD_INTENTOS_DEFECTO { get { return new ListaValores("032"); } }
        public static ListaValores MAIL_FORMATO { get { return new ListaValores("033"); } }
        public static ListaValores MAIL_VALORES { get { return new ListaValores("039"); } }
        public static ListaValores VALORES_SISTEMA { get { return new ListaValores("050"); } }
        public static ListaValores VALORES_SEGURIDAD { get { return new ListaValores("031"); } }
        public static ListaValores DURACION_SESION { get { return new ListaValores("051"); } }
        public static ListaValores CANTIDAD_FILAS_DATATABLE { get { return new ListaValores("052"); } }
        public static ListaValores LONGITUD_MINIMA_CLAVE { get { return new ListaValores("062"); } }
        public static ListaValores REGLAS_CLAVE { get { return new ListaValores("068"); } }

        public static ListaValores ESTADO_REGISTRADO { get { return new ListaValores("1"); } }
        public static ListaValores ESTADO_ASIGNADO { get { return new ListaValores("2"); } }
        public static ListaValores ESTADO_CONFORME { get { return new ListaValores("5"); } }

        public static ListaValores ESTADO_PROBLEMA_ASIGNADO { get { return new ListaValores("1"); } }
        public static ListaValores ESTADO_PROBLEMA_SOLUCIONADO { get { return new ListaValores("2"); } }
        public static ListaValores ESTADO_PROBLEMA_ACEPTADO{ get { return new ListaValores("3"); } }

        public static ListaValores ESTADO_CAMBIO_ASIGNADO { get { return new ListaValores("1"); } }
        public static ListaValores ESTADO_CAMBIO_PROCEDE { get { return new ListaValores("2"); } }
        public static ListaValores ESTADO_CAMBIO_NO_PROCEDE { get { return new ListaValores("3"); } }
    }
    public class MailParametros
    {
        private MailParametros(string value) { Value = value; }
        public string Value { get; set; }
        public static MailParametros HTML { get { return new MailParametros("034"); } }
        public static MailParametros HEADER { get { return new MailParametros("035"); } }
        public static MailParametros BODY { get { return new MailParametros("036"); } }
        public static MailParametros BODY2 { get { return new MailParametros("037"); } }
        public static MailParametros FOOTER { get { return new MailParametros("038"); } }
        public static MailParametros ASUNTO_CORREO { get { return new MailParametros("063"); } }
        public static MailParametros ASUNTO_CORREO_APLICACION { get { return new MailParametros("077"); } }
        public static MailParametros ASUNTO_CORREO_RESETEO { get { return new MailParametros("078"); } }

        public static MailParametros TITULO { get { return new MailParametros("040"); } }
        public static MailParametros SALUDO { get { return new MailParametros("041"); } }
        public static MailParametros MENSAJE_NUEVA_CLAVE { get { return new MailParametros("042"); } }
        public static MailParametros DATOS_PARTICULARES { get { return new MailParametros("043"); } }
        public static MailParametros MENSAJE_FINAL { get { return new MailParametros("044"); } }
        public static MailParametros PIE_MENSAJE { get { return new MailParametros("045"); } }
        public static MailParametros MENSAJE_NORESPONDER { get { return new MailParametros("064"); } }
        public static MailParametros MENSAJE_RESETEO_CLAVE { get { return new MailParametros("046"); } }


        public static MailParametros MENSAJE_APLICACION { get { return new MailParametros("065"); } }
        public static MailParametros DATOS_APLICACIONES { get { return new MailParametros("066"); } }
        public static MailParametros MENSAJE_FINAL_APLICACION_INTERNO { get { return new MailParametros("067"); } }
        public static MailParametros MENSAJE_FINAL_APLICACION_EXTERNO { get { return new MailParametros("079"); } }
    }

    public class CamposDDL
    {
        private CamposDDL(string value) { Value = value; }
        private CamposDDL(int value) { ValueInt = value; }
        public string Value { get; set; }
        public int ValueInt { get; set; }
        public static CamposDDL TODOS { get { return new CamposDDL("TODOS"); } }
        public static CamposDDL SELECCIONE { get { return new CamposDDL("SELECCIONE"); } }
        public static CamposDDL CERO { get { return new CamposDDL(0); } }
        public static CamposDDL CEROCAD { get { return new CamposDDL("0"); } }
        public static CamposDDL DESCRIPCION { get { return new CamposDDL("DESCRIPCION"); } }
        public static CamposDDL VALOR { get { return new CamposDDL("CODIGO_VALOR"); } }
        public static CamposDDL APLICACION_ID { get { return new CamposDDL("APLICACION_ID"); } }
        public static CamposDDL NOMBRE { get { return new CamposDDL("NOMBRE"); } }
        public static CamposDDL PERFIL_ID { get { return new CamposDDL("PERFIL_ID"); } }
        public static CamposDDL NOMBRE_PERFIL { get { return new CamposDDL("NOMBRE_PERFIL"); } }
    }

    public class TablasBD
    {
        private TablasBD(string value) { Value = value; }
        public string Value { get; set; }
        public static TablasBD USUARIO { get { return new TablasBD("USUARIO"); } }
        public static TablasBD APLICACION { get { return new TablasBD("APLICACION"); } }
        public static TablasBD APLICACION_VERSION { get { return new TablasBD("VERSION"); } }
        public static TablasBD OPCION { get { return new TablasBD("OPCION"); } }
        public static TablasBD PERFIL { get { return new TablasBD("PERFIL"); } }
        public static TablasBD LISTA_VALORES { get { return new TablasBD("LISTA_VALORES"); } }
    }
    public class CampoBD
    {
        private CampoBD(string value) { Value = value; }
        public string Value { get; set; }
        public static CampoBD USUARIO_ID { get { return new CampoBD("USUARIO_ID"); } }
        public static CampoBD APLICACION_ID { get { return new CampoBD("APLICACION_ID"); } }
        public static CampoBD VERSION_ID { get { return new CampoBD("VERSION_ID"); } }
        public static CampoBD OPCION_ID { get { return new CampoBD("OPCION_ID"); } }
        public static CampoBD PERFIL_ID { get { return new CampoBD("PERFIL_ID"); } }
        public static CampoBD CODIGO_VALOR { get { return new CampoBD("CODIGO_VALOR"); } }
    }
    public class TitulosCabeceraExcel
    {
        private TitulosCabeceraExcel(string value) { Value = value; }
        public string Value { get; set; }
        public static TitulosCabeceraExcel TRIAJE { get { return new TitulosCabeceraExcel("LISTA DE TRIAJES"); } }
        public static TitulosCabeceraExcel DONACION { get { return new TitulosCabeceraExcel("LISTA DE DONACIONES"); } }

        public static TitulosCabeceraExcel PROBLEMA { get { return new TitulosCabeceraExcel("LISTA DE PROBLEMAS"); } }
        public static TitulosCabeceraExcel CAMBIO { get { return new TitulosCabeceraExcel("LISTA DE CAMBIOS"); } }
        public static TitulosCabeceraExcel MANTENIMIENTO_USUARIO { get { return new TitulosCabeceraExcel("LISTA DE USUARIOS"); } }
        public static TitulosCabeceraExcel MANTENIMIENTO_APLICACION { get { return new TitulosCabeceraExcel("LISTA DE APLICACIONES"); } }
        public static TitulosCabeceraExcel MANTENIMIENTO_PERFILES { get { return new TitulosCabeceraExcel("LISTA DE PERFILES"); } }
        public static TitulosCabeceraExcel MANTENIMIENTO_OPCIONES { get { return new TitulosCabeceraExcel("LISTA DE OPCIONES"); } }
        public static TitulosCabeceraExcel MANTENIMIENTO_LISTA_VALORES { get { return new TitulosCabeceraExcel("LISTA DE VALORES"); } }
        public static TitulosCabeceraExcel MANTENIMIENTO_MENSAJE { get { return new TitulosCabeceraExcel("LISTA DE MENSAJES"); } }
        public static TitulosCabeceraExcel BITACORA_RECUPERACION_CLAVE { get { return new TitulosCabeceraExcel("BITÁCORA DE RECUPERACIÓN DE CLAVE"); } }
        public static TitulosCabeceraExcel BITACORA_SESION_USUARIOS { get { return new TitulosCabeceraExcel("BITÁCORA DE SESIÓN DE USUARIOS"); } }
        public static TitulosCabeceraExcel BITACORA_SESION_USUARIOS_DET { get { return new TitulosCabeceraExcel("DETALLE DE SESIONES DEL USUARIO"); } }
        public static TitulosCabeceraExcel BITACORA_ERROR_APLICACIONES { get { return new TitulosCabeceraExcel("BITÁCORA DE ERROR DE APLICACIONES"); } }
        public static TitulosCabeceraExcel OPCIONES_PERFIL { get { return new TitulosCabeceraExcel("LISTA DE OPCIONES POR PERFIL"); } }
        public static TitulosCabeceraExcel PERFIL_USUARIO { get { return new TitulosCabeceraExcel("LISTA DE PERFILES POR USUARIO"); } }

    }

    public class KeysWebConfig
    {
        private KeysWebConfig(string value) { Value = ConfigurationManager.AppSettings[value].ToString(); }
        public string Value { get; set; }
        public static KeysWebConfig URLLogoSD { get { return new KeysWebConfig("URLLogoSD"); } }
        public static KeysWebConfig MailServer { get { return new KeysWebConfig("mailServer"); } }
        public static KeysWebConfig MailPort { get { return new KeysWebConfig("mailPort"); } }
        public static KeysWebConfig MailFrom { get { return new KeysWebConfig("mailFrom"); } }
        public static KeysWebConfig MailPass { get { return new KeysWebConfig("mailPass"); } }

    }


    public class ParametrosClave
    {
        private ParametrosClave(string value) { Value = value; }
        public string Value { get; set; }
        public static ParametrosClave CLAVE_NUNCA_EXPIRA { get { return new ParametrosClave("069"); } }
        public static ParametrosClave VALIDAR_LONGITUD_CLAVE { get { return new ParametrosClave("070"); } }
        public static ParametrosClave MANTENER_HISTORIAL { get { return new ParametrosClave("071"); } }
        public static ParametrosClave CARACTERES_CONSECUTIVOS { get { return new ParametrosClave("072"); } }
        public static ParametrosClave BLOQUEO_USUARIO { get { return new ParametrosClave("073"); } }
        public static ParametrosClave CAMBIO_INMEDIATAMENTE { get { return new ParametrosClave("074"); } }
        public static ParametrosClave VALIDAR_CLAVE_ALFANUMERICA { get { return new ParametrosClave("075"); } }
        public static ParametrosClave CLAVE_IGUAL_LOGIN { get { return new ParametrosClave("076"); } }
    }
}