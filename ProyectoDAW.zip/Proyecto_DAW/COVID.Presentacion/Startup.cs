﻿using Owin;
using Microsoft.Owin;
[assembly: OwinStartup(typeof(COVID.Presentacion.Startup))]

namespace COVID.Presentacion
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            // Any connection or hub wire up and configuration should go here
            app.MapSignalR();
        }
    }
}