﻿function ParametrosReadPersona() {

    var strNroDocumento = $("#htxtNroDocumento").val();
    var strApellidosNombres = $("#htxtApellidosNombres").val();
    return {
        strNroDocumento: strNroDocumento,
        strApellidosNombres: strApellidosNombres
    };
}

function Listar() {
    $.ajax({
        type: 'Get',
        dataType: 'json',
        cache: false,
        url: BASE_APP_URL + "Donacion/Leer_Persona_Pobre",
        data: ParametrosReadPersona(),
        beforeSend: addLoading("ContenidoWeb"),
        success: function (data) {
            clearLoading();
            var table = $('#tblPersonasPobres').DataTable();
            table.clear().draw();
            table.rows.add(data).draw();
        }
    });
}

$(document).ready(function () {
    $("#ul_1").css("display", "block");
    $('.form-control').keypress(function (e) {
        if (e.which == 13) {
            $("#btnConsultar").click();
            return false;
        }
    });
    $('#tblPersonasPobres').DataTable({
        //<"col-sm-3"l> -- Numero de registros por mostrar
        "dom": GfooterDT,
        bFilter: false,
        "bSort": false,
        "pageLength": CANTIDAD_REGISTROS_DATATABLE,
        responsive: true,
        "columns": [{
            "title": "ID", 'data': 'PERSONA_ID'
        }, {
            "title": "Tipo documento", 'data': 'TIPO_DOCUMENTO'
        }, {
            "title": "N° Documento", 'data': 'NRO_DOCUMENTO'
        }, {
            "title": "Apellidos Paterno", 'data': 'PATERNO'
        }, {
            "title": "Apellido Materno", 'data': 'MATERNO'
        }, {
            "title": "Nombres", 'data': 'NOMBRES'
        }, {
            "title": "Sexo", 'data': 'SEXO'
        }, {
            "title": "Dirección", 'data': 'DIRECCION'
        }, {
            "title": "Ver", render: function () { return GcolDTVer }
        }
        ],
        tableTools: {
            "sRowSelect": "single"
        }
    });

    /* AGREGAR BOTONERA AL FOOTER */
    $('#BotoneraUsuarios').appendTo('#Botonera');
    /* SELECCION REGISTRO */
    $("#tblPersonasPobres tbody").on('click', 'tr', function (event) {
        event.preventDefault();
        $("#tblPersonasPobres tbody tr").removeClass('row_selected');
        $(this).addClass('row_selected');
    });

    /*BOTONES*/
    /*BOTÓN CREAR*/
    $("#btnCrear").click(function (event) {
        event.preventDefault();
        var url = 'CrearPersona'
        window.location.href = url;
    });
    /*BOTÓN EDITAR*/
    /*$('#tblPersonasPobres tbody').on("dblclick", 'tr', function (event) {
        event.preventDefault();
        var $this = $(this);
        var row = $this.closest("tr");
        var strIdCodigoPersona = row.find('td:first').text();
        var url = BASE_APP_URL + 'Donacion/EditarPersona?$strIdCodigoPersona=' + EncriptarParametro(strIdCodigoPersona);
        window.location.href = url;
    });*/
    /*BOTÓN VER*/
    $("#tblPersonasPobres tbody").on('click', 'img.btnVer', function (event) {
        event.preventDefault();
        var $this = $(this);
        var row = $this.closest("tr");
        var strIdCodigoPersona = row.find('td:first').text();
        var url = BASE_APP_URL + 'Donacion/VerPersona?$strIdCodigoPersona=' + EncriptarParametro(strIdCodigoPersona);
        window.location.href = url
    });
    /*BOTÓN CONSULTAR*/
    $("#btnConsultar").click(function (event) {
        event.preventDefault();
        Listar();
    });
    Listar();

});

