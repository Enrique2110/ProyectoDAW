﻿var validCorreo = 0;

$(document).ready(function () {
    $("#ul_1").css("display", "block");

    /* BOTONES */
    $("#hbtnModificar").click(function (event) {
        event.preventDefault();
        $.validator.unobtrusive.parse("#frmModificar"); // Vuelva a cargar la validacion
        $("#frmModificar").data("validator").settings.ignore = ""; // tome en cuenta los campos ocultos
        if ($("#frmModificar").valid() && validCorreo == 0) {
            var intDonacionId = $("#htxtIdDonacion").val();
            var intEstadoDonacion = $("#hddlEstadoDonacion").val();
            var fileData = new FormData();
            fileData.append('intDonacionId', intDonacionId);
            fileData.append('intEstadoDonacion', intEstadoDonacion);
            $.ajax({
                cache: false,
                type: "POST",
                contentType: false, // Not to set any content header  
                processData: false,
                url: BASE_APP_URL + "Donacion/Modificar",
                data: fileData,
                dataType: "json",
                beforeSend: addLoading("ContenidoWeb"),
                success: function (result) {
                    clearLoading();
                    if (result.strRespuesta == '0') {
                        var url = 'Listar'
                        window.location.href = url;
                    } else {
                        bootbox.alert("Ocurrió un error en el registro, vuelva a intentarlo.", null);
                    }
                },
                error: function () {
                    bootbox.alert("Ocurrió un error en el registro, vuelva a intentarlo.", null);
                }
            });
        }
    });
    $("#btnCancelar").click(function (event) {
        event.preventDefault();
        var url = 'Listar'
        window.location.href = url;
    });

});

