﻿var validCorreo = 0;

$(document).ready(function () {
    $("#ul_1").css("display", "block");

    /* BOTONES */
    $("#hbtnGuardar").click(function (event) {
        event.preventDefault();
        $.validator.unobtrusive.parse("#frmCrear"); // Vuelva a cargar la validacion
        $("#frmCrear").data("validator").settings.ignore = ""; // tome en cuenta los campos ocultos
        if ($("#frmCrear").valid()) {
            var intTipoDocumento = $("#hddlTipoDocumento").val();
            var strNroDocumento = $("#htxtNroDocumento").val();
            var strApellidoPaterno = $("#htxtApellidoPaterno").val();
            var strApellidoMaterno = $("#htxtApellidoMaterno").val();
            var strNombres = $("#htxtNombre").val();
            var intSexo = $("#hddlSexo").val();
            var intTipoDonacion = $("#hddlTipoDonacion").val();
            var intEstadoDonacion = $("#hddlEstadoDonacion").val();
            var strDescripcion = $("#htxtDescripcionDonacion").val();
            var intCantidad = $("#htxtCantidad").val();
            // Create FormData object  
            var fileData = new FormData();
            fileData.append('intTipoDocumento', intTipoDocumento);
            fileData.append('strNroDocumento', strNroDocumento);
            fileData.append('strApellidoPaterno', strApellidoPaterno);
            fileData.append('strApellidoMaterno', strApellidoMaterno);
            fileData.append('strNombres', strNombres);
            fileData.append('intSexo', intSexo);
            fileData.append('intTipoDonacion', intTipoDonacion);
            fileData.append('intEstadoDonacion', intEstadoDonacion);
            fileData.append('strDescripcion', strDescripcion);
            fileData.append('intCantidad', intCantidad);
            $.ajax({
                cache: false,
                type: "POST",
                contentType: false, // Not to set any content header  
                processData: false,
                url: BASE_APP_URL + "Donacion/Guardar",
                data: fileData,
                dataType: "json",
                beforeSend: addLoading("ContenidoWeb"),
                success: function (result) {
                    clearLoading();
                    if (result.strRespuesta == '0') {
                        var url = 'Listar'
                        window.location.href = url;
                    } else {
                        bootbox.alert("Ocurrió un error en el registro, vuelva a intentarlo.", null);
                    }
                },
                error: function () {
                    bootbox.alert("Ocurrió un error en el registro, vuelva a intentarlo.", null);
                }
            });
        }
    });
    $("#hbtnCancelar").click(function (event) {
        event.preventDefault();
        var url = 'Listar'
        window.location.href = url;
    });

    $(document).on("keydown", function (e) {
        console.log("nope");
        if (e.which === 8 && !$(e.target).is("input, textarea")) {
            e.preventDefault();
        }
    });
    $(".fake-select").on("click", function () {
        var numOfOpen = $("select.select option").size();
        $(".select").attr("size", numOfOpen).css("overflow", "hidden");
        $(this).hide();
    });

    $(".select").on("click", function () {
        $(".select").attr("size", 1);
        $(".fake-select").show();
    });
    //Just to view what is selected
    $(".select option").on("mouseover", function () {
        $(this).prop("selected", true);
    });

    $(document).on('change', '.btn-file :file', function () {
        var input = $(this),
			label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
        input.trigger('fileselect', [label]);
    });

    $('.btn-file :file').on('fileselect', function (event, label) {

        var input = $(this).parents('.input-group').find(':text'),
            log = label;

        if (input.length) {
            input.val(log);
        } else {
            if (log) alert(log);
        }

    });

    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#imagen-tag').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#imagen").change(function () {
        readURL(this);
    });

});



