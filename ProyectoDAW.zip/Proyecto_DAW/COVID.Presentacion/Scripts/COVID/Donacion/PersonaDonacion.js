﻿
function ParametrosReadParametros(intTipoConsulta) {
    var intPersonaId = $("#hhdnIdPersona").val();
    return {
        intPersonaId: intPersonaId,
        intTipoConsulta: intTipoConsulta
    };
}
function Listar(intTipoConsulta) {
    $.ajax({
        type: 'Get',
        dataType: 'json',
        cache: false,
        url: BASE_APP_URL + "Donacion/Leer_Donacion_Persona",
        data: ParametrosReadParametros(intTipoConsulta),
        beforeSend: addLoading("ContenidoWeb"),
        success: function (data) {
            clearLoading();
            if (intTipoConsulta == 1) {
                var table = $('#tblDonacionesDisponibles').DataTable();
                table.clear().draw();
                table.rows.add(data).draw();
            } else {
                var table = $('#tblDonacionesAsignadas').DataTable();
                table.clear().draw();
                table.rows.add(data).draw();
            }
        }
    });
}


$(document).ready(function () {
    $("#ul_2").css("display", "block");
    var tblOpciones = $("#tblDonacionesDisponibles");
    tblOpciones.dataTable({
        "dom": GfooterDTOpcion,
        bFilter: false,
        "ordering": false,
        "bSort": false,
        "pageLength": CANTIDAD_REGISTROS_DATATABLE,
        responsive: true,
        bAutoWidth: false,
        "columns": [{
            "title": "Código", 'data': 'DONACION_ID'//, 'className': 'hide_column_dataTable'
        }, {
            "title": "", render: function () { return GcolDTArrowRight }
        }, {
            "title": "Descripción", 'data': 'DESCRIPCION_DONACION'
        }, {
            "title": "Cantidad", 'data': 'CANTIDAD'
        }
        ]
    });
    var tblOpcionesActuales = $("#tblDonacionesAsignadas");
    tblOpcionesActuales.dataTable({
        "dom": GfooterDTOpcion,
        bFilter: false,
        "ordering": false,
        "bSort": false,
        "pageLength": CANTIDAD_REGISTROS_DATATABLE,
        responsive: true,
        bAutoWidth: false,
        "columns": [{
            "title": "Código", 'data': 'DONACION_ID'//, 'className': 'hide_column_dataTable'
        }, {
            "title": "Descripción", 'data': 'DESCRIPCION_DONACION'
        }, {
            "title": "Cantidad", 'data': 'CANTIDAD'
        }, {
            "title": "", render: function () { return GcolDTArrowLeft }
        }
        ]
    });

    Listar(1);
    Listar(2);

    var tr,
    row,
    rowData;
    var tblDonacionesAsignadasDT = $('#tblDonacionesAsignadas').DataTable();
    var tblDonacionesDT = $('#tblDonacionesDisponibles').DataTable();
    $("#tblDonacionesAsignadas tbody").on('click', 'img.btnConfigurar', function () {

        tr = $(this).closest('tr');
        row = tblDonacionesAsignadasDT.row(tr);
        rowData = [];
        tr.find('td').each(function (i, td) {
            rowData.push($(td).html());
        });
        row.remove().draw();

        tblDonacionesDT.row.add({
            "DONACION_ID": rowData[0],
            "DESCRIPCION_DONACION": rowData[1],
            "CANTIDAD": rowData[2],
        }).draw();
    });
    $("#tblDonacionesDisponibles tbody").on('click', 'img.btnConfigurar', function () {
        tr = $(this).closest('tr');
        row = tblDonacionesDT.row(tr);
        rowData = [];
        tr.find('td').each(function (i, td) {
            rowData.push($(td).html());
        });
        row.remove().draw();
        tblDonacionesAsignadasDT.row.add({
            "DONACION_ID": rowData[0],
            "DESCRIPCION_DONACION": rowData[2],
            "CANTIDAD": rowData[3]
        }).draw();
    });


    /*BOTONES*/
    $("#hbtnCancelar").click(function (event) {
        event.preventDefault();
        var url = 'ListarDonacionPersona'
        window.location.href = url;
    });

    $("#hbtnGuardar").click(function (event) {
        event.preventDefault();
        var intPersonaID = $("#hhdnIdPersona").val();
        var rows = $("#tblDonacionesAsignadas").dataTable().fnGetNodes();
        var myObject = {};
        myObject.DONACIONES = [];
        for (var i = 0; i < rows.length; i++) {
            myObject.DONACIONES.push({});
            myObject.DONACIONES[i]['PERSONA_ID'] = intPersonaID;
            myObject.DONACIONES[i]['DONACION_ID'] = $(rows[i]).find("td:eq(0)").html();
            myObject.DONACIONES[i]['DESCRIPCION_DONACION'] = $(rows[i]).find("td:eq(2)").html();
        }
        if (rows.length == 0) {
            myObject.DONACIONES.push({});
            myObject.DONACIONES[i]['PERSONA_ID'] = intRolID;
            myObject.DONACIONES[i]['DONACION_ID'] = 0;
            myObject.DONACIONES[i]['DESCRIPCION_DONACION'] = '';
        }
        $.ajax({
            cache: false,
            url: BASE_APP_URL + "Donacion/GuardarDonacionPersona",
            type: "POST",
            data: JSON.stringify(myObject),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            beforeSend: addLoading("ContenidoWeb"),
            error: function (response) {
                bootbox.alert("Error", null);
            },
            success: function (result) {
                clearLoading();
                if (result.strRespuesta == 1) {
                    var url = 'ListarDonacionPersona'
                    window.location.href = url;
                } else {
                    bootbox.alert("Ocurrió un error al registrar.", null);
                }
            }
        });
    });
    /*BOTÓN VER*/
    $("#tblDonacionesDisponibles tbody").on('click', 'img.btnVer', function (event) {
        event.preventDefault();
        var $this = $(this);
        var row = $this.closest("tr");
        var intIdPersona = $("#hhdnIdPersona").val();
        var intIdOpcion = row.find('td:nth-child(1)').text();
    });
    $("#tblDonacionesAsignadas tbody").on('click', 'img.btnVer', function (event) {
        event.preventDefault();
        var $this = $(this);
        var row = $this.closest("tr");
        var intIdPersona = $("#hhdnIdPersona").val();
        var intIdOpcion = row.find('td:nth-child(1)').text();
    });
});




