﻿/*LISTADO*/
$(document).ready(function () {
    $("#ul_1").css("display", "block");
    /* BOTONES */
    $("#btnCancelar").click(function (event) {
        event.preventDefault();
        var url = 'ListarPersonaPobre'
        window.location.href = url;
    });
});