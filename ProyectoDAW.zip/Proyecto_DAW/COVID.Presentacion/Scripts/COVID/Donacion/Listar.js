﻿function ParametrosReadDonacion() {
    var intTipoDonacion = $("#hddlTipoDonacion").val();
    var intEstado = $("#hddlEstado").val();
    return {
        intTipoDonacion: intTipoDonacion,
        intEstado: intEstado
    };
}

function Listar() {
    $.ajax({
        type: 'Get',
        dataType: 'json',
        cache: false,
        url: BASE_APP_URL + "Donacion/Leer_Donacion",
        data: ParametrosReadDonacion(),
        beforeSend: addLoading("ContenidoWeb"),
        success: function (data) {
            clearLoading();
            var table = $('#tblDonaciones').DataTable();
            table.clear().draw();
            table.rows.add(data).draw();
        }
    });
}

$(document).ready(function () {
    $("#ul_1").css("display", "block");
    $('.form-control').keypress(function (e) {
        if (e.which == 13) {
            $("#btnConsultar").click();
            return false;
        }
    });
    $('#tblDonaciones').DataTable({
        //<"col-sm-3"l> -- Numero de registros por mostrar
        "dom": GfooterDT,
        bFilter: false,
        "bSort": false,
        "pageLength": CANTIDAD_REGISTROS_DATATABLE,
        responsive: true,
        "columns": [{
            "title": "ID", 'data': 'DONACION_ID'
        }, {
            "title": "Apellido Paterno", 'data': 'PATERNO_DONANTE'
        }, {
            "title": "Apellido Materno", 'data': 'MATERNO_DONANTE'
        }, {
            "title": "Nombres", 'data': 'NOMBRE_DONANTE'
        }, {
            "title": "Tipo Donación", 'data': 'TIPO_DONACION'
        }, {
            "title": "Estado Donación", 'data': 'ESTADO_DONACION'
        }, {
            "title": "Descripción", 'data': 'DESCRIPCION_DONACION'
        }, {
            "title": "Cantidad", 'data': 'CANTIDAD'
        }, {
            "title": "Fecha Registro", 'data': 'FECHA_REGISTRO'
        }, {
            "title": "Ver", render: function () { return GcolDTVer }
        }
        ],
        tableTools: {
            "sRowSelect": "single"
        },
        "fnRowCallback": function (nRow, aData, iDisplayIndex) {
            if (aData["ESTADO_DONACION"] == 'Pendiente') {
                $('td:eq(5)', nRow).html('<span class="badge bg-red">Pendiente</span>');
            }
            else {
                if (aData["ESTADO_DONACION"] == 'Confirmado') {
                    $('td:eq(5)', nRow).html('<span class="badge bg-green">Confirmado</span>');
                }
            }
        }
    });

    /* AGREGAR BOTONERA AL FOOTER */
    $('#BotoneraUsuarios').appendTo('#Botonera');

    $('#tblDonaciones tbody').on("dblclick", 'tr', function (event) {
        event.preventDefault();
        var $this = $(this);
        var row = $this.closest("tr");
        var strIdDonacion = row.find('td:first').text();
        var url = BASE_APP_URL + 'Donacion/Editar?$strIdDonacion=' + EncriptarParametro(strIdDonacion);
        window.location.href = url;
    });

    /* SELECCION REGISTRO */
    $("#tblDonaciones tbody").on('click', 'tr', function (event) {
        event.preventDefault();
        $("#tblDonaciones tbody tr").removeClass('row_selected');
        $(this).addClass('row_selected');
    });

    /*BOTONES*/
    /*BOTÓN CREAR*/
    $("#btnCrear").click(function (event) {
        event.preventDefault();
        var url = 'Crear'
        window.location.href = url;
    });

    /*BOTÓN VER*/
    $("#tblDonaciones tbody").on('click', 'img.btnVer', function (event) {
        event.preventDefault();
        var $this = $(this);
        var row = $this.closest("tr");
        var strIdDonacion = row.find('td:first').text();
        var url = BASE_APP_URL + 'Donacion/Ver?$strIdDonacion=' + EncriptarParametro(strIdDonacion);
        window.location.href = url
    });

    /*BOTÓN CONSULTAR*/
    $("#btnConsultar").click(function (event) {
        event.preventDefault();
        Listar();
    });
    Listar();

});

