﻿function ParametrosReadPersona() {
    var strNombrePersona = $("#htxtNombrePersona").val();
    return {
        strNombrePersona: strNombrePersona
    };
}

function Listar() {
    $.ajax({
        type: 'Get',
        dataType: 'json',
        cache: false,
        url: BASE_APP_URL + "Donacion/Leer_Persona_Pobre_Entrega",
        data: ParametrosReadPersona(),
        beforeSend: addLoading("ContenidoWeb"),
        success: function (data) {
            clearLoading();
            var table = $('#tblPersonasPobres').DataTable();
            table.clear().draw();
            table.rows.add(data).draw();
        }
    });
}
$(document).ready(function () {
    $("#ul_2").css("display", "block");
    $('#tblPersonasPobres').DataTable({
        //<"col-sm-3"l> -- Numero de registros por mostrar
        "dom": GfooterDT,
        "lengthMenu": [[5, 25, 50, -1], [5, 25, 50, "All"]],
        bFilter: false,
        "bSort": false,
        "pageLength": CANTIDAD_REGISTROS_DATATABLE,
        responsive: true,
        "columns": [{
            "title": "ID", 'data': 'PERSONA_ID'
        }, {
            "title": "Tipo Documento", 'data': 'TIPO_DOCUMENTO'
        }, {
            "title": "Nro.Documento", 'data': 'NRO_DOCUMENTO'
        }, {
            "title": "Apellido Paterno", 'data': 'PATERNO'
        }, {
            "title": "Apellido Materno", 'data': 'MATERNO'
        }, {
            "title": "Nombres", 'data': 'NOMBRES'
        }, {
            "title": "Donación", render: function () { return GcolDTConfig }
        }
        ],
        tableTools: {
            "sRowSelect": "single"
        }

    });

    Listar();

    /* SELECCION REGISTRO */
    $("#tblPersonasPobres tbody").on('click', 'tr', function (event) {
        event.preventDefault();
        $("#tblPersonasPobres tbody tr").removeClass('row_selected');
        $(this).addClass('row_selected');
    });
    /*BOTONES*/
    $("#btnConsultar").click(function (event) {
        event.preventDefault();
        Listar();
    });
    /*BOTÓN CONFIGURAR*/
    $('#tblPersonasPobres tbody').on("dblclick", 'tr', function (event) {
        event.preventDefault();
        var $this = $(this);
        var row = $this.closest("tr");
        var intIdPersona = row.find('td:first').text();
        var strPaterno = row.find('td:nth-child(4)').text();
        var strMaterno = row.find('td:nth-child(5)').text();
        var strNombres = row.find('td:nth-child(6)').text();
        var strNombreCompleto = strNombres + " " + strPaterno + " " + strMaterno;
        var url = BASE_APP_URL + 'Donacion/PersonaDonacion?$intIdPersona=' + EncriptarParametro(intIdPersona) + '&strNombreCompleto=' + EncriptarParametro(strNombreCompleto);
        window.location.href = url;
    });
    /*BOTÓN CONFIGURAR*/
    $("#tblPersonasPobres tbody").on('click', 'img.btnConfigurar', function (event) {
        event.preventDefault();
        var $this = $(this);
        var row = $this.closest("tr");
        var intIdPersona = row.find('td:first').text();
        var strPaterno = row.find('td:nth-child(4)').text();
        var strMaterno = row.find('td:nth-child(5)').text();
        var strNombres = row.find('td:nth-child(6)').text();
        var strNombreCompleto = strNombres + " " + strPaterno + " " + strMaterno;
        var url = BASE_APP_URL + 'Donacion/PersonaDonacion?$intIdPersona=' + EncriptarParametro(intIdPersona) + '&$strNombreCompleto=' + EncriptarParametro(strNombreCompleto);
        window.location.href = url;
    });

});