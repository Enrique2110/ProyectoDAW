﻿function ParametrosReadTicket() {
    var intEstadoTicket = $("#hddlEstadoTicket").val();
    var intPrioridadTicket = $("#hddlPrioridad").val();
    var intIncidenteTicket = $("#hddlIncidente").val();
    var strUsuario = $("#htxtUsuario").val();
    var strOperador = $("#htxtOperador").val();
    var strFechaInicial = $("#htxtFechaInicial").val();
    var strFechaFinal = $("#htxtFechaFinal").val();
    return {
        intEstadoTicket: intEstadoTicket,
        intPrioridadTicket: intPrioridadTicket,
        intIncidenteTicket: intIncidenteTicket,
        strUsuario: strUsuario,
        strOperador: strOperador,
        strFechaInicial: strFechaInicial,
        strFechaFinal: strFechaFinal
    };
}

function Listar() {
    $.ajax({
        type: 'Get',
        dataType: 'json',
        cache: false,
        url: BASE_APP_URL + "Reporte/Listar_Reporte",
        data: ParametrosReadTicket(),
        beforeSend: addLoading("ContenidoWeb"),
        success: function (data) {
            clearLoading();
            var table = $('#tblTickets').DataTable();
            table.clear().draw();
            table.rows.add(data).draw();
        }
    });
}

$(document).ready(function () {
    $("#ul_1").css("display", "block");
    $('#htxtFechaInicial1').datetimepicker({ format: "DD/MM/YYYY" });
    $('#htxtFechaFinal1').datetimepicker({ format: "DD/MM/YYYY" });

    $('.form-control').keypress(function (e) {
        if (e.which == 13) {
            $("#btnConsultar").click();
            return false;
        }
    });
    $('#tblTickets').DataTable({
        //<"col-sm-3"l> -- Numero de registros por mostrar
        "dom": GfooterDT,
        bFilter: false,
        "bSort": false,
        "pageLength": CANTIDAD_REGISTROS_DATATABLE,
        responsive: true,
        "columns": [{
            "title": "ID", 'data': 'TICKET_ID'
        }, {
            "title": "Fecha Registro", 'data': 'FECHA_CREACION'
        }, {
            "title": "Nro.Ticket", 'data': 'TICKET_NRO'
        }, {
            "title": "Estado", 'data': 'ESTADO_TICKET'
        }, {
            "title": "Prioridad", 'data': 'PRIORIDAD'
        }, {
            "title": "Tipo Ticket", 'data': 'TIPO_TICKET'
        }, {
            "title": "Datos del Usuario", 'data': 'USUARIO_REGISTRO'
        }, {
            "title": "Operador", 'data': 'OPERADOR'
        }, {
            "title": "Detalle", 'data': 'DETALLE'
        }, {
            "title": "Ver", render: function () { return GcolDTVer }
        }
        ],
        tableTools: {
            "sRowSelect": "single"
        },
        "fnRowCallback": function (nRow, aData, iDisplayIndex) {
            if (aData["ESTADO_TICKET"] == 'REGISTRADO' || aData["ESTADO_TICKET"] == 'Registrado') {
                $('td:eq(3)', nRow).html('<span class="badge bg-yellow">REGISTRADO</span>');
            }
            else {
                if (aData["ESTADO_TICKET"] == 'ASIGNADO' || aData["ESTADO_TICKET"] == 'Asignado') {
                    $('td:eq(3)', nRow).html('<span class="badge bg-blue">ASIGNADO</span>');
                }
                else {
                    if (aData["ESTADO_TICKET"] == 'EN ATENCIÓN' || aData["ESTADO_TICKET"] == 'En Atención') {
                        $('td:eq(3)', nRow).html('<span class="badge bg-gray">EN ATENCIÓN</span>');
                    }
                    else {
                        if (aData["ESTADO_TICKET"] == 'ATENDIDO' || aData["ESTADO_TICKET"] == 'Atendido') {
                            $('td:eq(3)', nRow).html('<span class="badge bg-red">ATENDIDO</span>');
                        }
                        else {
                            $('td:eq(3)', nRow).html('<span class="badge bg-green">CONFORME</span>');
                        }
                    }
                }
            }
        }
    });

    /* AGREGAR BOTONERA AL FOOTER */
    $('#BotoneraTickets').appendTo('#Botonera');
    /* SELECCION REGISTRO */
    $("#tblTickets tbody").on('click', 'tr', function (event) {
        event.preventDefault();
        $("#tblTickets tbody tr").removeClass('row_selected');
        $(this).addClass('row_selected');
    });

    /*BOTONES*/
    /*BOTÓN VER*/
    $("#tblTickets tbody").on('click', 'img.btnVer', function (event) {
        event.preventDefault();
        var $this = $(this);
        var row = $this.closest("tr");
        var strIdCodigoTicket = row.find('td:first').text();
        var estado = row.find('td').eq(3).text();
        var url = BASE_APP_URL + 'Reporte/VerTicket?$strIdCodigoTicket=' + EncriptarParametro(strIdCodigoTicket);
        window.location.href = url
    });
    /*BOTÓN CONSULTAR*/
    $("#btnConsultar").click(function (event) {
        event.preventDefault();
        Listar();
    });
    Listar();

});

