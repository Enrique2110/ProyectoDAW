﻿function ParametrosReadProblema() {
    var intEstadoProblema = $("#hddlEstadoProblema").val();
    var intPrioridadProblema = $("#hddlPrioridad").val();
    var intImpactoProblema = $("#hddlImpacto").val();
    var strUsuario = $("#htxtUsuario").val();
    var strOperador = $("#htxtOperador").val();
    var strFechaInicial = $("#htxtFechaInicial").val();
    var strFechaFinal = $("#htxtFechaFinal").val();
    return {
        intEstadoProblema: intEstadoProblema,
        intPrioridadProblema: intPrioridadProblema,
        intImpactoProblema: intImpactoProblema,
        strUsuario: strUsuario,
        strOperador: strOperador,
        strFechaInicial: strFechaInicial,
        strFechaFinal: strFechaFinal
    };
}

function Listar() {
    $.ajax({
        type: 'Get',
        dataType: 'json',
        cache: false,
        url: BASE_APP_URL + "Reporte/Listar_Reporte_Problema",
        data: ParametrosReadProblema(),
        beforeSend: addLoading("ContenidoWeb"),
        success: function (data) {
            clearLoading();
            var table = $('#tblProblemas').DataTable();
            table.clear().draw();
            table.rows.add(data).draw();
        }
    });
}

$(document).ready(function () {
    $("#ul_1").css("display", "block");
    $('#htxtFechaInicial1').datetimepicker({ format: "DD/MM/YYYY" });
    $('#htxtFechaFinal1').datetimepicker({ format: "DD/MM/YYYY" });

    $('.form-control').keypress(function (e) {
        if (e.which == 13) {
            $("#btnConsultar").click();
            return false;
        }
    });
    $('#tblProblemas').DataTable({
        //<"col-sm-3"l> -- Numero de registros por mostrar
        "dom": GfooterDT,
        bFilter: false,
        "bSort": false,
        "pageLength": CANTIDAD_REGISTROS_DATATABLE,
        responsive: true,
        "columns": [{
            "title": "ID", 'data': 'ID_PROBLEMA'
        }, {
            "title": "Fecha Registro", 'data': 'FECHA_CREACION'
        }, {
            "title": "Nro.Problema", 'data': 'NRO_PROBLEMA'
        }, {
            "title": "Estado", 'data': 'ESTADO_PROBLEMA'
        }, {
            "title": "Prioridad", 'data': 'PRIORIDAD'
        }, {
            "title": "Impacto", 'data': 'IMPACTO'
        }, {
            "title": "Datos del Usuario", 'data': 'USUARIO_REGISTRO'
        }, {
            "title": "Operador", 'data': 'OPERADOR'
        }, {
            "title": "Detalle", 'data': 'DETALLE'
        }, {
            "title": "Ver", render: function () { return GcolDTVer }
        }
        ],
        tableTools: {
            "sRowSelect": "single"
        },
        "fnRowCallback": function (nRow, aData, iDisplayIndex) {
            if (aData["ESTADO_PROBLEMA"] == 'SOLUCIONADO' || aData["ESTADO_PROBLEMA"] == 'Solucionado') {
                $('td:eq(3)', nRow).html('<span class="badge bg-yellow">SOLUCIONADO</span>');
            }
            else {
                if (aData["ESTADO_PROBLEMA"] == 'ASIGNADO' || aData["ESTADO_PROBLEMA"] == 'Asignado') {
                    $('td:eq(3)', nRow).html('<span class="badge bg-blue">ASIGNADO</span>');
                }
                else {
                    if (aData["ESTADO_PROBLEMA"] == 'ACEPTADO' || aData["ESTADO_PROBLEMA"] == 'Aceptado') {
                        $('td:eq(3)', nRow).html('<span class="badge bg-red">ACEPTADO</span>');
                    }
                }
            }
        }
    });

    /* AGREGAR BOTONERA AL FOOTER */
    $('#BotoneraTickets').appendTo('#Botonera');
    /* SELECCION REGISTRO */
    $("#tblProblemas tbody").on('click', 'tr', function (event) {
        event.preventDefault();
        $("#tblProblemas tbody tr").removeClass('row_selected');
        $(this).addClass('row_selected');
    });

    /*BOTONES*/
    /*BOTÓN VER*/
    $("#tblProblemas tbody").on('click', 'img.btnVer', function (event) {
        event.preventDefault();
        var $this = $(this);
        var row = $this.closest("tr");
        var strIdCodigoProblema = row.find('td:first').text();
        var estado = row.find('td').eq(3).text();
        var url = BASE_APP_URL + 'Reporte/VerProblema?$strIdCodigoProblema=' + EncriptarParametro(strIdCodigoProblema);
        window.location.href = url
    });
    /*BOTÓN CONSULTAR*/
    $("#btnConsultar").click(function (event) {
        event.preventDefault();
        Listar();
    });
    Listar();

});

