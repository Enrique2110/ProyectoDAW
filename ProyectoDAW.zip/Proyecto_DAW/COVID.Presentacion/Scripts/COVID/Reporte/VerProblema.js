﻿
$(document).ready(function () {
    $("#ul_1").css("display", "block");

    $("#hbtnCancelar").click(function (event) {
        event.preventDefault();
        var url = 'ListarProblema'
        window.location.href = url;
    });

    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#imagen-tag').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#imagen").change(function () {
        readURL(this);
    });
});

