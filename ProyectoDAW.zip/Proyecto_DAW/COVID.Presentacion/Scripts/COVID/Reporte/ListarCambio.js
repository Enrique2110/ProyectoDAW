﻿function ParametrosReadCambio() {
    var intEstadoCambio = $("#hddlEstadoCambio").val();
    var intTipoCambio = $("#hddlTipoCambio").val();
    var intImpactoCambio = $("#hddlImpacto").val();
    var strUsuario = $("#htxtUsuario").val();
    var strFechaInicial = $("#htxtFechaInicial").val();
    var strFechaFinal = $("#htxtFechaFinal").val();
    return {
        intEstadoCambio: intEstadoCambio,
        intTipoCambio: intTipoCambio,
        intImpactoCambio: intImpactoCambio,
        strUsuario: strUsuario,
        strFechaInicial: strFechaInicial,
        strFechaFinal: strFechaFinal
    };
}

function Listar() {
    $.ajax({
        type: 'Get',
        dataType: 'json',
        cache: false,
        url: BASE_APP_URL + "Reporte/Listar_Reporte_Cambio",
        data: ParametrosReadCambio(),
        beforeSend: addLoading("ContenidoWeb"),
        success: function (data) {
            clearLoading();
            var table = $('#tblCambios').DataTable();
            table.clear().draw();
            table.rows.add(data).draw();
        }
    });
}

$(document).ready(function () {
    $("#ul_1").css("display", "block");
    $('#htxtFechaInicial1').datetimepicker({ format: "DD/MM/YYYY" });
    $('#htxtFechaFinal1').datetimepicker({ format: "DD/MM/YYYY" });

    $('.form-control').keypress(function (e) {
        if (e.which == 13) {
            $("#btnConsultar").click();
            return false;
        }
    });
    $('#tblCambios').DataTable({
        //<"col-sm-3"l> -- Numero de registros por mostrar
        "dom": GfooterDT,
        bFilter: false,
        "bSort": false,
        "pageLength": CANTIDAD_REGISTROS_DATATABLE,
        responsive: true,
        "columns": [{
            "title": "ID", 'data': 'CAMBIO_ID'
        }, {
            "title": "Fecha Registro", 'data': 'FECHA_CREACION'
        }, {
            "title": "Nro.Cambio", 'data': 'NRO_CAMBIO'
        }, {
            "title": "Estado", 'data': 'ESTADO_CAMBIO'
        }, {
            "title": "Tipo Cambio", 'data': 'TIPO_CAMBIO'
        }, {
            "title": "Impacto", 'data': 'IMPACTO'
        }, {
            "title": "Usuario Reporta", 'data': 'USUARIO_REPORTA'
        },  {
            "title": "Detalle", 'data': 'DETALLE'
        }, {
            "title": "Ver", render: function () { return GcolDTVer }
        }
        ],
        tableTools: {
            "sRowSelect": "single"
        },
        "fnRowCallback": function (nRow, aData, iDisplayIndex) {
            if (aData["ESTADO_CAMBIO"] == 'PROCEDE' || aData["ESTADO_CAMBIO"] == 'Procede') {
                $('td:eq(3)', nRow).html('<span class="badge bg-green">PROCEDE</span>');
            }
            else {
                if (aData["ESTADO_CAMBIO"] == 'ASIGNADO' || aData["ESTADO_CAMBIO"] == 'Asignado') {
                    $('td:eq(3)', nRow).html('<span class="badge bg-yellow">ASIGNADO</span>');
                }
                else {
                    if (aData["ESTADO_CAMBIO"] == 'NO PROCEDE' || aData["ESTADO_CAMBIO"] == 'No Procede') {
                        $('td:eq(3)', nRow).html('<span class="badge bg-red">NO PROCEDE</span>');
                    }
                }
            }
        }
    });

    /* AGREGAR BOTONERA AL FOOTER */
    $('#BotoneraTickets').appendTo('#Botonera');
    /* SELECCION REGISTRO */
    $("#tblCambios tbody").on('click', 'tr', function (event) {
        event.preventDefault();
        $("#tblCambios tbody tr").removeClass('row_selected');
        $(this).addClass('row_selected');
    });

    /*BOTONES*/
    /*BOTÓN VER*/
    $("#tblCambios tbody").on('click', 'img.btnVer', function (event) {
        event.preventDefault();
        var $this = $(this);
        var row = $this.closest("tr");
        var strIdCodigoCambio = row.find('td:first').text();
        var estado = row.find('td').eq(3).text();
        var url = BASE_APP_URL + 'Reporte/VerCambio?$strIdCodigoCambio=' + EncriptarParametro(strIdCodigoCambio);
        window.location.href = url
    });
    /*BOTÓN CONSULTAR*/
    $("#btnConsultar").click(function (event) {
        event.preventDefault();
        Listar();
    });
    Listar();

});

