﻿$.validator.addMethod("requireddropdownlist",
function (value, element, param) {
    var result = (value == -1 || value == '' || value == 0 ? false : true);
    return result;
});
// Muestra el mensaje
$.validator.unobtrusive.adapters.add('requireddropdownlist', {}, function (options) {
    options.rules['requireddropdownlist'] = true;
    options.messages['requireddropdownlist'] = options.message;
});
$(document).ready(function () {
    $("#ul_1").css("display", "block");
    $("#btnCancelar").click(function (event) {
        event.preventDefault();
        var url = 'Listar'
        window.location.href = url;
    });
    $("#hbtnModificar").click(function (event) {
        event.preventDefault();

        $.validator.unobtrusive.parse("#frmModificar"); // Vuelva a cargar la validacion
        $("#frmModificar").data("validator").settings.ignore = ""; // tome en cuenta los campos ocultos
        if ($("#frmModificar").valid()) {
            $.ajax({
                cache: false,
                type: "POST",
                url: BASE_APP_URL + "Opcion/Modificar",
                data: $("#frmModificar").serialize(),
                dataType: "json",
                beforeSend: addLoading("ContenidoWeb"),
                success: function (result) {
                    clearLoading();
                    if (result.strRespuesta == '0') {
                        var url = 'Listar'
                        window.location.href = url;
                    } else {
                        bootbox.alert("Ocurrió un error en el registro.", null);
                    }
                },
                error: function () {
                    bootbox.alert("Ocurrió un error en el registro.", null);
                }
            });
        }
    });
});
