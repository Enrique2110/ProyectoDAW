﻿function ParametrosReadOpcion() {
    var strNombreOpcion = $("#htxtOpcion").val();
    return {
        strNombreOpcion: strNombreOpcion
    };
}
function Listar() {
    $.ajax({
        type: 'Get',
        dataType: 'json',
        cache: false,
        url: BASE_APP_URL + "Opcion/Leer_Opcion",
        data: ParametrosReadOpcion(),
        beforeSend: addLoading("ContenidoWeb"),
        success: function (data) {
            clearLoading();
            var table = $('#tblOpciones').DataTable();
            table.clear().draw();
            table.rows.add(data).draw();
        }
    });
}
$(document).ready(function () {
    $("#ul_1").css("display", "block");
    $('.form-control').keypress(function (e) {
        if (e.which == 13) {
            $("#btnConsultar").click();
            return false;
        }
    });
    $('#tblOpciones').DataTable({
        //<"col-sm-3"l> -- Numero de registros por mostrar
        "dom": GfooterDT,
        "lengthMenu": [[5, 25, 50, -1], [5, 25, 50, "All"]],
        bFilter: false,
        "bSort": false,
        "pageLength": CANTIDAD_REGISTROS_DATATABLE,
        responsive: true,
        "columns": [{
            "title": "ID", 'data': 'OPCION_ID'
        }, {
            "title": "Nombre de la Opción", 'data': 'NOMBRE'
        }, {
            "title": "Estado", 'data': 'ESTADO_DESCRIPCION'
        }, {
            "title": "Ver", render: function () { return GcolDTVer }
        }
        ],
        tableTools: {
            "sRowSelect": "single"
        }
    });
    Listar();
    /* AGREGAR BOTONERA AL FOOTER */
    $('#BotoneraOpciones').appendTo('#Botonera');
    /* SELECCION REGISTRO */
    $("#tblOpciones tbody").on('click', 'tr', function (event) {
        event.preventDefault();
        $("#tblOpciones tbody tr").removeClass('row_selected');
        $(this).addClass('row_selected');
    });

    /*BOTONES*/
    /*BOTÓN CREAR*/
    $("#btnCrear").click(function (event) {
        event.preventDefault();
        var url = 'Crear'
        window.location.href = url;
    });
    /*BOTÓN EDITAR*/
    $('#tblOpciones tbody').on("dblclick", 'tr', function (event) {
        event.preventDefault();
        var $this = $(this);
        var row = $this.closest("tr");
        var intIdCodigoOpcion = row.find('td:first').text();
        var url = BASE_APP_URL + 'Opcion/Editar?$intIdCodigoOpcion=' + EncriptarParametro(intIdCodigoOpcion);
        window.location.href = url;
    });
    /*BOTÓN VER*/
    $("#tblOpciones tbody").on('click', 'img.btnVer', function (event) {
        event.preventDefault();
        var $this = $(this);
        var row = $this.closest("tr");
        var intIdCodigoOpcion = row.find('td:first').text();
        var url = BASE_APP_URL + 'Opcion/Ver?$intIdCodigoOpcion=' + EncriptarParametro(intIdCodigoOpcion);
        window.location.href = url;
    });
    /*BOTÓN CONSULTAR*/
    $("#btnConsultar").click(function (event) {
        event.preventDefault();
        Listar();
    });
});