﻿var validCorreo = 0;

function LimpiarControles() {

    $('#htxtLogin').val('');
    $('#htxtCorreoElectronico').val('');
    $('#htxtTelefono').val('');
    $('#hhdnLogin').val('');
    $('#htxtNumeroDocumento').val('');
    $('#htxtApellidoPaterno').val('');
    $('#htxtApellidoMaterno').val('');
    $('#htxtNombrePC').val('');
    $('#htxtNombres').val('');
    $('#htxtTelefono').val('');
    $('#htxtCelular').val('');
    $('#hddlTipoDocumento')[0].selectedIndex = 0;
    $('#hddlEstado')[0].selectedIndex = 0;
}
function CambioTipoUsuario(intTipoUsuario) {
    $('#htxtUsuarioWindows').val('');
    LimpiarControles();
    if (intTipoUsuario == 1) {
        $('#htxtUsuarioWindows').prop('readonly', false);
        $('#htxtUsuarioWindows').focus();
        $('#hbtnBuscarAD').css("visibility", "visible");

    } else {
        $('#htxtUsuarioWindows').prop('readonly', true);
        $('#htxtLogin').focus();
        $('#hbtnBuscarAD').css("visibility", "hidden");
    }
}

$(document).ready(function () {
    $("#ul_1").css("display", "block");

    /* BOTONES */    
    $("#hbtnGuardar").click(function (event) {
        event.preventDefault();
        $.validator.unobtrusive.parse("#frmCrear"); // Vuelva a cargar la validacion
        $("#frmCrear").data("validator").settings.ignore = ""; // tome en cuenta los campos ocultos
        if ($("#frmCrear").valid() && validCorreo == 0) {
            if ($("#htxtLogin").val() == '') {
                bootbox.alert("Ingrese un nombre de usuario.", null);
            } else {
                var strLogin = $("#htxtLogin").val();
                var strTipoDocumento = $("#hddlTipoDocumento").val();
                var strNroDocumento = $("#htxtNumeroDocumento").val();
                var strApellidoPaterno = $("#htxtApellidoPaterno").val();
                var strApellidoMaterno = $("#htxtApellidoMaterno").val();
                var strNombres = $("#htxtNombres").val();
                var strTelefono = $("#htxtTelefono").val();
                var strCelular = $("#htxtCelular").val();
                var strCorreo = $("#htxtCorreoElectronico").val();
                var strEstado = $("#hddlEstado").val();
                var strRol = $("#hddlRol").val();
                var strClave = $("#htxtContrasena").val();
                var strPC = $("#htxtNombrePC").val();
                var fileUpload = $("#imagen").get(0);
                var files = fileUpload.files;
                // Create FormData object  
                var fileData = new FormData();
                // Looping over all files and add it to FormData object  
                for (var i = 0; i < files.length; i++) {
                    fileData.append(files[i].name, files[i]);
                }
                fileData.append('login', strLogin);
                fileData.append('tipoDocumento', strTipoDocumento);
                fileData.append('nroDocumento', strNroDocumento);
                fileData.append('apellidoPaterno', strApellidoPaterno);
                fileData.append('apellidoMaterno', strApellidoMaterno);
                fileData.append('nombres', strNombres);
                fileData.append('telefono', strTelefono);
                fileData.append('celular', strCelular);
                fileData.append('correo', strCorreo);
                fileData.append('estado', strEstado);
                fileData.append('rol', strRol);
                fileData.append('clave', strClave);
                fileData.append('pc', strPC);
                $.ajax({
                    cache: false,
                    type: "POST",
                    contentType: false, // Not to set any content header  
                    processData: false,
                    url: BASE_APP_URL + "Usuario/Guardar",
                    //data: $("#frmCrear").serialize(),
                    data: fileData,
                    dataType: "json",
                    beforeSend: addLoading("ContenidoWeb"),
                    success: function (result) {
                        clearLoading();
                        if (result.strRespuesta == '0') {
                            var url = 'Listar'
                            window.location.href = url;
                        } else  {
                            bootbox.alert("Ocurrió un error en el registro, vuelva a intentarlo.", null);
                        } 
                    },
                    error: function () {
                        bootbox.alert("Ocurrió un error en el registro, vuelva a intentarlo.", null);
                    }
                });
            }

        }
    });
    $("#hbtnCancelar").click(function (event) {
        event.preventDefault();
        var url = 'Listar'
        window.location.href = url;
    });

    $('#hddlTipoUsuario').change(function () {
        CambioTipoUsuario($(this).val());
    });
    CambioTipoUsuario(1);


    $(document).on("keydown", function (e) {
        console.log("nope");
        if (e.which === 8 && !$(e.target).is("input, textarea")) {
            e.preventDefault();
        }
    });
    $(".fake-select").on("click", function () {
        var numOfOpen = $("select.select option").size();
        $(".select").attr("size", numOfOpen).css("overflow", "hidden");
        $(this).hide();
    });

    $(".select").on("click", function () {
        $(".select").attr("size", 1);
        $(".fake-select").show();
    });
    //Just to view what is selected
    $(".select option").on("mouseover", function () {
        $(this).prop("selected", true);
    });

    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#imagen-tag').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#imagen").change(function () {
        readURL(this);
    });
});




