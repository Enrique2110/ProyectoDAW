﻿/*LISTADO*/
function Parametros() {
    var intIdUsuario = $("#USUARIO_ID").val();
    return {
        intIdUsuario: intIdUsuario
    };
}

$(document).ready(function () {
    $("#ul_1").css("display", "block");    
    /* BOTONES */
    $("#btnCancelar").click(function (event) {
        event.preventDefault();
        var url = 'Listar'
        window.location.href = url;
    });
    $("#hbtnAuditoria").click(function (event) {
        event.preventDefault();
        var intIdUsuario = $("#USUARIO_ID").val();
        PopupAuditoria("USUARIO", "USUARIO_ID", intIdUsuario, '', '');
    });
});

