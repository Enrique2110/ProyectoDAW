﻿function ParametrosReadTicket() {
    var intEstadoTicket = $("#hddlEstadoTicket").val();
    var intPrioridadTicket = $("#hddlPrioridad").val();
    var intIncidenteTicket = $("#hddlIncidente").val();
    return {
        intEstadoTicket: intEstadoTicket,
        intPrioridadTicket: intPrioridadTicket,
        intIncidenteTicket: intIncidenteTicket
    };
}

function Listar() {
    $.ajax({
        type: 'Get',
        dataType: 'json',
        cache: false,
        url: BASE_APP_URL + "Ticket/Leer_TicketsOperador",
        data: ParametrosReadTicket(),
        beforeSend: addLoading("ContenidoWeb"),
        success: function (data) {
            clearLoading();
            var table = $('#tblTickets').DataTable();
            table.clear().draw();
            table.rows.add(data).draw();
        }
    });
}

$(document).ready(function () {
    $("#ul_1").css("display", "block");
    $('.form-control').keypress(function (e) {
        if (e.which == 13) {
            $("#btnConsultar").click();
            return false;
        }
    });
    $('#tblTickets').DataTable({
        //<"col-sm-3"l> -- Numero de registros por mostrar
        "dom": GfooterDT,
        bFilter: false,
        "bSort": false,
        "pageLength": CANTIDAD_REGISTROS_DATATABLE,
        responsive: true,
        "columns": [{
            "title": "ID", 'data': 'TICKET_ID'
        }, {
            "title": "Fecha", 'data': 'FECHA_CREACION'
        }, {
            "title": "Nro.Ticket", 'data': 'TICKET_NRO'
        }, {
            "title": "Estado", 'data': 'ESTADO_TICKET'
        }, {
            "title": "Prioridad", 'data': 'PRIORIDAD'
        }, {
            "title": "Tipo Ticket", 'data': 'TIPO_TICKET'
        },{
            "title": "Usuario Ticket", 'data': 'USUARIO_REGISTRO'
        }, {
            "title": "Detalle", 'data': 'DETALLE'
        }, {
            "title": "Ver", render: function () { return GcolDTVer }
        }, {
            "title": "Chat", 'data':'LEIDO' //render: function () { return GcolDTChat }
        }
        ],
        tableTools: {
            "sRowSelect": "single"
        },
        "fnRowCallback": function (nRow, aData, iDisplayIndex) {
            if (aData["ESTADO_TICKET"] == 'REGISTRADO' || aData["ESTADO_TICKET"] == 'Registrado') {
                $('td:eq(3)', nRow).html('<span class="badge bg-yellow">REGISTRADO</span>');
            }
            else {
                if (aData["ESTADO_TICKET"] == 'ASIGNADO' || aData["ESTADO_TICKET"] == 'Asignado') {
                    $('td:eq(3)', nRow).html('<span class="badge bg-blue">ASIGNADO</span>');
                }
                else {
                    if (aData["ESTADO_TICKET"] == 'EN ATENCIÓN' || aData["ESTADO_TICKET"] == 'En Atención') {
                        $('td:eq(3)', nRow).html('<span class="badge bg-gray">EN ATENCIÓN</span>');
                    }
                    else {
                        if (aData["ESTADO_TICKET"] == 'ATENDIDO' || aData["ESTADO_TICKET"] == 'Atendido') {
                            $('td:eq(3)', nRow).html('<span class="badge bg-red">ATENDIDO</span>');
                        }
                        else {
                            $('td:eq(3)', nRow).html('<span class="badge bg-green">CONFORME</span>');
                        }
                    }
                }
            }

            if (aData["LEIDO"] == '0') {
                $('td:eq(9)', nRow).html('<center><img class="btnChat" src="' + "../Content/images/chat.png" + '"/></center>');
            }
            else {
                $('td:eq(9)', nRow).html('<center><img class="btnChat" src="' + "../Content/images/sinLeer.png" + '"/></center>');
            }

        }
    });

    /* AGREGAR BOTONERA AL FOOTER */
    $('#BotoneraUsuarios').appendTo('#Botonera');
    /* SELECCION REGISTRO */
    $("#tblTickets tbody").on('click', 'tr', function (event) {
        event.preventDefault();
        $("#tblTickets tbody tr").removeClass('row_selected');
        $(this).addClass('row_selected');
    });

    /*BOTONES*/
    /*BOTÓN CREAR*/
    $("#btnCrear").click(function (event) {
        event.preventDefault();
        var url = 'Crear'
        window.location.href = url;
    });

    /*BOTÓN VER*/
    $("#tblTickets tbody").on('click', 'img.btnVer', function (event) {
        event.preventDefault();
        var $this = $(this);
        var row = $this.closest("tr");
        var strIdCodigoTicket = row.find('td:first').text();
        var estado = row.find('td').eq(3).text();
        if (estado == 'Asignado' || estado=='En Atención' || estado=='ASIGNADO' || estado=='EN ATENCIÓN') {
            var url = BASE_APP_URL + 'Ticket/AtenderTicketOperador?$strIdCodigoTicket=' + EncriptarParametro(strIdCodigoTicket);
        }
        else {
            var url = BASE_APP_URL + 'Ticket/VerTicketOperador?$strIdCodigoTicket=' + EncriptarParametro(strIdCodigoTicket);
        }
        window.location.href = url
    });

    /*BOTÓN VER*/
    $("#tblTickets tbody").on('click', 'img.btnChat', function (event) {
        event.preventDefault();
        var $this = $(this);
        var row = $this.closest("tr");
        var strIdTicket = row.find('td:first').text();
        var url = BASE_APP_URL + 'Ticket/VerChat?$strIdTicket=' + EncriptarParametro(strIdTicket);
        window.location.href = url
    });

    /*BOTÓN CONSULTAR*/
    $("#btnConsultar").click(function (event) {
        event.preventDefault();
        Listar();
    });
    Listar();

});

