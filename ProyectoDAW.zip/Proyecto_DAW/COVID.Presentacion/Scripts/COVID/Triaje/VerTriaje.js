﻿$(document).ready(function () {
    $("#stars-default").rating();
    $("#stars-default2").rating();
    
    $("#ul_1").css("display", "block");

    $("#btnCancelar").click(function (event) {
        event.preventDefault();
        var url = 'Listar'
        window.location.href = url;
    });
});
