﻿function ParametrosReadTicket() {
    var intTipoPrueba = $("#hddlTipoPrueba").val();
    var intResultado = $("#hddlResultaldo").val();
    return {
        intTipoPrueba: intTipoPrueba,
        intResultado: intResultado
    };
}

function Listar() {
    $.ajax({
        type: 'Get',
        dataType: 'json',
        cache: false,
        url: BASE_APP_URL + "Triaje/Leer_Triaje",
        data: ParametrosReadTicket(),
        beforeSend: addLoading("ContenidoWeb"),
        success: function (data) {
            clearLoading();
            var table = $('#tblTriajes').DataTable();
            table.clear().draw();
            table.rows.add(data).draw();
        }
    });
}

$(document).ready(function () {
    $("#ul_1").css("display", "block");
    $('.form-control').keypress(function (e) {
        if (e.which == 13) {
            $("#btnConsultar").click();
            return false;
        }
    });
    $('#tblTriajes').DataTable({
        //<"col-sm-3"l> -- Numero de registros por mostrar
        "dom": GfooterDT,
        bFilter: false,
        "bSort": false,
        "pageLength": CANTIDAD_REGISTROS_DATATABLE,
        responsive: true,
        "columns": [{
            "title": "ID", 'data': 'TRIAJE_ID'
        }, {
            "title": "Apellido", 'data': 'APELLIDO_PACIENTE'
        }, {
            "title": "Nombre", 'data': 'NOMBRE_PACIENTE'
        }, {
            "title": "Resultado", 'data': 'RESULTADO'
        }, {
            "title": "Tipo Prueba", 'data': 'TIPO_PRUEBA'
        }, {
            "title": "Dirección", 'data': 'DIRECCION'
        }, {
            "title": "Profesión", 'data': 'PROFESION'
        },{
            "title": "Ver", render: function () { return GcolDTVer }
        }
        ],
        tableTools: {
            "sRowSelect": "single"
        },
        "fnRowCallback": function (nRow, aData, iDisplayIndex) {
            if (aData["RESULTADO"] == 'Positivo') {
                $('td:eq(4)', nRow).html('<span class="badge bg-red">Positivo</span>');
            }
            else {
                if (aData["RESULTADO"] == 'Negativo') {
                    $('td:eq(4)', nRow).html('<span class="badge bg-green">Negativo</span>');
                }
            }
        }
    });

    /* AGREGAR BOTONERA AL FOOTER */
    $('#BotoneraUsuarios').appendTo('#Botonera');
    /* SELECCION REGISTRO */
    $("#tblTriajes tbody").on('click', 'tr', function (event) {
        event.preventDefault();
        $("#tblTriajes tbody tr").removeClass('row_selected');
        $(this).addClass('row_selected');
    });

    /*BOTONES*/
    /*BOTÓN CREAR*/
    $("#btnCrear").click(function (event) {
        event.preventDefault();
        var url = 'Crear'
        window.location.href = url;
    });

    /*BOTÓN VER*/
    $("#tblTriajes tbody").on('click', 'img.btnVer', function (event) {
        event.preventDefault();
        var $this = $(this);
        var row = $this.closest("tr");
        var strIdTriaje = row.find('td:first').text();
        var url = BASE_APP_URL + 'Triaje/VerTriaje?$strIdTriaje=' + EncriptarParametro(strIdTriaje);
        window.location.href = url
    });

    /*BOTÓN CONSULTAR*/
    $("#btnConsultar").click(function (event) {
        event.preventDefault();
        Listar();
    });
    Listar();

});

