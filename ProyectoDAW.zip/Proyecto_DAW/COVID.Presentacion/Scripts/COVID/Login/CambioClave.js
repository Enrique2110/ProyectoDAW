﻿$(document).ready(function () {
    $("#hhdnLogin").val($("#hhdnLoginPrev").val());
    /* BOTONES */
    function Validar() {
        if ($("#htxtClaveActual").val().trim() == '') {
            $("#htxtClaveActual").focus();
            bootbox.alert("Ingrese la clave actual", null); // ObtenerMensaje("031")
            return false;
        }
        if ($("#htxtClaveNueva").val().trim() == '') {
            $("#htxtClaveNueva").focus();
            bootbox.alert("Ingrese la nueva clave", null); // ObtenerMensaje("032")
            return false;
        }
        if ($("#htxtClaveNueva").val() != $("#htxtClaveNuevaConfirma").val()) {
            bootbox.alert("La nueva clave y la confirmación de clave no coinciden", null); // ObtenerMensaje("033")
            return false;
        }

        return true;
    }
    $("#hbtnCambiarClave").click(function (event) {
        event.preventDefault();
        if (Validar()) {
            $.ajax({
                cache: false,
                type: "POST",
                url: BASE_APP_URL + "Login/CambiarClaveUsuario",
                data: $("#frmCambioClave").serialize(),
                dataType: "json",
                beforeSend: addLoading("ContenidoWeb"),
                success: function (result) {
                    clearLoading();
                    console.log(result.strRespuesta);

                    /*var obj = JSON.parse(result.strRespuesta)
                    if (obj.CODIGO_ERROR == "000") {
                        bootbox.alert(obj.DESCRIPCION_ERROR, function () {
                            var url = BASE_APP_URL + 'Login/LoginEstandar';
                            window.location.href = url;
                        });
                    } else {
                        bootbox.alert(obj.CODIGO_ERROR + ' ' + obj.DESCRIPCION_ERROR, null);
                    }*/
                },
                error: function () {
                    bootbox.alert(ObtenerMensaje("028"), null);
                }
            });
        }
    });
});