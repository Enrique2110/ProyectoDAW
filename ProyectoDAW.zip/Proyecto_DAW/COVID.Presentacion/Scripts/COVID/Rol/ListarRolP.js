﻿function ParametrosReadRol() {
    var strNombreRol = $("#htxtRol").val();
    return {
        strNombreRol: strNombreRol
    };
}

function Listar() {
    $.ajax({
        type: 'Get',
        dataType: 'json',
        cache: false,
        url: BASE_APP_URL + "Rol/Leer_Rol",
        data: ParametrosReadRol(),
        beforeSend: addLoading("ContenidoWeb"),
        success: function (data) {
            clearLoading();
            var table = $('#tblRolesOpcion').DataTable();
            table.clear().draw();
            table.rows.add(data).draw();
        }
    });
}
$(document).ready(function () {
    $("#ul_2").css("display", "block");
    /************************/
    // PERFILES
    $('#tblRolesOpcion').DataTable({
        //<"col-sm-3"l> -- Numero de registros por mostrar
        "dom": GfooterDT,
        "lengthMenu": [[5, 25, 50, -1], [5, 25, 50, "All"]],
        bFilter: false,
        "bSort": false,
        "pageLength": CANTIDAD_REGISTROS_DATATABLE,
        responsive: true,
        "columns": [{
            "title": "ID", 'data': 'ROL_ID'
        },  {
            "title": "Nombre de Rol", 'data': 'NOMBRE_ROL'
        }, {
            "title": "Estado", 'data': 'ESTADO_DESCRIPCION'
        }, {
            "title": "Configurar", render: function () { return GcolDTConfig }
        }
        ],
        tableTools: {
            "sRowSelect": "single"
        }

    });

    Listar();

    /* SELECCION REGISTRO */
    $("#tblRolesOpcion tbody").on('click', 'tr', function (event) {
        event.preventDefault();
        $("#tblRolesOpcion tbody tr").removeClass('row_selected');
        $(this).addClass('row_selected');
    });
    /*BOTONES*/
    $("#btnConsultar").click(function (event) {
        event.preventDefault();
        Listar();
    });
    /*BOTÓN CONFIGURAR*/
    $('#tblRolesOpcion tbody').on("dblclick", 'tr', function (event) {
        event.preventDefault();
        var $this = $(this);
        var row = $this.closest("tr");
        var intIdCodigoRol = row.find('td:first').text();
        var strNombreRol = row.find('td:nth-child(2)').text();
        var url = BASE_APP_URL + 'Rol/RolOpcion?$intIdCodigoRol=' + EncriptarParametro(intIdCodigoRol) + '&$strNombreRol=' + EncriptarParametro(strNombreRol);
        window.location.href = url;
    });
    /*BOTÓN CONFIGURAR*/
    $("#tblRolesOpcion tbody").on('click', 'img.btnConfigurar', function (event) {
        event.preventDefault();
        var $this = $(this);
        var row = $this.closest("tr");
        var intIdCodigoRol = row.find('td:first').text();
        var strNombreRol = row.find('td:nth-child(2)').text();
        var url = BASE_APP_URL + 'Rol/RolOpcion?$intIdCodigoRol=' + EncriptarParametro(intIdCodigoRol) + '&$strNombreRol=' + EncriptarParametro(strNombreRol);
        window.location.href = url;
    });

});