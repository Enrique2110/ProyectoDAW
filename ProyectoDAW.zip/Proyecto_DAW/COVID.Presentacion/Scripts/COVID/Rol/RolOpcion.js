﻿
function ParametrosReadOpcion(intTipoConsulta) {
    var intRolId = $("#hhdnIdRol").val();
    var intTipoConsulta = intTipoConsulta
    return {
        intRolId: intRolId,
        intTipoConsulta: intTipoConsulta
    };
}
function Listar(intTipoConsulta) {
    $.ajax({
        type: 'Get',
        dataType: 'json',
        cache: false,
        url: BASE_APP_URL + "Rol/Leer_Opcion",
        data: ParametrosReadOpcion(intTipoConsulta),
        beforeSend: addLoading("ContenidoWeb"),
        success: function (data) {
            clearLoading();
            if (intTipoConsulta == 1) {
                var table = $('#tblOpciones').DataTable();
                table.clear().draw();
                table.rows.add(data).draw();
            } else {
                var table = $('#tblOpcionesActuales').DataTable();
                table.clear().draw();
                table.rows.add(data).draw();
            }
        }
    });
}


$(document).ready(function () {
    $("#ul_2").css("display", "block");
    var tblOpciones = $("#tblOpciones");
    tblOpciones.dataTable({
        "dom": GfooterDTOpcion,
        bFilter: false,
        "ordering": false,
        "bSort": false,
        "pageLength": CANTIDAD_REGISTROS_DATATABLE,
        responsive: true,
        bAutoWidth: false,
        "columns": [{
            "title": "Código Interno", 'data': 'OPCION_ID'//, 'className': 'hide_column_dataTable'
        }, {
            "title": "", render: function () { return GcolDTArrowRight }
        }, {
            "title": "Opción", 'data': 'NOMBRE_OPCION'
        }
        ]
    });
    var tblOpcionesActuales = $("#tblOpcionesActuales");
    tblOpcionesActuales.dataTable({
        "dom": GfooterDTOpcion,
        bFilter: false,
        "ordering": false,
        "bSort": false,
        "pageLength": CANTIDAD_REGISTROS_DATATABLE,
        responsive: true,
        bAutoWidth: false,
        "columns": [{
            "title": "Código Interno", 'data': 'OPCION_ID'//, 'className': 'hide_column_dataTable'
        },  {
            "title": "Opción", 'data': 'NOMBRE_OPCION'
        }, {
            "title": "", render: function () { return GcolDTArrowLeft }
        }
        ]
    });

    Listar(1);
    Listar(2);

    var tr,
    row,
    rowData;
    var tblOpcionesActualesDT = $('#tblOpcionesActuales').DataTable();
    var tblOpcionesDT = $('#tblOpciones').DataTable();
    $("#tblOpcionesActuales tbody").on('click', 'img.btnConfigurar', function () {

        tr = $(this).closest('tr');
        row = tblOpcionesActualesDT.row(tr);
        rowData = [];
        tr.find('td').each(function (i, td) {
            rowData.push($(td).html());
        });
        row.remove().draw();

        tblOpcionesDT.row.add({
            "OPCION_ID": rowData[0],
            "NOMBRE_OPCION": rowData[1]
        }).draw();
    });
    $("#tblOpciones tbody").on('click', 'img.btnConfigurar', function () {
        tr = $(this).closest('tr');
        row = tblOpcionesDT.row(tr);
        rowData = [];
        tr.find('td').each(function (i, td) {
            rowData.push($(td).html());
        });
        row.remove().draw();
        tblOpcionesActualesDT.row.add({
            "OPCION_ID": rowData[0],
            "NOMBRE_OPCION": rowData[2]
        }).draw();
    });


    /*BOTONES*/
    $("#hbtnCancelar").click(function (event) {
        event.preventDefault();
        var url = 'ListarRolP'
        window.location.href = url;
    });

    $("#hbtnGuardar").click(function (event) {
        event.preventDefault();
        var intRolID = $("#hhdnIdRol").val();
        var rows = $("#tblOpcionesActuales").dataTable().fnGetNodes();
        var myObject = {};
        myObject.OPCIONES = [];
        for (var i = 0; i < rows.length; i++) {
            myObject.OPCIONES.push({});
            myObject.OPCIONES[i]['ROL_ID'] = intRolID;
            myObject.OPCIONES[i]['OPCION_ID'] = $(rows[i]).find("td:eq(0)").html();
            myObject.OPCIONES[i]['NOMBRE_OPCION'] = $(rows[i]).find("td:eq(2)").html();
        }
        if (rows.length == 0) {
            myObject.OPCIONES.push({});
            myObject.OPCIONES[i]['ROL_ID'] = intRolID;
            myObject.OPCIONES[i]['OPCION_ID'] = 0;
            myObject.OPCIONES[i]['NOMBRE_OPCION'] = '';
        }
        $.ajax({
            cache: false,
            url: BASE_APP_URL + "Rol/GuardarRolOpcion",
            type: "POST",
            data: JSON.stringify(myObject),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            beforeSend: addLoading("ContenidoWeb"),
            error: function (response) {
                bootbox.alert("Error", null);
            },
            success: function (result) {
                clearLoading();
                if (result.strRespuesta == 1) {
                    var url = 'ListarRolP'
                    window.location.href = url;
                } else {
                    bootbox.alert("Ocurrió un error al registrar.", null);
                }
            }
        });
    });
    /*BOTÓN VER*/
    $("#tblOpciones tbody").on('click', 'img.btnVer', function (event) {
        event.preventDefault();
        var $this = $(this);
        var row = $this.closest("tr");
        var intIdPerfil = $("#hhdnIdPerfil").val();
        var intIdOpcion = row.find('td:nth-child(1)').text();
    });
    $("#tblOpcionesActuales tbody").on('click', 'img.btnVer', function (event) {
        event.preventDefault();
        var $this = $(this);
        var row = $this.closest("tr");
        var intIdPerfil = $("#hhdnIdPerfil").val();
        var intIdOpcion = row.find('td:nth-child(1)').text();
    });
});




