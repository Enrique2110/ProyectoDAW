﻿function ParametrosReadRol() {
    var strNombreRol = $("#htxtRol").val();
    return {
        strNombreRol: strNombreRol
    };
}

function Listar() {
    $.ajax({
        type: 'Get',
        dataType: 'json',
        cache: false,
        url: BASE_APP_URL + "Rol/Leer_Rol",
        data: ParametrosReadRol(),
        beforeSend: addLoading("ContenidoWeb"),
        success: function (data) {
            clearLoading();
            var table = $('#tblRoles').DataTable();
            table.clear().draw();
            table.rows.add(data).draw();
        }
    });
}
$(document).ready(function () {
    $("#ul_1").css("display", "block");
    $('.form-control').keypress(function (e) {
        if (e.which == 13) {
            $("#btnConsultar").click();
            return false;
        }
    });
    // ROLES
    $('#tblRoles').DataTable({
        //<"col-sm-3"l> -- Numero de registros por mostrar
        "dom": GfooterDT,
        "lengthMenu": [[5, 25, 50, -1], [5, 25, 50, "All"]],
        bFilter: false,
        "bSort": false,
        "pageLength": CANTIDAD_REGISTROS_DATATABLE,
        responsive: true,
        "columns": [{
            "title": "ID", 'data': 'ROL_ID'
        }, {
            "title": "Nombre de Rol", 'data': 'NOMBRE_ROL'
        }, {
            "title": "Estado", 'data': 'ESTADO_DESCRIPCION'
        }, {
            "title": "Usuario Creación", 'data': 'USUARIO_CREACION'
        }, {
            "title": "Ver", render: function () { return GcolDTVer }
        }
        ],
        tableTools: {
            "sRowSelect": "single"
        }
    });
    Listar();
    /* AGREGAR BOTONERA AL FOOTER */
    $('#BotoneraPerfil').appendTo('#Botonera');
    /* SELECCION REGISTRO */
    $("#tblRoles tbody").on('click', 'tr', function (event) {
        event.preventDefault();
        $("#tblRoles tbody tr").removeClass('row_selected');
        $(this).addClass('row_selected');
    });

    /*BOTONES*/
    /*BOTÓN CREAR*/
    $("#btnCrear").click(function (event) {
        event.preventDefault();
        var url = 'Crear'
        window.location.href = url;
    });
    /*BOTÓN EDITAR*/
    $('#tblRoles tbody').on("dblclick", 'tr', function (event) {
        event.preventDefault();
        var $this = $(this);
        var row = $this.closest("tr");
        var intIdCodigoRol = row.find('td:first').text();
        var url = BASE_APP_URL + 'Rol/Editar?$intIdCodigoRol=' + EncriptarParametro(intIdCodigoRol);
        window.location.href = url;
    });
    /*BOTÓN VER*/
    $("#tblRoles tbody").on('click', 'img.btnVer', function (event) {
        event.preventDefault();
        var $this = $(this);
        var row = $this.closest("tr");
        var intIdCodigoRol = row.find('td:first').text();
        var url = BASE_APP_URL + 'Rol/Ver?$intIdCodigoRol=' + EncriptarParametro(intIdCodigoRol);
        window.location.href = url;
    });
    /*BOTÓN CONSULTAR*/
    $("#btnConsultar").click(function (event) {
        event.preventDefault();
        Listar();
    });
});