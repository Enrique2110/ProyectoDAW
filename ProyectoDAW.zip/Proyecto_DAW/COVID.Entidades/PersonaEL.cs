﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Entidades
{
    public class PersonaEL
    {
        private string _NOMBRE_COMPLETO;
        private string _DOCUMENTO;

        [Display(Name = "Nombre")]
        [StringLength(182)]
        public string NOMBRE_COMPLETO
        {
            get { return _NOMBRE_COMPLETO; }
            set { _NOMBRE_COMPLETO = value; }
        }

        [Display(Name = "Documento")]
        [StringLength(30)]
        [Required(ErrorMessage = "El campo Documento es obligatorio.")]
        public string DOCUMENTO
        {
            get { return _DOCUMENTO; }
            set { _DOCUMENTO = value; }
        }

        private int _TIPO_DOCUMENTO_CODIGO;
        [Display(Name = "Tipo Documento")]
        [Required(ErrorMessage = "El campo Tipo Documento es obligatorio.")]
        public int TIPO_DOCUMENTO_CODIGO
        {
            get { return _TIPO_DOCUMENTO_CODIGO; }
            set { _TIPO_DOCUMENTO_CODIGO = value; }
        }

        private string _APELLIDO_MATERNO;
        [Display(Name = "Apellido Materno")]
        [StringLength(60)]
        public string APELLIDO_MATERNO
        {
            get { return _APELLIDO_MATERNO; }
            set { _APELLIDO_MATERNO = value; }
        }

        private string _APELLIDO_PATERNO;
        [Display(Name = "Apellido Paterno")]
        [StringLength(60)]
        [Required(ErrorMessage = "El campo Apellido Paterno es obligatorio.")]
        public string APELLIDO_PATERNO
        {
            get { return _APELLIDO_PATERNO; }
            set { _APELLIDO_PATERNO = value; }
        }

        private string _NOMBRE;
        [Display(Name = "Nombre")]
        [StringLength(60)]
        [Required(ErrorMessage = "El campo Nombre es obligatorio.")]
        public string NOMBRE
        {
            get { return _NOMBRE; }
            set { _NOMBRE = value; }
        }

        private string _TELEFONO;
        [Display(Name = "Teléfono")]
        [StringLength(20)]
        public string TELEFONO
        {
            get { return _TELEFONO; }
            set { _TELEFONO = value; }
        }

        private int _SEXO_CODIGO;
        [Display(Name = "Sexo")]
        [Required(ErrorMessage = "El campo Sexo es obligatorio.")]
        public int SEXO_CODIGO
        {
            get { return _SEXO_CODIGO; }
            set { _SEXO_CODIGO = value; }
        }

        private string _FECHA_NACIMIENTO;
        [Display(Name = "Fecha Nacimiento")]
        [Required(ErrorMessage = "El campo Fecha de Nacimiento es obligatorio.")]
        public string FECHA_NACIMIENTO
        {
            get { return _FECHA_NACIMIENTO; }
            set { _FECHA_NACIMIENTO = value; }
        }

        private string _FOTO;
        [Display(Name = "Foto")]
        public string FOTO
        {
            get { return _FOTO; }
            set { _FOTO = value; }
        }

        private string _USUARIO_REGISTRO;
        [Display(Name = "Usuario Registro")]
        public string USUARIO_REGISTRO
        {
            get { return _USUARIO_REGISTRO; }
            set { _USUARIO_REGISTRO = value; }
        }

        private string _DOMICILIO;
        [Display(Name = "Domicilio")]
        public string DOMICILIO
        {
            get { return _DOMICILIO; }
            set { _DOMICILIO = value; }
        }

        private int _PERSONA_ID;
        [Display(Name = "Código Persona")]
        public int PERSONA_ID
        {
            get { return _PERSONA_ID; }
            set { _PERSONA_ID = value; }
        }
    }
}
