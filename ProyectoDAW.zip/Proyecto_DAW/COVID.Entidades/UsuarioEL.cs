﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Entidades
{
    public class UsuarioEL
    {
        private int _USUARIO_ID;
        private string _LOGIN;
        private string _APELLIDO_MATERNO;
        private string _APELLIDO_PATERNO;
        private string _NOMBRE;
        private string _NOMBRE_COMPLETO;
        private int _TIPO_DOCUMENTO_CODIGO;
        private string _TIPO_DOCUMENTO_DESCRIPCION;
        private string _DOCUMENTO;
        private string _CELULAR;
        private string _TELEFONO;
        private string _EMAIL;
        private string _DESCRIPCION;
        private string _CLAVE;
        private int _ESTADO_CODIGO;
        private string _ESTADO_DESCRIPCION;
        private string _USUARIO_REGISTRO;
        private string _LOGIN_USUARIO;
        private string _VALIDAR_CONTRASENA;

        [Display(Name = "Repetir Contraseña")]
        [Required(ErrorMessage = "El campo Repetir Contraseña es obligatorio.")]
        public string VALIDAR_CONTRASENA
        {
            get { return _VALIDAR_CONTRASENA; }
            set { _VALIDAR_CONTRASENA = value; }
        }
        private int _ROL_CODIGO;

        [Display(Name = "Rol")]
        public int ROL_CODIGO
        {
            get { return _ROL_CODIGO; }
            set { _ROL_CODIGO = value; }
        }

        [Display(Name = "ID")]
        public int USUARIO_ID
        {
            get { return _USUARIO_ID; }
            set { _USUARIO_ID = value; }
        }
        [Display(Name = "Login")]
        [StringLength(60)]
        public string LOGIN
        {
            get { return _LOGIN; }
            set { _LOGIN = value; }
        }
        [Display(Name = "Apellido Materno")]
        [StringLength(60)]
        public string APELLIDO_MATERNO
        {
            get { return _APELLIDO_MATERNO; }
            set { _APELLIDO_MATERNO = value; }
        }
        [Display(Name = "Apellido Paterno")]
        [StringLength(60)]
        [Required(ErrorMessage = "El campo Apellido Paterno es obligatorio.")]

        public string APELLIDO_PATERNO
        {
            get { return _APELLIDO_PATERNO; }
            set { _APELLIDO_PATERNO = value; }
        }
        [Display(Name = "Nombre")]
        [StringLength(60)]
        [Required(ErrorMessage = "El campo Nombre es obligatorio.")]
        public string NOMBRE
        {
            get { return _NOMBRE; }
            set { _NOMBRE = value; }
        }
        [Display(Name = "Nombre")]
        [StringLength(182)]
        public string NOMBRE_COMPLETO
        {
            get { return _NOMBRE_COMPLETO; }
            set { _NOMBRE_COMPLETO = value; }
        }
        [Display(Name = "Tipo Documento")]
        [Required(ErrorMessage = "El campo Tipo Documento es obligatorio.")]
        public int TIPO_DOCUMENTO_CODIGO
        {
            get { return _TIPO_DOCUMENTO_CODIGO; }
            set { _TIPO_DOCUMENTO_CODIGO = value; }
        }
        public string TIPO_DOCUMENTO_DESCRIPCION
        {
            get { return _TIPO_DOCUMENTO_DESCRIPCION; }
            set { _TIPO_DOCUMENTO_DESCRIPCION = value; }
        }
        [Display(Name = "Documento")]
        [StringLength(30)]
        [Required(ErrorMessage = "El campo Documento es obligatorio.")]
        public string DOCUMENTO
        {
            get { return _DOCUMENTO; }
            set { _DOCUMENTO = value; }
        }
        [Display(Name = "Celular")]
        [StringLength(20)]
        public string CELULAR
        {
            get { return _CELULAR; }
            set { _CELULAR = value; }
        }
        [Display(Name = "Teléfono")]
        [StringLength(20)]
        public string TELEFONO
        {
            get { return _TELEFONO; }
            set { _TELEFONO = value; }
        }
        [Display(Name = "Email")]
        [StringLength(100)]
        [Required(ErrorMessage = "El campo Email es obligatorio.")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "El campo Email no tiene el formato correcto.")]
        public string EMAIL
        {
            get { return _EMAIL; }
            set { _EMAIL = value; }
        }


        [Display(Name = "Descripción")]
        [StringLength(120)]
        public string DESCRIPCION
        {
            get { return _DESCRIPCION; }
            set { _DESCRIPCION = value; }
        }

        [Display(Name = "Contraseña")]
        [Required(ErrorMessage = "El campo Clave es obligatorio.")]
        public string CLAVE
        {
            get { return _CLAVE; }
            set { _CLAVE = value; }
        }

        [Display(Name = "Estado")]
        public int ESTADO_CODIGO
        {
            get { return _ESTADO_CODIGO; }
            set { _ESTADO_CODIGO = value; }
        }
        public string ESTADO_DESCRIPCION
        {
            get { return _ESTADO_DESCRIPCION; }
            set { _ESTADO_DESCRIPCION = value; }
        }

        public string USUARIO_REGISTRO
        {
            get { return _USUARIO_REGISTRO; }
            set { _USUARIO_REGISTRO = value; }
        }
        public string LOGIN_USUARIO
        {
            get { return _LOGIN_USUARIO; }
            set { _LOGIN_USUARIO = value; }
        }

        private string _AVATAR;
        [Display(Name = "Avatar")]
        public string AVATAR
        {
            get { return _AVATAR; }
            set { _AVATAR = value; }
        }
    }
}
