﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Entidades
{
    public class ParametroEL
    {
        private string _CODIGO_VALOR;
        private int _GRUPO_LISTA_VALORES;
        private string _DESCRIPCION;
        private string _VALOR;

        [Display(Name = "ID")]
        public string CODIGO_VALOR
        {
            get { return _CODIGO_VALOR; }
            set { _CODIGO_VALOR = value; }
        }
        [Display(Name = "Grupo parámetro")]
        public int GRUPO_LISTA_VALORES
        {
            get { return _GRUPO_LISTA_VALORES; }
            set { _GRUPO_LISTA_VALORES = value; }
        }
        [Display(Name = "Descripción")]
        public string DESCRIPCION
        {
            get { return _DESCRIPCION; }
            set { _DESCRIPCION = value; }
        }
        [Display(Name = "Valor")]
        public string VALOR
        {
            get { return _VALOR; }
            set { _VALOR = value; }
        }
    }
}
