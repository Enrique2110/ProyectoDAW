﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Entidades
{
    public class RolEL
    {
        private int _ROL_ID;
        private string _NOMBRE_ROL;
        private string _DESCRIPCION;
        private int _ESTADO_CODIGO;
        private string _ESTADO_DESCRIPCION;
        private string _USUARIO_REGISTRO;

        [Display(Name = "ID")]
        public int ROL_ID
        {
            get { return _ROL_ID; }
            set { _ROL_ID = value; }
        }
        [Display(Name = "Nombre Rol")]
        [StringLength(60)]
        [Required(ErrorMessage = "El campo Nombre Rol es obligatorio.")]
        public string NOMBRE_ROL
        {
            get { return _NOMBRE_ROL; }
            set { _NOMBRE_ROL = value; }
        }
        [Display(Name = "Descripción")]
        [StringLength(150)]
        [Required(ErrorMessage = "El campo Descripción es obligatorio.")]
        public string DESCRIPCION
        {
            get { return _DESCRIPCION; }
            set { _DESCRIPCION = value; }
        }
        [Display(Name = "Estado")]
        [StringLength(1)]
        [Required(ErrorMessage = "El campo Estado es obligatorio.")]
        public int ESTADO_CODIGO
        {
            get { return _ESTADO_CODIGO; }
            set { _ESTADO_CODIGO = value; }
        }
        public string ESTADO_DESCRIPCION
        {
            get { return _ESTADO_DESCRIPCION; }
            set { _ESTADO_DESCRIPCION = value; }
        }
        public string USUARIO_REGISTRO
        {
            get { return _USUARIO_REGISTRO; }
            set { _USUARIO_REGISTRO = value; }
        }
    }
}
