﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Entidades.Listado
{
    public class TriajeListaEL
    {
        private int _TRIAJE_ID;

        public int TRIAJE_ID
        {
            get { return _TRIAJE_ID; }
            set { _TRIAJE_ID = value; }
        }
        private string _NOMBRE_PACIENTE;

        public string NOMBRE_PACIENTE
        {
            get { return _NOMBRE_PACIENTE; }
            set { _NOMBRE_PACIENTE = value; }
        }
        private string _APELLIDO_PACIENTE;

        public string APELLIDO_PACIENTE
        {
            get { return _APELLIDO_PACIENTE; }
            set { _APELLIDO_PACIENTE = value; }
        }

        private string _NRO_DOCUMENTO;

        public string NRO_DOCUMENTO
        {
            get { return _NRO_DOCUMENTO; }
            set { _NRO_DOCUMENTO = value; }
        }

        private string _PROFESION;

        public string PROFESION
        {
            get { return _PROFESION; }
            set { _PROFESION = value; }
        }
        private string _RESULTADO;

        public string RESULTADO
        {
            get { return _RESULTADO; }
            set { _RESULTADO = value; }
        }

        private string _TIPO_PRUEBA;

        public string TIPO_PRUEBA
        {
            get { return _TIPO_PRUEBA; }
            set { _TIPO_PRUEBA = value; }
        }

        private string _DIRECCION;

        public string DIRECCION
        {
            get { return _DIRECCION; }
            set { _DIRECCION = value; }
        }

        private string _DISTRITO;

        public string DISTRITO
        {
            get { return _DISTRITO; }
            set { _DISTRITO = value; }
        }
    }
}
