﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Entidades.Listado
{
    public class RolListaEL
    {
        private int _ROL_ID;
        private string _NOMBRE_ROL;
        private string _ESTADO_DESCRIPCION;
        private string _USUARIO_CREACION;

        public string USUARIO_CREACION
        {
            get { return _USUARIO_CREACION; }
            set { _USUARIO_CREACION = value; }
        }

        [DisplayName("ID Rol")]
        public int ROL_ID
        {
            get { return _ROL_ID; }
            set { _ROL_ID = value; }
        }
        [DisplayName("Nombre Rol")]
        public string NOMBRE_ROL
        {
            get { return _NOMBRE_ROL; }
            set { _NOMBRE_ROL = value; }
        }
        [DisplayName("Estado")]
        public string ESTADO_DESCRIPCION
        {
            get { return _ESTADO_DESCRIPCION; }
            set { _ESTADO_DESCRIPCION = value; }
        }
    }
}
