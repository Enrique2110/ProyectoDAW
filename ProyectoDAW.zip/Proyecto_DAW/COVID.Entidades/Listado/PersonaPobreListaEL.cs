﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Entidades.Listado
{
    public class PersonaPobreListaEL
    {
        private int _PERSONA_ID;

        [DisplayName("ID")]
        public int PERSONA_ID
        {
            get { return _PERSONA_ID; }
            set { _PERSONA_ID = value; }
        }
        private string _TIPO_DOCUMENTO;

        [DisplayName("Tipo Documento")]
        public string TIPO_DOCUMENTO
        {
            get { return _TIPO_DOCUMENTO; }
            set { _TIPO_DOCUMENTO = value; }
        }
        private string _NRO_DOCUMENTO;

        [DisplayName("Nro Documento")]
        public string NRO_DOCUMENTO
        {
            get { return _NRO_DOCUMENTO; }
            set { _NRO_DOCUMENTO = value; }
        }
        private string _PATERNO;

        [DisplayName("Apellido Paterno")]
        public string PATERNO
        {
            get { return _PATERNO; }
            set { _PATERNO = value; }
        }

        private string _MATERNO;

        [DisplayName("Apellido Materno")]
        public string MATERNO
        {
            get { return _MATERNO; }
            set { _MATERNO = value; }
        }

        private string _NOMBRES;

        [DisplayName("Nombres")]
        public string NOMBRES
        {
            get { return _NOMBRES; }
            set { _NOMBRES = value; }
        }

        private string _DIRECCION;

        [DisplayName("Dirección")]
        public string DIRECCION
        {
            get { return _DIRECCION; }
            set { _DIRECCION = value; }
        }

        private string _SEXO;

        [DisplayName("Sexo")]
        public string SEXO
        {
            get { return _SEXO; }
            set { _SEXO = value; }
        }

    }
}
