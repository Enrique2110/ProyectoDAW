﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Entidades.Listado
{
    public class OpcionListaEL
    {
        private int _OPCION_ID;
        private string _NOMBRE;
        private string _ESTADO_DESCRIPCION;

        [DisplayName("ID")]
        public int OPCION_ID
        {
            get { return _OPCION_ID; }
            set { _OPCION_ID = value; }
        }
        [DisplayName("Nombre Opción")]
        public string NOMBRE
        {
            get { return _NOMBRE; }
            set { _NOMBRE = value; }
        }
        [DisplayName("Estado")]
        public string ESTADO_DESCRIPCION
        {
            get { return _ESTADO_DESCRIPCION; }
            set { _ESTADO_DESCRIPCION = value; }
        }
    }
}
