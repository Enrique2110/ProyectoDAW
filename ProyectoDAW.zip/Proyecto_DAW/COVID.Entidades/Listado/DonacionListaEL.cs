﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Entidades.Listado
{
    public class DonacionListaEL
    {
        private int _DONACION_ID;

        public int DONACION_ID
        {
            get { return _DONACION_ID; }
            set { _DONACION_ID = value; }
        }
        private string _PATERNO_DONANTE;

        public string PATERNO_DONANTE
        {
            get { return _PATERNO_DONANTE; }
            set { _PATERNO_DONANTE = value; }
        }
        private string _MATERNO_DONANTE;

        public string MATERNO_DONANTE
        {
            get { return _MATERNO_DONANTE; }
            set { _MATERNO_DONANTE = value; }
        }

        private string _NOMBRE_DONANTE;

        public string NOMBRE_DONANTE
        {
            get { return _NOMBRE_DONANTE; }
            set { _NOMBRE_DONANTE = value; }
        }

        private string _TIPO_DONACION;

        public string TIPO_DONACION
        {
            get { return _TIPO_DONACION; }
            set { _TIPO_DONACION = value; }
        }

        private string _ESTADO_DONACION;

        public string ESTADO_DONACION
        {
            get { return _ESTADO_DONACION; }
            set { _ESTADO_DONACION = value; }
        }

        private decimal _CANTIDAD;

        public decimal CANTIDAD
        {
            get { return _CANTIDAD; }
            set { _CANTIDAD = value; }
        }
        private string _DESCRIPCION_DONACION;

        public string DESCRIPCION_DONACION
        {
            get { return _DESCRIPCION_DONACION; }
            set { _DESCRIPCION_DONACION = value; }
        }

        private string _FECHA_REGISTRO;

        public string FECHA_REGISTRO
        {
            get { return _FECHA_REGISTRO; }
            set { _FECHA_REGISTRO = value; }
        }

    }
}
