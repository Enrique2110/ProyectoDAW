﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Entidades.Listado
{
    public class UsuarioListaEL
    {
        private int _USUARIO_ID;

        [DisplayName("ID")]
        public int USUARIO_ID
        {
            get { return _USUARIO_ID; }
            set { _USUARIO_ID = value; }
        }
        private string _DOCUMENTO;

        [DisplayName("Documento")]
        public string DOCUMENTO
        {
            get { return _DOCUMENTO; }
            set { _DOCUMENTO = value; }
        }
        private string _LOGIN;

        [DisplayName("Login")]
        public string LOGIN
        {
            get { return _LOGIN; }
            set { _LOGIN = value; }
        }
        private string _NOMBRE_COMPLETO;

        [DisplayName("Nombre Completo")]
        public string NOMBRE_COMPLETO
        {
            get { return _NOMBRE_COMPLETO; }
            set { _NOMBRE_COMPLETO = value; }
        }
        private string _ESTADO_DESCRIPCION;

        [DisplayName("Estado")]
        public string ESTADO_DESCRIPCION
        {
            get { return _ESTADO_DESCRIPCION; }
            set { _ESTADO_DESCRIPCION = value; }
        }

        private string _ROL_DESCRIPCION;

        [DisplayName("Rol")]
        public string ROL_DESCRIPCION
        {
            get { return _ROL_DESCRIPCION; }
            set { _ROL_DESCRIPCION = value; }
        }
    }
}
