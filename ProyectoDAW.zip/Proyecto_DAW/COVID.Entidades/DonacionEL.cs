﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Entidades
{
    public class DonacionEL
    {
        private int _DONACION_ID;
        [Display(Name = "ID")]
        public int DONACION_ID
        {
            get { return _DONACION_ID; }
            set { _DONACION_ID = value; }
        }

        private int _TIPO_DONACION_ID;
        [Display(Name = "Tipo Donación")]
        public int TIPO_DONACION_ID
        {
            get { return _TIPO_DONACION_ID; }
            set { _TIPO_DONACION_ID = value; }
        }
        private int _ESTADO_DONACION_ID;
        [Display(Name = "Estado Donación")]
        public int ESTADO_DONACION_ID
        {
            get { return _ESTADO_DONACION_ID; }
            set { _ESTADO_DONACION_ID = value; }
        }

        private string _NOMBRE_DONANTE;
        [Display(Name = "Nombre")]
        public string NOMBRE_DONANTE
        {
            get { return _NOMBRE_DONANTE; }
            set { _NOMBRE_DONANTE = value; }
        }

        private string _APELLIDO_PATERNO;
        [Display(Name = "Apellido Paterno")]
        public string APELLIDO_PATERNO
        {
            get { return _APELLIDO_PATERNO; }
            set { _APELLIDO_PATERNO = value; }
        }

        private string _APELLIDO_MATERNO;
        [Display(Name = "Apellido Materno")]
        public string APELLIDO_MATERNO
        {
            get { return _APELLIDO_MATERNO; }
            set { _APELLIDO_MATERNO = value; }
        }

        private int _TIPO_DOCUMENTO_ID;
        [Display(Name = "Tipo Documento")]
        public int TIPO_DOCUMENTO_ID
        {
            get { return _TIPO_DOCUMENTO_ID; }
            set { _TIPO_DOCUMENTO_ID = value; }
        }

        private string _NRO_DOCUMENTO;
        [Display(Name = "Nro. Documento")]
        public string NRO_DOCUMENTO
        {
            get { return _NRO_DOCUMENTO; }
            set { _NRO_DOCUMENTO = value; }
        }

        private int _SEXO_ID;
        [Display(Name = "Sexo")]
        public int SEXO_ID
        {
            get { return _SEXO_ID; }
            set { _SEXO_ID = value; }
        }

        private string _DESCRIPCION_DONACION;
        [Display(Name = "Descripción")]
        public string DESCRIPCION_DONACION
        {
            get { return _DESCRIPCION_DONACION; }
            set { _DESCRIPCION_DONACION = value; }
        }

        private decimal _CANTIDAD;
        [Display(Name = "Cantidad")]
        public decimal CANTIDAD
        {
            get { return _CANTIDAD; }
            set { _CANTIDAD = value; }
        }

        private string _USUARIO_CREACION;
        [Display(Name = "Usuario Creación")]
        public string USUARIO_CREACION
        {
            get { return _USUARIO_CREACION; }
            set { _USUARIO_CREACION = value; }
        }

        private string _DESCRIPCION;
        public string DESCRIPCION
        {
            get { return _DESCRIPCION; }
            set { _DESCRIPCION = value; }
        }

        private int _TOTAL_DONACIONES;
        public int TOTAL_DONACIONES
        {
            get { return _TOTAL_DONACIONES; }
            set { _TOTAL_DONACIONES = value; }
        }
    }
}
