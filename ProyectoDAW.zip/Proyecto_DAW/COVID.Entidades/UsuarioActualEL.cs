﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Entidades
{
    public class UsuarioActualEL
    {
        private int _LOG_SESION_ID;
        private int _USUARIO_ID;
        private string _LOGIN_USUARIO;
        private string _LOGIN_PWD;
        private string _APELLIDO_PATERNO;
        private string _APELLIDO_MATERNO;
        private string _NOMBRE;
        private int _ROL_ID;
        private string _NOMBRE_ROL;
        private int _PERSONA_ID;

        public int LOG_SESION_ID
        {
            get { return _LOG_SESION_ID; }
            set { _LOG_SESION_ID = value; }
        }
        public int USUARIO_ID
        {
            get { return _USUARIO_ID; }
            set { _USUARIO_ID = value; }
        }
        public string LOGIN_USUARIO
        {
            get { return _LOGIN_USUARIO; }
            set { _LOGIN_USUARIO = value; }
        }
        public string LOGIN_PWD
        {
            get { return _LOGIN_PWD; }
            set { _LOGIN_PWD = value; }
        }
        public string APELLIDO_PATERNO
        {
            get { return _APELLIDO_PATERNO; }
            set { _APELLIDO_PATERNO = value; }
        }
        public string APELLIDO_MATERNO
        {
            get { return _APELLIDO_MATERNO; }
            set { _APELLIDO_MATERNO = value; }
        }
        public string NOMBRE
        {
            get { return _NOMBRE; }
            set { _NOMBRE = value; }
        }
        public int ROL_ID
        {
            get { return _ROL_ID; }
            set { _ROL_ID = value; }
        }
        public string NOMBRE_ROL
        {
            get { return _NOMBRE_ROL; }
            set { _NOMBRE_ROL = value; }
        }
        public int PERSONA_ID
        {
            get { return _PERSONA_ID; }
            set { _PERSONA_ID = value; }
        }

        private string _AVATAR;

        public string AVATAR
        {
            get { return _AVATAR; }
            set { _AVATAR = value; }
        }
    }
}
