﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Entidades
{
    public class OpcionEL
    {
        private int _OPCION_ID;

        [Display(Name = "ID")]
        public int OPCION_ID
        {
            get { return _OPCION_ID; }
            set { _OPCION_ID = value; }
        }
        private string _NOMBRE_OPCION;

        [Display(Name = "Nombre Opción")]
        public string NOMBRE_OPCION
        {
            get { return _NOMBRE_OPCION; }
            set { _NOMBRE_OPCION = value; }
        }
        private string _SIGLA_OPCION;

        [Display(Name = "Sigla")]
        public string SIGLA_OPCION
        {
            get { return _SIGLA_OPCION; }
            set { _SIGLA_OPCION = value; }
        }

        private int _ESTADO;

        [Display(Name = "Estado")]
        public int ESTADO
        {
            get { return _ESTADO; }
            set { _ESTADO = value; }
        }

        private string _DESCRIPCION;

        [Display(Name = "Descripción")]
        public string DESCRIPCION
        {
            get { return _DESCRIPCION; }
            set { _DESCRIPCION = value; }
        }

        private string _USU_CREACION;

        public string USU_CREACION
        {
            get { return _USU_CREACION; }
            set { _USU_CREACION = value; }
        }
    }
}
