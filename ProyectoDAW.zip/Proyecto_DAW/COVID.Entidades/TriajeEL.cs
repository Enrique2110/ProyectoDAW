﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Entidades
{
    public class TriajeEL
    {
        private int _TRIAJE_ID;
        [Display(Name = "ID")]
        public int TRIAJE_ID
        {
            get { return _TRIAJE_ID; }
            set { _TRIAJE_ID = value; }
        }

        private int _RESULTADO_ID;
        [Display(Name = "Resultado")]
        public int RESULTADO_ID
        {
            get { return _RESULTADO_ID; }
            set { _RESULTADO_ID = value; }
        }
        private int _TIPO_PRUEBA_ID;
        [Display(Name = "Tipo Prueba")]
        public int TIPO_PRUEBA_ID
        {
            get { return _TIPO_PRUEBA_ID; }
            set { _TIPO_PRUEBA_ID = value; }
        }

        private string _NOMBRE_PACIENTE;
        [Display(Name = "Nombre Paciente")]
        [Required(ErrorMessage = "El nombre del Paciente es obligatorio.")]
        public string NOMBRE_PACIENTE
        {
            get { return _NOMBRE_PACIENTE; }
            set { _NOMBRE_PACIENTE = value; }
        }

        private string _APELLIDO_PACIENTE;
        [Display(Name = "Apellido Paterno")]
        [Required(ErrorMessage = "El apellido paterno del Paciente es obligatorio.")]
        public string APELLIDO_PACIENTE
        {
            get { return _APELLIDO_PACIENTE; }
            set { _APELLIDO_PACIENTE = value; }
        }

        private string _APELLIDO_MATERNO_PACIENTE;
        [Display(Name = "Apellido Materno")]
        [Required(ErrorMessage = "El apellido materno del Paciente es obligatorio.")]
        public string APELLIDO_MATERNO_PACIENTE
        {
            get { return _APELLIDO_MATERNO_PACIENTE; }
            set { _APELLIDO_MATERNO_PACIENTE = value; }
        }

        private int _TIPO_DOCUMENTO_ID;
        [Display(Name = "Tipo Documento")]
        public int TIPO_DOCUMENTO_ID
        {
            get { return _TIPO_DOCUMENTO_ID; }
            set { _TIPO_DOCUMENTO_ID = value; }
        }

        private string _NRO_DOCUMENTO;
        [Display(Name = "Nro. Documento")]
        [Required(ErrorMessage = "El Nro. del documento es obligatorio.")]
        public string NRO_DOCUMENTO
        {
            get { return _NRO_DOCUMENTO; }
            set { _NRO_DOCUMENTO = value; }
        }

        private int _SEXO_ID;
        [Display(Name = "Sexo")]
        public int SEXO_ID
        {
            get { return _SEXO_ID; }
            set { _SEXO_ID = value; }
        }

        private string _DIRECCION;
        [Display(Name = "Dirección")]
        [Required(ErrorMessage = "La dirección es obligatoria.")]
        public string DIRECCION
        {
            get { return _DIRECCION; }
            set { _DIRECCION = value; }
        }

        private string _PROFESION;
        [Display(Name = "Profesión")]
        [Required(ErrorMessage = "La profesión es obligatoria.")]
        public string PROFESION
        {
            get { return _PROFESION; }
            set { _PROFESION = value; }
        }

        private string _USUARIO_CREACION;
        [Display(Name = "Usuario Creación")]
        public string USUARIO_CREACION
        {
            get { return _USUARIO_CREACION; }
            set { _USUARIO_CREACION = value; }
        }

        private int _TOTAL_TRIAJES;
        public int TOTAL_TRIAJE
        {
            get { return _TOTAL_TRIAJES; }
            set { _TOTAL_TRIAJES = value; }
        }

        private string _DESCRIPCION;
        public string DESCRIPCION
        {
            get { return _DESCRIPCION; }
            set { _DESCRIPCION = value; }
        }

        private string _TIPO_PRUEBA;
        public string TIPO_PRUEBA
        {
            get { return _TIPO_PRUEBA; }
            set { _TIPO_PRUEBA = value; }
        }
    }
}
